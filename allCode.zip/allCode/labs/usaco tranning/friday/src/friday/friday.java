package friday;

public class friday 
{
	public static void main(String[] args)
	{
		int years = 20;
		String days = calculateDays(years);
		System.out.println(days);
	}
	
	private static String calculateDays(int years) {
		int[] days = new int[7];
		
		int date = 2;
		for(int year = 1900; year < 1900 + years; year++) {
			for(int month = 0; month < 12; month++) {
				for(int day = 0; day < getDaysInMonth(month, year); day++) {
					if(day == 12)
						days[date % 7]++;
					date++;
				}
			}
		}

		for(int i = 1900; i < years + 1900; i++) {
			System.out.println(i + " " + isLeapYear(i));
		}
		
		return convertToString(days);
	}

	private static String convertToString(int[] days) {
		String out = "";
		for(int i = 0; i < 6; i++)
			out += days[i] + ",";
		out+= days[6] + "\n";
		return out;
	}
	
	private static int[] days = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	private static int getDaysInMonth(int month, int year) 
	{
		if(month == 1 && isLeapYear(year))
			return 29;
		
		return days[month];
	}
	
	private static boolean isLeapYear(int year) {
		if(year % 10 == 0 && (year / 10) % 10 == 0)
			return year % 400 == 0;
		
		else
			return year % 4 == 0;
	}
}
