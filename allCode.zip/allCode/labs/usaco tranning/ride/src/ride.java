/*
ID: davidka2
LANG: JAVA
PROG: ride
*/

import java.io.*;
import java.util.*;

public class ride {
    
    private static String test = "COMETQ\nHVNGAT";
    
    public static void main(String[] args) {
    	String go = rider(InAndOut.readFile("ride.in"));
    	InAndOut.writeFile("ride.out", go);
    }
    
    
    
    
    private static int cal(String data) {
    	if(data.length() == 0) { return 0; }
    	int total = 1;
    	for(int i = 0; i < data.length(); i++) {
    		total *= (int)data.charAt(i) - (int)'A' + 1;
    	}
    	System.out.println(total);
    	return total%47;
    }
    
    private static String rider(String data) {
    	String[] tokens = data.split("\n");
    	int a = cal(tokens[0]);
    	int b = cal(tokens[1]);
    	return (a==b) ? "GO\n" : "STAY\n";
    }
}





class InAndOut {

	public static void writeFile(String path, String data) {
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(path));
			br.write(data);
			br.close();
		}catch(Exception e) { e.printStackTrace(); }
	}

	public static String readFile(String path) {
    	try {
	    	String data = "";
	    	Scanner file = new Scanner(new File(path));
			while(file.hasNext()) {
		     	data += file.nextLine() + "\n";
			}
			return data;
    	} catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }

}

