package beads;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		int beads = calculateBeads("rrrwwbbwrwrrrbbrrww");
		System.out.println(beads);
	}
	
	private static boolean isValid(String beads, int i, char c) {
		if(i < 0 || i >= beads.length()) { return false; }
		return beads.charAt(i) == c || beads.charAt(i) == 'w';
	}
	
	private static BeadData calculateBeadData(String beads, int i) {
		char c = beads.charAt(i);
		int start = i, stop = i;
		
		while(isValid(beads, start - 1, c)) {
			start--;
		}
		
		while(isValid(beads, stop + 1, c)) {
			stop++;
		}
		
		return new BeadData(c, start, stop + 1);
	}
	
	private static Set<BeadData> split(String beads) {
		Set<BeadData> beadData = new TreeSet<BeadData>();
		for(int i = 0; i < beads.length(); i++) {
			if(beads.charAt(i) != 'w') {
				beadData.add(calculateBeadData(beads, i));
			}
		}
		
		return beadData;
	}
	
	private static int calculateBeads(String beads) {
		Set<BeadData> beadData = split(beads + beads);
		
		if(beadData.size() == 1 || beadData.size() == 0 || split(beads).size() == 2) { return beads.length(); } 
		
		Iterator<BeadData> it = beadData.iterator();
		BeadData last = it.next();
		int max = -1;
		while(it.hasNext()) {
			BeadData now = it.next();
			int length = last.calLength(now);
			
			if(length > max) {
				max = length;
			}
			
			last = now;
		}

		return max - 1;
	}
}
