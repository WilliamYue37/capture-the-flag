package beads;

public class BeadData implements Comparable<BeadData> {

	private char c;
	private int start;
	private int stop;
	
	public BeadData(char c, int start, int stop) {
		this.c = c;
		this.start = start;
		this.stop = stop;
	}
	
	public char getChar() {
		return c;
	}
	
	public int getLength() {
		return stop - start;
	}
	
	public String toString() {
		return c + " " + start + " to " + stop;
	}
	
	public boolean equals(Object o) {
		if(o instanceof BeadData) {
			BeadData b = (BeadData)o;
			return b.start == start && b.stop == stop;
		} else {
			return false;
		}
	}
	
	public int calLength(BeadData next) {
		return next.stop - start;
	}
	
	public int compareTo(BeadData other) {
		return ((Integer)start).compareTo(other.start);
	}
}
