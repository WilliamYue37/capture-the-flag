/*
ID: davidka2
LANG: JAVA
TASK: gift1
*/

import java.util.*;
import java.io.*;



public class gift1 {

	private String test = "5 dave laura owen vick amr dave 200 3 laura owen vick owen 500 1 dave amr 150 2 vick owen laura 0 2 amr vick vick 0 0";

    public static void main(String[] args) {
    	String money = getMoneyFinal(readFile("gift1.in"));
    	writeFile("gift1.out", money);
    }

	private static String getMoneyFinal(String data) {
		String output = "";
	
		String[] tokens = data.split(" ");
		int numPeople = Integer.parseInt(tokens[0]);
		person[] people = new person[numPeople];
		for(int i = 0; i < numPeople; i++) {
			people[i] = new person(tokens[i+1]);
		}
	
		int offset = numPeople + 1;
		while(offset < tokens.length) {
			String person = tokens[offset];
			int amount = Integer.parseInt(tokens[offset+1]);
			int num = Integer.parseInt(tokens[offset+2]);
			if(num != 0) {
				String[] names = new String[num];
				for(int i = 0; i < num; i++) {
					names[i] = tokens[i + offset + 3];
				}
		
				for(person p : people) {
					p.give(person, amount - amount%num);
					p.recieve(names, amount/num);
				}
			}
			
			offset += 3 + num;
		}
	
		for(person p : people) {
			output += p;
		}
	
		return output;
	}

	private static void writeFile(String path, String data) {
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(path));
			br.write(data);
			br.close();
		}catch(Exception e) { e.printStackTrace(); }
	}

	private static String readFile(String path) {
    	try {
	    	String data = "";
	    	Scanner file = new Scanner(new File(path));
			while(file.hasNext()) {
		     	data += file.nextLine() + " ";
			}
			return data;
    	} catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }

}

class person {

	String name;
	int value;

	public person(String name) {
		this.name = name;		
	}

	public String toString() {
		return name + " " + value + "\n";
	}

	public void give(String name, int i) {
		if(name.equals(this.name))
			value -= i;
	}

	public void recieve(String[] names, int i) {
		for(String s : names) {
			if(s.equals(name)) {
				value += i;
				return;
			}
		}
	}
}




























