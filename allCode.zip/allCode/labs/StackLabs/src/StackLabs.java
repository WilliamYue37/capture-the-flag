import java.util.*;
import java.io.*;

public class StackLabs {
    
    private static void divide() {
    	System.out.println("------------------------");
    }
    
    public static void main(String[] args) {
    	labA("gsgsjb43tb39sFSF");
    	divide();
    	labB(labBData);
    	divide();
    	labC(labCData);
    	divide();
    }
    
    private static void evaluate(String data) {
    	String[] tokens = data.split(" ");
    	MyStack<Integer> stack = new MyStack<Integer>();
    	for(String s : tokens) {
    		if(inList(operators, s.charAt(0))) {
    			int a = stack.pop();
    			int b = stack.pop();
    			int c = 0;
    			switch(s) {
    			case "+" :
    				c = a+b;
    				break;
    			case "-" :
    				c = a-b;
    				break;
    			case "*" :
    				c = a*b;
    				break;
    			case "/" :
    				c = a/b;
    				break;
    			}
    			stack.push(c);
    		} else {
    			stack.push(Integer.parseInt(s));
    		}
    	}
    	
    	System.out.println(data + " = " + stack.pop());
    }
    
    private static String labCData = "2 7 + 1 2 + +\n1 2 3 4 + + +\n9 3 * 8 / 4 +\n3 3 + 7 * 9 2 / +\n9 3 / 2 * 7 9 * + 4 -\n5 5 + 2 * 4 / 9 +\n";
    private static String operators = "+-*/";
    private static void labC(String data) {
    	String[] tokens = data.split("\n");
    	for(String s : tokens) {
    		evaluate(s);
    	}
    }
    
    private static boolean inList(String s, char c) {
    	for(int i = 0; i < s.length(); i++) {
    		if(s.charAt(i)==c) {
    			return true;
    		}
    	}
    	return false;
    }
    
    private static void isValid(String data) {
    	Stack<Character> s = new Stack<Character>();
    	for(int i = 0; i < data.length(); i++) {
    		int index = opening.indexOf(data.charAt(i));
    		if(index == -1) {
    			if(closing.indexOf(data.charAt(i)) == -1) { continue; }
    			
    			if(s.isEmpty()) {
    				System.out.println(data + " is NOT valid");
    				return;
    			}
    			
    			char c = s.pop();
    			if(opening.indexOf(c) != closing.indexOf(data.charAt(i))) {
    				System.out.println(data + " is NOT valid");
    				return;
    			}
    		} else {
    			s.push(data.charAt(i));
    		}
    	}
    	
    	if(s.isEmpty()) {
    		System.out.println(data + " is vaild");
    	} else {
    		System.out.println(data + " is NOT valid");
    	}
    }
    
    private static String labBData = "(abc(*def)\n[{}]\n[\n[{<()>}]\n{<html[value=4]*(12)>{$x}}\n[one]<two>{three}(four)\ncar(cdr(a)(b)))\ncar(cdr(a)(b))";
    private static String opening = "{[(<";
    private static String closing = "}])>";
    private static void labB(String data) {
    	String[] tokens = data.split("\n");
    	for(String s : tokens) {
    		isValid(s);
    	}
    }
    
    private static void labA(String tokens) {
    	Stack s = new Stack<Character>();
    	for(int i = 0; i < tokens.length(); i++) {
    		s.push(tokens.charAt(i));
    	}
    	System.out.println(s);
    	while(!s.isEmpty()) {
    		System.out.print(s.pop() + " ");
    	}
    	System.out.println();
    }
}

class MyStack<E> {
	private List<E> list = new ArrayList<E>();
	
	public void push(E e) {
		list.add(0, e);
	}
	
	public E pop() {
		return list.get(0);
	}
	
	public int size() {
		return list.size();
	}
	
	public String toString() {
		return list.toString();
	}
}






class InAndOut {

	public static void writeFile(String path, String data) {
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(path));
			br.write(data);
			br.close();
		}catch(Exception e) { e.printStackTrace(); }
	}

	public static String readFile(String path) {
    	try {
	    	String data = "";
	    	Scanner file = new Scanner(new File(path));
			while(file.hasNext()) {
		     	data += file.nextLine() + " ";
			}
			return data;
    	} catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }

}

