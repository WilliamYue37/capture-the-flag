import java.util.*;

public class CompareLab {
    
    public static void main(String[] args) {
    	Tester[] test = new Tester[5];
    	for(int i = 0; i < test.length; i++) {
    		test[i] = new Tester();
    	}
    	
    	System.out.println(Arrays.toString(test));
    	Arrays.sort(test);
    	System.out.println(Arrays.toString(test));
    }
}

class Tester implements Comparable {
	
	private int size;
	private int data;
	
	public Tester() {
		size = (int) (Math.random() * 100);
		data = (int) (Math.random() * 100);
	}
	
	public int compareTo(Object t) {
		return size - ((Tester)t).size;
	}
	
	public String toString() {
		return "SIZE: " + size + " DATA: " + data;
	}
}
