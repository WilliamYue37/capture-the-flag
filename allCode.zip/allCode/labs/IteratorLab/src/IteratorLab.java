import java.util.*;

public class IteratorLab {
    
    public static void main(String[] args) {
    	ArrayList<String> strings = new ArrayList<String>();
    	strings.add("hello");
    	strings.add("hey");
    	strings.add("hi");
    	strings.add("hello");
    	System.out.println(strings);
    	replace(strings, "hello", "bonjour");
    	System.out.println(strings);
    	remove(strings, "bonjour");
    	System.out.println(strings);
    }
    
    private static void replace(ArrayList<String> strings, String string, String replace) {
    	ListIterator<String> it = strings.listIterator();
    	while(it.hasNext()) {
    		if(it.next().equals(string)) {
    			it.set(replace);
    		}
    	}
    }
    
    private static void remove(ArrayList<String> strings, String string) {
    	Iterator<String> strs = strings.iterator();
    	while(strs.hasNext()) {
    		if(strs.next().equals(string)) {
    			strs.remove();
    		}
    	}
    }
}
