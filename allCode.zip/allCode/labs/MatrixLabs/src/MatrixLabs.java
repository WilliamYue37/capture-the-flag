import java.util.*;
import java.io.*;

class Rational {
	
	private int x;
	private int y;
	
	public Rational(int x, int y) {
		this.x = x;
		this.y = y;
		simplify();
	}
	
	public float getValue() {
		return (float)x / y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public String toString() {
		return x + "/" + y;
	}

	private void simplify() {
		int a = Math.abs(x);
		int b = Math.abs(y);
		while (b > 0) {
	        int temp = b;
	        b = a % b;
	        a = temp;
    	}
		x /= a;
		y /= a;
	}

	public void add(Rational fraction) {
		int temp = y;
		x *= fraction.y;
		y *= fraction.y;
		x += fraction.x * temp;
		simplify();
	}
	
	public void sub(Rational fraction) {
		int temp = y;
		x *= fraction.y;
		y *= fraction.y;
		x -= fraction.x * temp;
		simplify();
	}
	
	public void mul(Rational fraction) {
		x *= fraction.x;
		y *= fraction.y;
		simplify();
	}
	
	public void div(Rational fraction) {
		x *= fraction.y;
		y *= fraction.x;
		simplify();
	}
}

class Roman {
	
	private String[] romans = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
	private int[] values = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
	
	private int val;
	private String roman;
	
	public Roman(int x) {
		val = x;
		roman = "";
		for(int i = 0; i < romans.length; i++) {
			if(x >= values[i]) {
				x -= values[i];
				roman += romans[i--];
			}
		}
	}
	
	public Roman add(Roman b) {
		return new Roman(b.val + val);
	}
	
	public void print() {
		System.out.println(roman + " " + val);
	}
}

public class MatrixLabs {

    public static void main(String[] args) {
    	//Roman r1 = new Roman(10);
    	//Roman r2 = new Roman(103);
    	//r1.print();
    	//r2.print();
    	//r1.add(r2).print();
    	
    	//Rational fraction = new Rational(25, 10);
    	//fraction.div(new Rational(1, 2));
    	//System.out.print(fraction);
    	
    	//printPerfectSquare(10);

    	//printTriangle(10, true);
    	
    	printSpiral(5);
    	
    	//String path = "C:\\Users\\600976\\Desktop\\lab01_matrices\\lab01b.dat";
    	//String data = readFile(path);
    	//String[] tokens = data.split("\\s+");
    	//for(String token : tokens) {
    	//	printHourGlass(token);
    	//}
    }

	private static boolean validIndex(int x, int y, int[][] mat) {
		if(x < 0) { return false; }
		if(y < 0) { return false; }
		if(x > mat.length - 1) { return false; }
		if(y > mat[x].length - 1) { return false; }
		if(mat[x][y] != 0) { return false; }
		return true;
	}

	private static void printSpiral(int size) {
		int[][] mat = new int[size][size];
		int r = 0;
		int c = 0;
		int dr = 1;
		int dc = 0;
		for(int i = 1; i <= size * size; i++) {
			mat[r][c] = i;
			if(!validIndex(r + dr, c + dc, mat)) {
				int temp = dr;
				dr = -dc;
				dc = temp;
			}
			r += dr;
			c += dc;
		}
		
		printMatrix(mat);
	}

    private static String readFile(String path) {
    	try {
	    	String data = "";
	    	Scanner file = new Scanner(new File(path));
			while(file.hasNext()) {
		     	data += file.nextLine() + "\n";
			}
			return data;
    	} catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }
    
    private static void printPerfectSquare(int size) {
    	int[][] mat = new int[size][size];
    	int numbersPlaced = 1;
    	int r = 0;
    	int c = size / 2;
    	mat[r][c] = 1;
    	while(numbersPlaced < size * size) {
    		r--;
    		if(r < 0) {
    			r = size - 1;
    		}
    		
    		c++;
    		if(c > size - 1) {
    			c = 0;
    		}
    		
    		if(mat[r][c] == 0) {
    			mat[r][c] = ++numbersPlaced;
    		}
    		
    		else {
    			r += 2;
    			if(r > size - 1) {
    				r -= size;
    			}
    			
    			c--;
    			if(c < 0) {
    				c = size - 1;
    			}
    			
    			mat[r][c] = ++numbersPlaced;
    		}
    	}
    	
    	printMatrix(mat);
    }
    
    private static void printHourGlass(String word) {
    	int length = word.length();
    	char[][] glass = new char[length][length];
    	
    	for(int r = 0; r < length; r++) {
    		for(int c = 0; c < length; c++) {
    			glass[r][c] = ' ';	
    		}
    	}
    	
    	for(int i = 0; i < length; i++) {
    		glass[0][i] = word.charAt(i);
    		glass[length - 1][i] = word.charAt(i);
    	} for(int i = 1; i < length - 1; i++) {
    		glass[i][i] = word.charAt(i);
    		glass[i][length - 1 - i] = word.charAt(length - 1 - i);
    	}

    	printMatrix(glass);
    	
    	System.out.println();
    }
    
    private static int[][] add(int[][] a, int[][] b) {
    	int[][] c = new int[a.length][];
    	for(int r = 0; r < a.length; r++) {
    		c[r] = new int[a[r].length];
    		for(int C = 0; C < a[r].length; C++) {
    			c[r][C] = a[r][C] + b[r][C];
    		}
    	}
    	return c;
    }
    
    private static void printTriangle(int size, boolean equal) {
    	int[][] triangle = new int[size][size];
    	for(int r = 0; r < size; r++) {
    		for(int c = 0; c < r + 1; c++) {
    			triangle[r][c] = 1;
    			if(c > 0 && c < r) {
    				triangle[r][c] = triangle[r - 1][c] + triangle[r - 1][c - 1];
    			}
    		}
    	}
    	
    	String[] rows = new String[size];
    	for(int r = 0; r < size; r++) {
    		rows[r] = "";
    		for(int c = 0; c < size; c++) {
    			if(triangle[r][c] != 0) {
    				rows[r] += triangle[r][c] + " ";
    			}
    		}
    	}
    	
    	if(equal) {
	    	int length = rows[size - 1].length();
	    	for(int r = 0; r < size; r++) {
	    		int l = rows[r].length();
	    		for(int i = 0; i < (length - l) / 2; i++) {
	    			rows[r] = " " + rows[r] + " ";
	    		}
	    	}
    	}
    	
    	for(String r : rows) {
    		System.out.println(r);
    	}
    	
    	System.out.println();
    }
    
    private static void printMatrix(int[][] matrix) {
    	int[] chars = new int[matrix[0].length];
    	String[][] strings = new String[matrix.length][matrix[0].length];
    	for(int r = 0; r < matrix.length; r++) {
    		for(int c = 0; c < matrix[r].length; c++) {
    			strings[r][c] = matrix[r][c] + " ";
    			if(strings[r][c].length() > chars[c]) {
    				chars[c] = strings[r][c].length();
    			}
    		}
    	}
    	
    	for(int r = 0; r < matrix.length; r++) {
    		for(int c = 0; c < matrix[r].length; c++) {
    			System.out.print(strings[r][c]);
    			for(int i = 0; i < chars[c] - strings[r][c].length(); i++) {
    				System.out.print(" ");
    			}
    		}
    		System.out.println();
    	}
    }
    
    private static void printMatrix(char[][] matrix) {
    	for(int r = 0; r < matrix.length; r++) {
    		for(int c = 0; c < matrix[r].length; c++) {
    			System.out.print(matrix[r][c]);
    		}
    		System.out.println();
    	}
    }
}
