import java.util.*;

public class SetLabs {
    
    public static void main(String[] args) {
    	uniqueDupes("hello hello hey hello runner run runner five sx Five");
    	System.out.println();
    	numbers("9 4 2 525 532523525 2 6 7 4 3");
    	System.out.println();
    	op("5 3 6 7 3 5 7 3", "4 -24 5 3 7 5 3");
    }
    
    private static Set<Integer> storeInSet(String data) {
    	String[] tokens = data.split(" ");
    	Set<Integer> set = new TreeSet<Integer>();
    	for(String s : tokens) {
    		set.add(Integer.parseInt(s));
    	}
    	
    	return set;
    }
    
    private static void op(String as, String bs) {
    	Set<Integer> a = storeInSet(as);
    	Set<Integer> b = storeInSet(bs);
    	Set<Integer> union = new TreeSet<Integer>();
    	Set<Integer> intersection = new TreeSet<Integer>();
    	Set<Integer> aNotB = new TreeSet<Integer>();
    	Set<Integer> bNotA = new TreeSet<Integer>();
    	
    	for(int i : a) {
    		union.add(i);
    	} for(int i : b) {
    		if(union.add(i)) {
    			bNotA.add(i);
    		} else {
    			intersection.add(i);
    		}
    	}
    	
    	System.out.println("Set A: " + a);
    	System.out.println("Set b: " + b);
    	System.out.println("union: " + union);
    	System.out.println("intersection: " + intersection);
    	System.out.println("a not b: " + aNotB);
    	System.out.println("b not a: " + bNotA);
    }
    
    private static void numbers(String data) { // TODO add perfect numbers
    	String[] tokens = data.split(" ");
    	Set<Integer> evens = new TreeSet<Integer>();
    	Set<Integer> odds = new TreeSet<Integer>();
    	for(int i = 0; i < tokens.length; i++) {
    		int integer = Integer.parseInt(tokens[i]);
    		if(integer % 2 == 0) {
    			evens.add(integer);
    		} else {
    			odds.add(integer);
    		}
    	}
    	
    	System.out.println("Data: " + data);
    	System.out.println("Evens: " + evens);
    	System.out.println("Odds: " + odds);
    }
    
    private static void uniqueDupes(String data) {
    	String[] tokens = data.split(" ");
    	Set<String> uniques = new TreeSet<String>();
    	Set<String> dupes = new TreeSet<String>();
    	for(int i = 0; i < tokens.length; i++) {
    		if(!uniques.add(tokens[i])) {
    			dupes.add(tokens[i]);
    		}
    	}
    	
    	System.out.println("Data: " + data);
    	System.out.println("Uniques: " + uniques);
    	System.out.println("Dupes: " + dupes);
    }
}
