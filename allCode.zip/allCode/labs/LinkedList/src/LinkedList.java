import java.lang.IndexOutOfBoundsException;

class LinkedListLabs {
    
    public static void main(String[] args) {
    	mark(1);
    	for(int i = 0; i < 4; i++) {
    		labone();
    	}
    	
    	mark(2);
    	mark(3);
    	labtwo();
    	
    	mark(4);
    	lab4();
    }
    
    private static void lab4() {
    	for(int i = 0; i < 4; i++) {
    		lab4run();
    		System.out.println("\n");
    	}
    }
    
    private static void lab4run() {
		int size = (int)(Math.random() * 4) + 8;
		char c1 = (char)(Math.random() * 10 + (int)'a');
    	Letter start = new Letter(c1);
    	System.out.print(c1 + ", ");
    	
    	for(int i = 1; i < size; i++) {
    		char c = (char)(Math.random() * 10 + (int)'a');
    		System.out.print(c + ", ");
    		Letter temp = start;
    		boolean found = false;
    		
    		while(temp.getNext() != null && !found) {
    			if(temp.getChar() == c) {
    				found = true;
    				temp.addOne();
    			}
    			
    			temp = temp.getNext();
    		}
    		
    		if(temp.getChar() == c) {
    				found = true;
    				temp.addOne();
    			}
    		
    		if(!found) {
    			temp.setNext(new Letter(c));
    		}
    	}
    	
    	System.out.println();
    	while(start != null) {
    		System.out.print(start + ", ");
    		start = start.getNext();
    	}
    }
    
    private static void labtwo() {
    	LinkedList<Integer> list = new LinkedList<Integer>();
    	list.add(6);
    	list.add(9);
    	list.add(51);
    	System.out.println(list);
    	list.add(0, 1);
    	System.out.println(list);
    	list.remove(3);
    	System.out.println(list);
    	list.add(2, 99999);
    	System.out.println(list);
    	
    	//remove every other
    	for(int i = list.getSize() - 1; i >= 0; i -= 2) {
    		list.remove(i);
    	}
    	
    	System.out.println(list);
    }
    
    private static void labone() {
    	ListNode<Integer> start = getRandomList((int)(Math.random() * 4) + 2);
    	int listSize = 1;
    	int sum = start.getValue();
    	int min = start.getValue();
    	int max = start.getValue();
    	System.out.print(start.getValue() + " ");
    	start = start.getNext();
    	while(start != null) {
    		listSize++;
    		sum += start.getValue();
    		min = Math.min(min, start.getValue());
    		max = Math.max(max, start.getValue());
    		System.out.print(start.getValue() + " ");
    		start = start.getNext();
    	}
    	
    	System.out.println("\n");
    	double average = (double)sum / listSize;
    	System.out.println("\t\tSUM: " + sum);
    	System.out.println("\t\tAVERAGE: " + average);
    	System.out.println("\t\tMIN: " + min);
    	System.out.println("\t\tMAX: " + max);
    }
    
   	private static ListNode<Integer> getRandomList(int size) {
   		ListNode<Integer> start = new ListNode<Integer>((int)(Math.random() * 20), null);
   		ListNode<Integer> current = start;
   		for(int i = 1; i < size; i++) {
   			ListNode<Integer> next = new ListNode<Integer>((int)(Math.random() * 20), null);
   			current.setNext(next);
   			current = next;
   		}
   		
   		return start;
   	}
   	
   	private static void mark(int lab) {
   		System.out.println("");
   		System.out.println("-------------------");
   		System.out.println("Start Lab " + lab);
   		System.out.println("");
   	}
}

class LinkedList<T> {
	
	private ListNode<T> start;
	private int size;
	
	public LinkedList() {
		clear();
	}
	
	public void clear() {
		start = new ListNode<T>(null, null);
		size = 0;
	}
	
	public T get(int index) {
		if(index >= size || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		
		ListNode<T> get = start;
		for(int i = 0; i < index; i++) {
			get = get.getNext();
		}
		
		return get.getValue();
	}
	
	public T set(int index, T value) {
		if(index < 0 || index >= size) {
			throw new ArrayIndexOutOfBoundsException();
		}
		
		ListNode<T> set = start;
		for(int i = 0; i < index; i++) {
			set = set.getNext();
		}
		
		T t = set.getValue();
		set.setValue(value);
		return t;
	}
	
	public T remove(int index) {
		if(index >= size || index < 0) {
			throw new ArrayIndexOutOfBoundsException();
		}
		
		if(index == 0) {
			T value = start.getValue();
			start = start.getNext();
			size--;
			return value;
		} else {
			ListNode<T> remove = start;
			for(int i = 0; i < index - 1; i++) {
				remove = remove.getNext();
			}
			
			T value = (T)remove.getNext().getValue();
			remove.setNext(remove.getNext().getNext());
			size--;
			return value;
		}
	}
	
	public void add(int index, T value) {
		if(index < 0) { throw new ArrayIndexOutOfBoundsException(); }
		if(size == 0) {
			if(index != 0) { throw new ArrayIndexOutOfBoundsException(); }
			start.setValue(value);
			size++;
		} else if(index == 0) {
			ListNode<T> temp = new ListNode<T>(value, start);
			start = temp;
			size++;
		} else {
			ListNode<T> node = start;
			for(int i = 0; i < index - 1; i++) {
				node = node.getNext();
				if(node == null) { throw new ArrayIndexOutOfBoundsException(); }
			}
			
			ListNode<T> temp = new ListNode<T>(value, node.getNext());
			node.setNext(temp);
			size++;
		}
	}
	
	public void add(T value) {
		add(size, value);
	}

	public String toString() {
		String s = "[";
		ListNode<T> current = start;
		while(true) {
			if(current.getNext() == null) {
				s += current.getValue() + "] " + size;
				return s;
			}
			
			s += current.getValue() + ", ";
			current = current.getNext();
		}
	}
	
	public int getSize() {
		return size;
	}
}

class ListNode<T> {
	
	private T value;
	private ListNode next;
	
	public ListNode(T t, ListNode n) {
		value = t;
		next = n;
	}
	
	public void setNext(ListNode next) {
		this.next = next;
	}
	
	public void setValue(T t) {
		value = t;
	}
	
	public ListNode getNext() {
		return next;
	}
	
	public T getValue() {
		return value;
	}
}

class Letter {
	
	private char c;
	private int count;
	private Letter next;
	
	public Letter(char c) {
		this.c = c;
		count = 1;
		next = null;
	}
	
	public void setNext(Letter l) {
		next = l;
	}
	
	public Letter getNext() {
		return next;
	}
	
	public void addOne() {
		count++;
	}
	
	public char getChar() {
		return c;
	}
	
	public String toString() {
		return c + " - " + count;
	}
}
