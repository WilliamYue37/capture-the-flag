import java.util.*;
import java.io.*;

public class MapLabs {
    
    public static void main(String[] args) {
    	 //englishToSpanish("S:\\Computer Science 3\\CS3 1st 9 weeks\\Maps\\spantoeng.dat");
    	 countChars("gsdgsknKES$nsfgsgfdfdf");
    	 //printFam("S:\\Computer Science 3\\CS3 1st 9 weeks\\Maps\\relatives.dat");
    	 //acronyms("S:\\Computer Science 3\\CS3 1st 9 weeks\\Maps\\acro.dat");
    }
    
    private static void acronyms(String path) {
    	String[] data = readFile(path).split("\n");
    	Map<String, String> acro = new HashMap<String, String>();
    	for(int i = 1; i < Integer.parseInt(data[0].substring(0, data[0].length() - 1)) + 1; i++) {
    		String s = data[i];
    		String[] a = s.split(" ");
    		String b = "";
    		for(int j = 2; j < a.length; j++) {
    			b += a[j] + " ";
    		}
    		acro.put(a[0],b);
    	}
    	
    	int start = Integer.parseInt(data[0].substring(0, data[0].length() - 1));
    	for(int i = start; i < data.length; i++) {
    		String[] line = data[i].split(" ");
    		for(String word : line) {
    			boolean addPeriod = false;
    			String other = acro.get(word);
    			if(other == null) {
    				other = acro.get(" " +word);
    			} if(other == null && word.length() - 1 >= 0) {
    				other = acro.get(word.substring(0,word.length() - 1));
    				addPeriod = true;
    			}
    			
    			if(other == null) {
    				System.out.print(word + " ");
    			} else {
    				System.out.print(other);
    				if(addPeriod) {
    					System.out.print(".");
    				}
    			}
    		}
    		System.out.println();
    	}
    	
    	System.out.println(acro);
    }
    
    private static void printFam(String path) {
    	String[] tokens = readFile(path).split(" ");
    	int size = Integer.parseInt(tokens[0]);
    	Set<String> names = new TreeSet<String>();
    	Map<String, Set<String>> map = new TreeMap<String, Set<String>>();
    	for(int i = 0; i < size; i++) {
    		String name = tokens[i * 2 + 1];
    		names.add(name);
    		String relative = tokens[i * 2 + 2];
    		if(map.get(name) == null) {
    			Set<String> relatives = new HashSet<String>();
    			relatives.add(relative);
    			map.put(name, relatives);
    		} else {
    			map.get(name).add(relative);
    		}
    	}
    	
    	for(String name : names) {
    		Set<String> relatives = map.get(name);
    		System.out.print(name + " is related to ");
    		for(String relative : relatives) {
    			System.out.print(relative + " ");
    		}
    		System.out.println();
    	}
    }
    
    private static void countChars(String data) {
    	Set<Character> allChars = new TreeSet<Character>();
    	Map<Character, Integer> chars = new TreeMap<Character, Integer>();
    	for(int i = 0; i < data.length(); i++) {
    		char c = data.charAt(i);
    		if(allChars.add(c)) {
    			chars.put(c, 1);
    		} else {
    			chars.put(c, chars.get(c) + 1);
    		}
    	}
    	
    	for(char c : allChars) {
    		System.out.print(c + " ");
    		for(int i = 0; i < chars.get(c); i++) {
    			System.out.print("*");
    		}
    		System.out.println();
    	}
    }
    
    private static String readFile(String path) {
    	try {
	    	String data = "";
	    	Scanner file = new Scanner(new File(path));
			while(file.hasNext()) {
		     	data += file.nextLine() + " \n";
			}
			return data;
    	} catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }
    
    private static void englishToSpanish(String path) {
    	String[] tokens = readFile(path).split(" ");
    	int numWords = Integer.parseInt(tokens[0]);
    	int translateIndex = numWords * 2 + 1;
    	Map<String, String> words = new HashMap<String, String>();
    	for(int i = 0; i < numWords; i++) {
    		String span = tokens[i * 2 + 1];
    		String eng = tokens[i * 2 + 2];
    		words.put(span.trim(), eng);
    	}
    	
    	System.out.println(words);
    	
    	for(int i = translateIndex; i < tokens.length; i++) {
    		System.out.println(words.get(tokens[i].trim()));
    	}
    }
}
