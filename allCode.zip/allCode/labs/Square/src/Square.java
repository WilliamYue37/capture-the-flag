import java.util.*;
import javax.swing.*;
import java.awt.Point;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.image.*;

public class Square extends JPanel {
    
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    
    private static JFrame frame;
    
    public static void main(String[] args) {
    	gcf(5, 6);
    	gcf(3, 3);
    	gcf(2, 8);
    	
    	System.out.println("------------\n----------\n\n\n\n\n");
    	
    	oddCounter(Integer.MAX_VALUE, 4);
    	
    	System.out.println("------------\n----------\n\n\n\n\n");
    	
    	runChick("chicken");
    	runChick("chickenachchickenicken");
    	
    	System.out.println("------------\n----------\n\n\n\n\n");
    	
    	runLucky7(4, Integer.MAX_VALUE);
    	
    	System.out.println("------------\n----------\n\n\n\n\n");
    	
    	Counter.runCounter();
    	
		frame = createFrame();
		Square s = new Square();
		frame.add(s);
		
		long lastTime = System.currentTimeMillis();
		while(System.currentTimeMillis() - lastTime < 3000) {}
		s.fac();
    }
    
    private static JFrame createFrame() {
    	JFrame frame = new JFrame("Square");
		frame.setSize(WIDTH, HEIGHT + 200);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setFocusable(true);
		//frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return frame;
    }
    
    private static void runLucky7(int times, int size) {
    	int num = 577474777;
    	for(int i = 0; i < times; i++) {
    		System.out.println(num + " has a Lucky7 of " + lucky7(num, false));
    		num = (int)(Math.random() * size);
    	}
    }
    
    private static int lucky7(int num, boolean lastFirst7) {
    	if(num == 0) { return 0; }
    	if(num % 10 == 7) {
    		if(lastFirst7) {
    			return 13 + lucky7(num / 10, false);
    		} else {
    			return 1 + lucky7(num / 10, true);
    		}
    	} else {
    		return lucky7(num / 10, false);
    	}
    }
    
    private static void runChick(String word) {
    	System.out.println(word + " has chicken " + removeChicken(word) + " times");
    }
    
 	private static int removeChicken(String string) {
 		int index = string.indexOf("chicken");
 		if(index < 0) { return 0; }
 		String removed = string.substring(0, index) + string.substring(index + 7, string.length());
 		return 1 + removeChicken(removed);
 	}
    
    private static void oddCounter(int size, int times) {
    	for(int i = 0; i < times; i++) {
    		int num = (int)(Math.random() * size);
    		System.out.println("There are " + countOddDigits(num) + " in " + num);
    	}
    }
    
    private static int countOddDigits(int num) {
    	if(num == 0) { return 0; }
    	return num % 2 + countOddDigits(num / 10);
    }
    
    private static void gcf(int x, int y) {
    	System.out.println("GCF of " + x + " and " + y + " is " + gcfCal(x, y));
    }
    
    private static int gcfCal(int x, int y) {
    	int r = x % y;
    	if(r == 0) {
    		return y;
    	} else {
    		return gcfCal(y, r);
    	}
    }
    
   	private void fac() {
   		fac = true;
   		repaint();
   	}
    
    private Square() {
    	repaint();
    }
    
    private boolean fac = false;
    public void paint(Graphics g) {
    	if(fac) {
    		Fractal fac = new Fractal(g);
    	} else {
	    	g.setColor(Color.WHITE);
	    	g.fillRect(0, 0, WIDTH, HEIGHT + 200);
	    	g.setColor(Color.BLACK);
	    	drawSquare(g, 10, 10, 200);
    	}
    }
    
    private void drawSquare(Graphics g, int x, int y, int size) {
    	g.fillRect(x, y, size, size);
    	g.fillRect(WIDTH - x, HEIGHT - y * 2 - size, size, size);
    	if(size > 0)
    		drawSquare(g, x + size + 4, y, size * 3 / 4);
    }
}

class Counter {
	
	private static final int SIZE = 5;
	private char[][] matrix = new char[SIZE][SIZE];
	
	private Counter() {
		for(int x = 0; x < SIZE; x++) {
			for(int y = 0; y < SIZE; y++) {
				matrix[x][y] = ((int)(Math.random() * 2) == 0) ? '@' : '-';
			}
		}
	}
	
	public static void runCounter() {
		Counter counter = new Counter();
		counter.printMat();
		for(int i = 0; i < 4; i++) {
			int x = (int)(Math.random() * SIZE);
			int y = (int)(Math.random() * SIZE);
			counter.printConnection(x, y);
		}
	}
	
	private boolean isValidConnection(int x, int y, char c, List<Point> connected) {
		if(x < 0 || x >= SIZE || y < 0 || y >= SIZE) { return false; }
		
		for(Point connection : connected) {
			if(connection.x == x && connection.y == y) {
				return false;
			}
		}
		
		return matrix[x][y] == c;
	}
	
	private int calConnection(int x, int y, char c, List<Point> connected) {
		if(isValidConnection(x, y, c, connected)) {
			connected.add(new Point(x, y));
			return calConnection(x-1, y, c, connected) + calConnection(x+1, y, c, connected) + calConnection(x, y-1, c, connected) + calConnection(x, y+1, c, connected) + 1;
		}
		
		return 0;
	}
	
	private void printConnection(int x, int y) {
		char c = matrix[x][y];
		List<Point> connected = new ArrayList<Point>();
		int connection = calConnection(x, y, c, connected);
		System.out.println(x + ", " + y + " has " + connection + ":" + matrix[x][y]);
	}
	
	private void printMat() {
		for(int x = 0; x < SIZE; x++) {
			for(int y = 0; y < SIZE; y++) {
				System.out.print(matrix[x][y]);
			}
			System.out.println();
		}
	}
}

class Fractal {
	
	private int width = Square.WIDTH;
	private int height = Square.HEIGHT;
	
	public Fractal(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, width, height);
		drawSquare(g, width / 8 * 3, height / 8 * 3, width / 4, height / 4, ALL);
	}
	
	private static final int TOP_LEFT = 0;
	private static final int TOP_RIGHT = 1;
	private static final int BOTTOM_LEFT = 2;
	private static final int BOTTOM_RIGHT = 3;
	private static final int ALL = 4;

	private void drawSquare(Graphics g, int x, int y, int width, int height, int side) {
		g.setColor(Color.BLACK);
		g.fillRect(x, y, width, height);

		if(width / 2 == 0 || height / 2 == 0) {
			return; 
		}
		
		if(side != TOP_LEFT) drawSquare(g, x - width / 2, y - height / 2, width / 2, height / 2, BOTTOM_RIGHT);
		if(side != TOP_RIGHT) drawSquare(g, x - width / 2, y + height, width / 2, height / 2, BOTTOM_LEFT);
		if(side != BOTTOM_LEFT) drawSquare(g, x + width, y - height / 2, width / 2, height / 2, TOP_RIGHT);
		if(side != BOTTOM_RIGHT) drawSquare(g, x + width, y + height, width / 2, height / 2, TOP_LEFT);
	}
}
