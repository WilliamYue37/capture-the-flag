import java.util.*;
import java.awt.*;
import java.io.*;

public class SortByAge {
    
    public static void main(String[] args) {
    	Scanner in;
    	try {
    		in = new Scanner(new File("S:\\Computer Science 3\\CS3 1st 9 weeks\\Interfaces\\lab06_interfaces\\person.dat"));
    	} catch(Exception e) {
    		in = null;
    		e.printStackTrace();
    	}
    	
    	int size = in.nextInt();
    	Student[] kids = new Student[size];
    	for(int i = 0; i < size; i++) {
    		int year = in.nextInt();
    		int month = in.nextInt();
    		int day = in.nextInt();
    		String name = in.next();
    		kids[i] = new Student(year, month, day, name);
    	}
    	
    	System.out.println(Arrays.toString(kids));
    	System.out.println("----------");
    	Arrays.sort(kids);
    	System.out.println(Arrays.toString(kids));
    }
}

class Student implements Comparable<Student> {
	
	private int m_year;
	private int m_month;
	private int m_day;
	private String m_name;
	
	public Student(int year, int month, int day, String name) {
		m_year = year;
		m_month = month;
		m_day = day;
		m_name = name;
	}
	
	public int compareTo(Student other) {
		if(m_year != other.m_year) {
			return other.m_year - m_year;
		}
		
		if(m_month != other.m_month) {
			return other.m_month = m_month;
		}
		
		if(m_day != other.m_day) {
			return other.m_day - m_day;
		}

		return m_name.compareTo(other.m_name);
	}
	
	public String toString() {
		return m_name;
	}
}
