import java.util.*;

public class QueueLabs {
    
    public static void main(String[] args) {
    	basics("one one two one one");
    	System.out.println("----------------");
    	monster();
    }
    
    private static void basics(String data) {
    	MyQueue<String> queue = new MyQueue<String>();
    	Stack<String> stack = new Stack<String>();
    	String[] tokens = data.split(" ");
    	for(String s : tokens) {
    		queue.add(s);
    		stack.push(s);
    	}
    	
    	while(!queue.isEmpty()) {
    		String a = queue.remove();
    		String b = stack.pop();
    		if(!a.equals(b)) {
    			System.out.println(data + " is NOT a palidrome");
    			return;
    		}
    	}
    	
    	System.out.println(data + " is a palidrome");
    }
        
    private static void monster() {
    	PriorityQueue pq = new PriorityQueue<Monster>();
    	
    	for(int i = 0; i < 10; i++) {
    		pq.add(new Monster((int)(Math.random() * 40)));
    	}
    	
    	while(!pq.isEmpty()) {
    		System.out.println(pq.remove());
    	}
    }
}

class Monster implements Comparable<Monster> {
	
	private int size;
	
	public Monster(int size) {
		this.size = size;
	}
	
	public int compareTo(Monster that) {
		return ((Integer)that.size).compareTo(this.size);
	}
	
	public String toString() {
		return size + "";
	}
}

class MyQueue<E> {
	
	private ArrayList<E> data;
	
	public MyQueue() {
		data = new ArrayList<E>();
	}
	
	public void add(E e) {
		data.add(e);
	}
	
	public E remove() {
		return data.remove(0);
	}
	
	public boolean isEmpty() {
		return data.isEmpty();
	}
	
	public E peek() {
		return data.get(0);
	}
	
	public void clear() {
		data.clear();
	}
}

