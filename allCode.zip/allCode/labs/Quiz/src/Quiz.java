import java.util.Arrays;

public class Quiz {
    
    public static void main(String[] args) {
    	String[] words = { "HELLo", "this", "yellow", "this", "hello" };
    	testMethod(words);
    	String[] w = {};
    	testMethod(w);
    	String[] w1 = { "hey" };
    	testMethod(w1);
    	String[] w2 = { "five", "song", "red", "five" };
    	testMethod(w2);
    	String[] words1 = { "six", "seven", "six", "blue" };
    	testMethod(words1);
    }
    
    private static void testMethod(String[] words) {
    	System.out.print(Arrays.toString(words));
    	if(isPalindrome(words)) {
    		System.out.println(" is a palindrome");
    	} else {
    		System.out.println(" is NOT a palindrome");
    	}
    }
    
    private static boolean isPalindrome(String[] words) {
    	for(int i = 0; i < words.length / 2; i++) {
    		if(!words[i].toLowerCase().equals(words[words.length - i - 1].toLowerCase())) {
    			return false;
    		}
    	}
    	return true;
    }
}
