import java.util.*;
public class ArrayListQuiz
{
	public static void main (String args[])
	{
		ArrayList <String> sample = new ArrayList<String>();
		sample.add("Did");sample.add("you");sample.add("solve");sample.add("it");sample.add("or");sample.add("what?");
		//Complete the method removeEvens below
		System.out.println("\n"+sample);
		removeEvenLength(sample);
		System.out.println("Removing Strings of even length\n"+sample);

		//Complete the method maxLength
		sample.clear();
		System.out.println("\n"+sample);
		System.out.println("maxLength for an empty list is:  "+maxLength(sample));
		sample.add("to");sample.add("be");sample.add("or");	sample.add("not");sample.add("to");	sample.add("be");sample.add("hamlet");
	    System.out.println("\n"+sample);
		System.out.println("maxLength is:  "+maxLength(sample));
		sample.clear();
		sample.add("Only one really long string");
		System.out.println("\n"+sample);
		System.out.println("maxLength is:  "+maxLength(sample));

		sample.clear();

		// complete the method swapPairs
		sample.add("four");sample.add("score");sample.add("and");sample.add("seven");sample.add("years");sample.add("ago");
		System.out.println("\n"+sample);
		swapPairs(sample);
		System.out.println("\n\n after swapping pairs");
		System.out.println(sample);
		
		sample.clear();

		sample.add("This");sample.add("is");sample.add("lots");
		sample.add("of");sample.add("fun");sample.add("for");
		sample.add("every");sample.add("java");sample.add("programmer");
		System.out.println("\n"+sample);
		markLength4(sample);
		System.out.println("After a call to stutter\n");
		System.out.println(sample+"\n");

	}
	//Write a method removeEvenLength that takes an ArrayList of Strings as a parameter and
	//that removes all of the strings of even length from the list.

	public static void  removeEvenLength(ArrayList<String> list)
	{
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).length() % 2 == 0) {
				list.remove(i--);
			}
		}
	
	
    }

   //Write a method maxLength that takes an ArrayList of Strings as a parameter and
   //that returns the length of the longest string in the list. If your method is passed an empty list, it should return 0.


	public static int maxLength(ArrayList <String> list)
	{
		int max = 0;
		
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).length() > max) {
				max = list.get(i).length();
			}
		}
		
		return max;
	
	}

	//Write a method swapPairs that switches the order of values in an ArrayList of Strings in a pairwise fashion.
	// Your method should switch the order of the first two values, then switch the order of the next two,
	// switch the order of the next two, and so on.
	//For example, if the list initially stores these values: {"four", "score", "and", "seven", "years", "ago"}
	// your method should switch the first pair, "four", "score", the second pair, "and", "seven",
	// and the third pair, "years", "ago", to yield this list: {"score", "four", "seven", "and", "ago", "years"}

	//If there are an odd number of values in the list, the final element is not moved.
	// For example, if the original list had been: {"to", "be", "or", "not", "to", "be", "hamlet"}It would again switch pairs
	// but the final value, "hamlet" would not be moved, yielding this list: {"be", "to", "not", "or", "be", "to", "hamlet"}

	public static void  swapPairs(ArrayList<String> list)
	{
		for(int i = 0; i < list.size() / 2; i++) {
			String s = list.get(i * 2);
			list.set(i * 2, list.get(i * 2 + 1));
			list.set(i * 2 + 1, s);
		}	

    }
    
    
   //Complete the method stutter below. Stutter takes an ArrayList of Strings and an integer k as parameters
   //and that replaces every string with k copies of that string.
   //For example, if the list stores the values ["how", "are", "you?"]
   // before the method is called and k is 4
   //it should store the values ["how", "how", "how", "how", "are", "are", "are", "are", "you?", "you?", "you?", "you?"]
   // after the method finishes executing. If k is 0 or negative, the list should be empty after the call.

 	public static void  stutter(ArrayList<String> list, int k)
	{
		for(int i = list.size() - 1; i >= 0; i++) {
			String s = list.get(i);
			for(int j = 1; j < k; j++) {
				list.add(i, s);
			}
		}
    }
    //Write a method markLength4 that takes an ArrayList of Strings as a parameter and
	//that places a string of four asterisks "****" in front of every string of length 4.
	// For example, suppose that a variable called list contains the following values:
	// {"this", "is", "lots", "of", "fun", "for", "every", "Java", "programmer"}
	// And you make the following call: markLength4(list); then list should store the following values
	//after the call: {"****", "this", "is", "****", "lots", "of", "fun", "for", "every", "****", "Java", "programmer"}
	//Notice that you leave the original strings in the list, "this", "lots", "Java",
	// but include the four-asterisk string in front of each to mark it.

    public static void  markLength4(ArrayList<String> list)
	{
		for(int i = 0; i < list.size(); i++) {
			if(list.get(i).length() == 4) {
				list.add(i++, "****");
			}
		}
    }


}