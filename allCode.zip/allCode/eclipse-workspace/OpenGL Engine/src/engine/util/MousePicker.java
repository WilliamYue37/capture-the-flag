package engine.util;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import engine.graphics.Camera;
import engine.graphics.Renderer;

public class MousePicker {

	private static Vector3f currentRay;
	private static Matrix4f projectionMatrix;
	private static Matrix4f viewMatrix;
	private static Camera camera;
	
	public static void createMousePicker(Camera camera) {
		MousePicker.camera = camera;
		projectionMatrix = Renderer.getProjectionMatrix();
		update();
	}

	public static Vector3f getCurrentRay() {
		return currentRay;
	}
	
	public static void update() {
		viewMatrix = camera.toMatrix();
		currentRay = calculateMouseRay();
	}
	
	private static Vector3f calculateMouseRay() {
		Vector2f normalizedDeviceMouseCoords = getNormalizedDeviceCoords(Mouse.getX(), Mouse.getY());
		Vector4f clipCoords = new Vector4f(normalizedDeviceMouseCoords.x, normalizedDeviceMouseCoords.y, -1, 1);
		Vector4f eyeCoords = toEyeCoords(clipCoords);
		Vector3f worldRay = toWorldCoords(eyeCoords);
		return worldRay;
	}
	
	private static Vector3f toWorldCoords(Vector4f eyeCoords) {
		Matrix4f inverseView = Matrix4f.invert(viewMatrix, null);
		Vector4f rayWorld = Matrix4f.transform(inverseView, eyeCoords, null);
		Vector3f mouseRay = new Vector3f(rayWorld.x, rayWorld.y, rayWorld.z);
		mouseRay.normalise();
		return mouseRay;
	}
	
	private static Vector4f toEyeCoords(Vector4f clipCoords) {
		Matrix4f inverseProjection = Matrix4f.invert(projectionMatrix, null);
		Vector4f eyeCoords = Matrix4f.transform(inverseProjection, clipCoords, null);
		return new Vector4f(eyeCoords.x, eyeCoords.y, -1, 0);
	}
	
	private static Vector2f getNormalizedDeviceCoords(float mouseX, float mouseY) {
		float x = mouseX / Display.getWidth() * 2 - 1;
		float y = mouseY / Display.getHeight() * 2 - 1;
		return new Vector2f(x, y);
	}
}
