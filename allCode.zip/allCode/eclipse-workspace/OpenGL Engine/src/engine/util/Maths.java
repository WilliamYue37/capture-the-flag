package engine.util;

import org.lwjgl.util.vector.Vector3f;

public class Maths {

	public static final Vector3f X_AXIS = new Vector3f(1, 0, 0);
	public static final Vector3f Y_AXIS = new Vector3f(0, 1, 0);
	public static final Vector3f Z_AXIS = new Vector3f(0, 0, 1);
	
	public static final Vector3f UP = Y_AXIS;
	public static final Vector3f DOWN = new Vector3f(0, -1, 0);
	public static final Vector3f LEFT = new Vector3f(-1, 0, 0);
	public static final Vector3f RIGHT = X_AXIS;
	public static final Vector3f FORWARD = new Vector3f(0, 0, -1);
	public static final Vector3f BACKWARD = Z_AXIS;
	
	public static Vector3f mul(Vector3f a, Vector3f b, Vector3f c) {
		float x = a.x * b.x;
		float y = a.y * b.y;
		float z = a.z * b.z;
		
		if(c != null) {
			c.set(x, y, z);
		}
		
		return new Vector3f(x, y, z);
	}
	
	public static Vector3f div(Vector3f a, Vector3f b, Vector3f c) {
		float x = a.x / b.x;
		float y = a.y / b.y;
		float z = a.z / b.z;
		
		if(c != null) {
			c.set(x, y, z);
		}
		
		return new Vector3f(x, y, z);
	}
	
	public static final int X = 0;
	public static final int Y = 1;
	public static final int Z = 2;
	public static float getDimension(Vector3f vector, int dimension) {
		if(dimension == X) {
			return vector.x;
		} if(dimension == Y) {
			return vector.y;
		} if(dimension == Z) {
			return vector.z;
		}
		
		return 0;
	}
}
