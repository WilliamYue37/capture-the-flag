package engine.graphics;

import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Cursor;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ContextAttribs;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.PixelFormat;

import engine.model.Loader;

public class DisplayManager {

	// TODO, work on fixed mouse types, make GIUS once gui shader aviable, add scaling and other effects
	
	private static final int FPS_CAP = 120;

	private static long lastFrameTime;
	private static int frameTimeMillis;
	private static float frameTimeSeconds;

	private static int mouseDX;
	private static int mouseDY;
	
	public static void createDisplay(int width, int height, String title) {
		try {
			Display.setDisplayMode(new DisplayMode(width, height));
			ContextAttribs attribs = new ContextAttribs(3, 3)
					.withForwardCompatible(true)
					.withProfileCore(true);
			Display.create(new PixelFormat().withDepthBits(24), attribs);
			Display.setTitle(title);
			GL11.glViewport(0, 0, width, height);
			
			createCursors();
		} catch(LWJGLException e) {
			e.printStackTrace();
		}
	}

	private static void createCursors() throws LWJGLException {
		defaultCursor = Mouse.getNativeCursor();
		
		int size = 16;
		int border = 2;
		
		int[] cross = new int[size * size];
		int[] circle = new int[size * size];
		int[] x = new int[size * size];
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < size; j++) {
				if(Math.abs(size / 2 - i) <= border / 2 || Math.abs(size / 2 - j) <= border / 2) {
					cross[i * size + j] = 0xff000000;
				}

				if(Math.abs(i - j) <= border / 2 || Math.abs(i - size + j) <= border / 2) {
					x[i * size + j] = 0xff000000;
				}
			}
		}
		
		for(int angle = 0; angle < 360; angle++) {
			int i = (int)(Math.cos(Math.toRadians(angle)) * size / 2) + size / 2;
			int j = (int)(Math.sin(Math.toRadians(angle)) * size / 2) + size / 2;
			if(i * size + j > 0 && i * size + j < size * size) {
				circle[i * size + j] = 0xff000000;
			}
		}
		
		CROSS = createCursor(size, cross);
		CIRCLE = createCursor(size, circle);
		X = createCursor(size, x);
		BLANK = fixedCursor = createCursor(1, new int[] { 0x00000000 });
	}

	private static Cursor createCursor(int size, int[] image) throws LWJGLException {
		IntBuffer buffer = BufferUtils.createIntBuffer(size * size);
		buffer.put(image);
		buffer.flip();
		return new Cursor(size, size, size / 2, size / 2, 1, buffer, null);
	}
	
	public static Cursor CROSS;
	public static Cursor CIRCLE;
	public static Cursor X;
	public static Cursor BLANK;
	public static void setFixedCursorType(Cursor cursor) {
		fixedCursor = cursor;
		if(cursorFixed) {
			setCursor(cursor);
		}
	}
	
	private static boolean cursorFixed = false;
	private static Cursor defaultCursor;
	private static Cursor fixedCursor;
	public static void setCursorFixed(boolean fixed) {
		cursorFixed = fixed;
		setCursor(fixed ? fixedCursor : defaultCursor);
	}
	
	private static void setCursor(Cursor cursor) {
		try {
			Mouse.setNativeCursor(cursor);
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
	}

	private static void updateCursor() {
		if(cursorFixed) {
			mouseDX = Mouse.getX() - Display.getWidth() / 2;
			mouseDY = Mouse.getY() - Display.getHeight() / 2;
			Mouse.setCursorPosition(Display.getWidth() / 2, Display.getHeight() / 2);
		} else {
			mouseDX = Mouse.getDX();
			mouseDY = Mouse.getDY();
		}
	}
	
	public static void updateDisplay() {
		Display.sync(FPS_CAP);
		Display.update();
		
		long currentTime = getCurrentTimeMillis();
		frameTimeMillis = (int)(currentTime - lastFrameTime);
		frameTimeSeconds = frameTimeMillis / 1000f;
		lastFrameTime = currentTime;
		
		updateCursor();
	}
	public static void closeDisplay() {
		Renderer.destroy();
		Loader.destroy();
		Display.destroy();
	}
	
	public static long getCurrentTimeMillis() {
		return Sys.getTime() * 1000 / Sys.getTimerResolution();
	}
	
	public static int getFrameTimeMillis() {
		return frameTimeMillis;
	}
	
	public static float getFrameTimeSeconds() {
		return frameTimeSeconds;
	}

	public static boolean isCursorFixed() {
		return cursorFixed;
	}
	
	public static int getMouseDX() {
		return mouseDX;
	}
	
	public static int getMouseDY() {
		return mouseDY;
	}
}
