package engine.graphics;

import org.lwjgl.util.vector.Vector3f;

public class Light {

	private Vector3f position;
	private Vector3f direction;
	private Vector3f color;
	
	public Light(Vector3f vector, Vector3f color, boolean directional) {
		this.color = color;
		if(directional) {
			direction = vector;
		} else { // point
			position = vector;
		}
	}

	public Vector3f getPosition() {
		return position;
	}
	
	public Vector3f getColor() {
		return color;
	}
	
	public Vector3f getDirection() {
		return direction;
	}
}
