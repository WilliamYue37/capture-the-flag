package engine.graphics;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import engine.util.MousePicker;

public class Renderer {

	public static final Vector3f WHITE = new Vector3f(1, 1, 1);
	public static final Vector3f BLACK = new Vector3f(0, 0, 0);
	public static final Vector3f RED = new Vector3f(1, 0, 0);
	public static final Vector3f GREEN = new Vector3f(0, 1, 0);
	public static final Vector3f BLUE = new Vector3f(0, 0, 1);
	
	public static void createRenderer(Camera camera, float red, float green, float blue) {
		createRenderer((float)Math.toRadians(70), 0.01f, 1000, camera, red, green, blue);
	}
	
	protected static Camera camera;
	protected static float red;
	protected static float green;
	protected static float blue;
	public static void createRenderer(float fov, float nearPlane, float farPlane, Camera camera, float red, float green, float blue) {
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthFunc(GL11.GL_LESS);
		
		Renderer.camera = camera;
		createProjectionMatrix(fov, nearPlane, farPlane);
		Renderer.red = red;
		Renderer.green = green;
		Renderer.blue = blue;
		
		MousePicker.createMousePicker(camera);
	}
	
	protected static Matrix4f projectionMatrix;
	private static void createProjectionMatrix(float fov, float nearPlane, float farPlane) {
		float aspectRatio = (float) Display.getWidth() / Display.getHeight();
		float yScale = 1 / (float) Math.tan(fov / 2);
		float xScale = yScale / aspectRatio;
		float frustumLength = farPlane - nearPlane;
		
		projectionMatrix = new Matrix4f();
		projectionMatrix.m00 = xScale;
		projectionMatrix.m11 = yScale;
		projectionMatrix.m22 = -((farPlane + nearPlane) / frustumLength);
		projectionMatrix.m23 = -1;
		projectionMatrix.m32 = -2 * farPlane * nearPlane / frustumLength;
		projectionMatrix.m33 = 0;
	}
	
	public static Matrix4f getViewMatrix() {
		return camera.toMatrix();
	}
	
	public static Matrix4f getProjectionMatrix() {
		return projectionMatrix;
	}
	
	public static void prepare() {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glClearColor(red, green, blue, 1);
	}
	
	private static boolean cullingEnabled = false;
	protected static void setCulling(boolean cull) {
		if(cullingEnabled != cull) {
			if(cull) {
				GL11.glEnable(GL11.GL_CULL_FACE);
				GL11.glCullFace(GL11.GL_BACK);
			} else {
				GL11.glDisable(GL11.GL_CULL_FACE);
			}
			
			cullingEnabled = cull;
		}
	}

	private static boolean blendEnabled = false;
	protected static void setBlend(boolean blend) {
		if(blendEnabled != blend) {
			if(blend) {
				GL11.glEnable(GL11.GL_BLEND);
				GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
			} else {
				GL11.glDisable(GL11.GL_BLEND);
			}
			
			blendEnabled = blend;
		}
	}

	private static List<ShaderProgram> programs = new ArrayList<ShaderProgram>();
	protected static void addShaderProgram(ShaderProgram program) {
		programs.add(program);
	}
	
	protected static void destroy() {
		for(ShaderProgram program : programs) {
			program.destroy();
		}
	}
}
