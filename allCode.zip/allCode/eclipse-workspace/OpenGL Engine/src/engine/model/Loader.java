package engine.model;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class Loader {

	private static List<Integer> textures = new ArrayList<Integer>();
	private static List<Integer> vaos = new ArrayList<Integer>();
	private static List<Integer> vbos = new ArrayList<Integer>();
	
	private static int currentVao;
	private static boolean hasIndexBuffer;
	private static int numVbos;
	
	public static void createVAO() {
		hasIndexBuffer = false;
		numVbos = 0;
		currentVao = GL30.glGenVertexArrays();
		GL30.glBindVertexArray(currentVao);
		vaos.add(currentVao);
	}
	
	public static void bindIndicesBuffer(List<Integer> indices) {
		int[] ind = new int[indices.size()];
		for(int i = 0; i < indices.size(); i++) {
			ind[i] = indices.get(i);
		}
		
		bindIndicesBuffer(ind);
	}
	
	public static void bindIndicesBuffer(int[] indices) {
		hasIndexBuffer = true;
		int vboID = GL15.glGenBuffers();
		vbos.add(vboID);
		GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, vboID);
		IntBuffer buffer = storeDataInIntBuffer(indices);
		GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
	}
	
	public static void storeVec2DataInAttributeList(int attributeNumber, List<Vector2f> data) {
		float[] d = new float[data.size() * 2];
		for(int i = 0; i < data.size(); i++) {
			d[i * 2] = data.get(i).x;
			d[i * 2 + 1] = data.get(i).y;
		}
		
		storeFloatDataInAttributeList(attributeNumber, d, 2);
	}
	
	public static void storeVec3DataInAttributeList(int attributeNumber, List<Vector3f> data) {
		float[] d = new float[data.size() * 3];
		for(int i = 0; i < data.size(); i++) {
			d[i * 3] = data.get(i).x;
			d[i * 3 + 1] = data.get(i).y;
			d[i * 3 + 2] = data.get(i).z;
		}
		
		storeFloatDataInAttributeList(attributeNumber, d, 3);
	}
	
	public static void storeFloatDataInAttributeList(int attributeNumber, float[] data, int dimensions) {
		numVbos++;
		int vboID = GL15.glGenBuffers();
		vbos.add(vboID);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vboID);
		FloatBuffer buffer = storeDataInFloatBuffer(data);
		GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
		GL20.glVertexAttribPointer(attributeNumber, dimensions, GL11.GL_FLOAT, false, 0, 0);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
	}

	public static Model finalize(int drawType, int drawCount) {
		GL30.glBindVertexArray(0);
		if(hasIndexBuffer) {
			return new Model(currentVao, drawCount, true, drawType, numVbos);
		} else {
			return new Model(currentVao, drawCount, false, drawType, numVbos);
		}
	}
	
	private static FloatBuffer storeDataInFloatBuffer(float[] data) {
		FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(data.length);
		floatBuffer.put(data);
		floatBuffer.flip();
		return floatBuffer;
	}
	
	private static IntBuffer storeDataInIntBuffer(int[] data) {
		IntBuffer intBuffer = BufferUtils.createIntBuffer(data.length);
		intBuffer.put(data);
		intBuffer.flip();
		return intBuffer;
	}
	
	public static String loadFile(String path, String lineSplit) {
		try {
			StringBuilder builder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader("res/" + path + ".txt"));
            String line;
            while((line = reader.readLine()) != null) {
                builder.append(line + lineSplit);
            }
            reader.close();
            return builder.toString();
        } catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static BufferedImage loadImage(String file) {
		try {
			return ImageIO.read(new File("res/" + file));
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	protected static int loadTexture(String file) {
		Texture texture = null;
		try {
			texture = TextureLoader.getTexture(file.substring(file.length() - 3).toUpperCase(), new FileInputStream("res/" + file));
			GL30.glGenerateMipmap(GL11.GL_TEXTURE_2D);
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR_MIPMAP_LINEAR);
			GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, 0);
		} catch(Exception e) {
			e.printStackTrace();
		}
		int textureID = texture.getTextureID();
		textures.add(textureID);
		return textureID;
	}
	
	public static void destroy() {
		for(int vao : vaos) {
			GL30.glDeleteVertexArrays(vao);
		} for(int vbo : vbos) {
			GL15.glDeleteBuffers(vbo);
		} for(int texture : textures) {
			GL11.glDeleteTextures(texture);
		}
	}
}
