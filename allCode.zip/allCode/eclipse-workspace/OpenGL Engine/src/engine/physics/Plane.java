package engine.physics;

import org.lwjgl.util.vector.Vector3f;

public class Plane {

	private Vector3f normal = new Vector3f();
	private float[] equation = new float[4];
	
	public Plane(Vector3f origin, Vector3f normal) {
		setEquation(normal.x, normal.y, normal.z, -Vector3f.dot(origin, normal));
	}
	
	public Plane(float a, float b, float c, float d) {
		setEquation(a, b, c, d);
	}
	
	public Vector3f projectToPlane(Vector3f point) {
		float distance = signedDistanceTo(point);
		Vector3f intersection = new Vector3f(normal);
		intersection.scale(distance);
		Vector3f.sub(point, intersection, intersection);
		return intersection;
	}
	
	public float signedDistanceTo(Vector3f point) {
		return equation[0] * point.x + equation[1] * point.y + equation[2] * point.z + equation[3];
	}
	
	public boolean contains(Vector3f point) {
		return signedDistanceTo(point) == 0;
	}
	
	private void setEquation(float a, float b, float c, float d) {
		normal.set(a, b, c);
		equation[0] = a;
		equation[1] = b;
		equation[2] = c;
		equation[3] = d;
	}

	public Vector3f projectRayToPlane(Vector3f origin, Vector3f ray) {
		float dot = Vector3f.dot(ray, normal);
		if(dot == 0) {
			if(contains(origin)) {
				return new Vector3f(origin);
			} else {
				return null;
			}
		}
		
		float f = -(Vector3f.dot(origin, normal) + equation[3]) / dot;
		Vector3f point = new Vector3f(ray);
		point.scale(f);
		Vector3f.add(origin, point, point);
		return point;
	}
}
