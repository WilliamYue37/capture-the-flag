package engine.physics;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import engine.util.Maths;

public class AABB {
	
	public static final int TOP = 0;
	public static final int BOTTOM = 1;
	public static final int LEFT = 2;
	public static final int RIGHT = 3;
	public static final int FRONT = 4;
	public static final int BACK = 5;
	private Plane[] planes = new Plane[6];
	
	private Vector3f min;
	private Vector3f max;
	private Vector3f center;
	
	public AABB(Vector3f min, Vector3f max) {
		setPosition(min, max);
	}
	
	public void move(Vector3f offset) {
		Vector3f.add(min, offset, min);
		Vector3f.add(max, offset, max);
		createGeometry();
	}
	
	public void setPosition(Vector3f min, Vector3f max) {
		this.min = min;
		this.max = max;
		createGeometry();
	}
	
	private void createGeometry() {
		center = Vector3f.add(min, max, null);
		center.scale(0.5f);
		
		planes[TOP] = new Plane(max, Maths.UP);
		planes[BOTTOM] = new Plane(min, Maths.DOWN);
		planes[LEFT] = new Plane(min, Maths.LEFT);
		planes[RIGHT] = new Plane(max, Maths.RIGHT);
		planes[FRONT] = new Plane(min, Maths.FORWARD);
		planes[BACK] = new Plane(max, Maths.BACKWARD);
	}
	
	public Vector4f sweptCollision(AABB aabb, Vector3f velocity) {
		float xEntry, xExit;
		float yEntry, yExit;
		float zEntry, zExit;
		
		if(velocity.x > 0) {
			xEntry = (min.x - aabb.max.x) / velocity.x;
			xExit = (max.x - aabb.min.x) / velocity.x;
		} else if(velocity.x < 0) {
			xEntry = (max.x - aabb.min.x) / velocity.x;
			xExit = (min.x - aabb.max.x) / velocity.x;
		} else {
			if(aabb.min.x > max.x || aabb.max.x < min.x) { return new Vector4f(1, 1, 1, 1); }
			xEntry = -Float.MAX_VALUE;
			xExit = Float.MAX_VALUE;
		}
		
		if(velocity.y > 0) {
			yEntry = (min.y - aabb.max.y) / velocity.y;
			yExit = (max.y - aabb.min.y) / velocity.y;
		} else if(velocity.y < 0) {
			yEntry = (max.y - aabb.min.y) / velocity.y;
			yExit = (min.y - aabb.max.y) / velocity.y;
		} else {
			if(aabb.min.y > max.y || aabb.max.y < min.y) { return new Vector4f(1, 1, 1, 1); }
			yEntry = -Float.MAX_VALUE;
			yExit = Float.MAX_VALUE;
		}
		
		if(velocity.z > 0) {
			zEntry = (min.z - aabb.max.z) / velocity.z;
			zExit = (max.z - aabb.min.z) / velocity.z;
		} else if(velocity.z < 0) {
			zEntry = (max.z - aabb.min.z) / velocity.z;
			zExit = (min.z - aabb.max.z) / velocity.z;
		} else {
			if(aabb.min.z > max.z || aabb.max.z < min.z) { return new Vector4f(1, 1, 1, 1); }
			zEntry = -Float.MAX_VALUE;
			zExit = Float.MAX_VALUE;
		}
		
		float entry = Math.max(xEntry, Math.max(yEntry, zEntry));
		float exit = Math.min(xExit, Math.min(yExit, zExit));

		if(entry > exit || (xEntry < 0 && yEntry < 0 && zEntry < 0) || xEntry > 1 || yEntry > 1 || zEntry > 1) {
			return new Vector4f(1, 1, 1, 1);
		} else {
			if(xEntry > yEntry && xEntry > zEntry) {
				return new Vector4f(entry, 0, 1, 1);
			} else if(yEntry > zEntry) {
				return new Vector4f(entry, 1, 0, 1);
			} else {
				return new Vector4f(entry, 1, 1, 0);
			}
		}
	}
	
	public int faceOfPoint(Vector3f point) {
		for(int i = 0; i < planes.length; i++) {
			if(planes[i].contains(point)) {
				return i;
			}
		}
		
		return -1;
	}
	
	private boolean pointInOther(AABB aabb) {
		return aabb.contains(min) || aabb.contains(new Vector3f(min.x, min.y, max.z)) || aabb.contains(new Vector3f(min.x, max.y, min.z)) || aabb.contains(new Vector3f(max.x, min.y, min.z))
				|| aabb.contains(new Vector3f(max.x, max.y, min.z)) || aabb.contains(new Vector3f(min.x, max.y, max.z)) || aabb.contains(new Vector3f(max.x, min.y, max.z)) || aabb.contains(max);
	}
	
	public boolean intersects(AABB aabb) {
		return pointInOther(aabb) || aabb.pointInOther(this);
	}
	
	public boolean contains(Vector3f point) {
		if(point.x < min.x || point.y < min.y || point.z < min.z
				|| point.x > max.x || point.y > max.y || point.z > max.z) {
			return false;
		} else {
			return true;
		}
	}
	
	private boolean clipLine(Vector2f f, Vector3f origin, Vector3f ray, int d) {
		if(Maths.getDimension(ray, d) == 0) {
			return contains(origin);
		}
		
		float fDLow = (Maths.getDimension(min, d) - Maths.getDimension(origin, d)) / Maths.getDimension(ray, d);
		float fDHigh = (Maths.getDimension(max, d) - Maths.getDimension(origin, d)) / Maths.getDimension(ray, d);
		if(fDLow > fDHigh) { float temp = fDLow; fDLow = fDHigh; fDHigh = temp; }
		
		if(fDHigh < f.x) { return false; }
		if(fDLow > f.y) { return false; }
		f.x = Math.max(f.x, fDLow);
		f.y = Math.min(f.y, fDHigh);
		
		return f.x <= f.y;
	}
	
	public float getRayIntersection(Vector3f origin, Vector3f ray) {
		if(contains(origin)) { return 0; }
		Vector2f f = new Vector2f(0, 1);
		if(!clipLine(f, origin, ray, Maths.X)) { return -1; }
		if(!clipLine(f, origin, ray, Maths.Y)) { return -1; }
		if(!clipLine(f, origin, ray, Maths.Z)) { return -1; }
		return f.x;
	}
	
	public Vector3f getMin() {
		return min;
	}
	
	public Vector3f getMax() {
		return max;
	}
	
	public Vector3f getCenter() {
		return center;
	}
}
