package graphics;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Cursor;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ContextAttribs;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.PixelFormat;

public class DisplayManager {

	private static final int FPS_CAP = 120;
	
	private static long lastFrameTime;
	private static int frameTimeMillis;
	private static float frameTimeSeconds;
	
	private static Cursor inGameCursor;
	private static Cursor defaultCursor;
	private static boolean inGameCursorMode;
	
	private static int mouseDX;
	private static int mouseDY;
	
	public static void createDisplay(int width, int height, String title) {
		try {
			Display.setDisplayMode(new DisplayMode(width, height));
			ContextAttribs attribs = new ContextAttribs(3, 3)
					.withForwardCompatible(true)
					.withProfileCore(true);
			Display.create(new PixelFormat().withDepthBits(24), attribs);
			Display.setTitle(title);
			GL11.glViewport(0, 0, width, height);
			
			inGameCursor = new Cursor(1, 1, 0, 0, 1, BufferUtils.createIntBuffer(1), BufferUtils.createIntBuffer(1));
			defaultCursor = Mouse.getNativeCursor();
		} catch(LWJGLException e) {
			e.printStackTrace();
		}
	}
	
	public static void updateDisplay() {
		Display.sync(FPS_CAP);
		Display.update();
		
		long currentTime = getCurrentTimeMillis();
		frameTimeMillis = (int)(currentTime - lastFrameTime);
		frameTimeSeconds = frameTimeMillis / 1000f;
		lastFrameTime = currentTime;
		
		if(inGameCursorMode) {
			mouseDX = Mouse.getX() - Display.getWidth()/2;
			mouseDY = Mouse.getY() - Display.getHeight()/2;
			Mouse.setCursorPosition(Display.getWidth()/2, Display.getHeight()/2);
		}
	}
	
	public static void changeCursor(boolean inGame) {
		inGameCursorMode = inGame;
		if(inGame) {
			try {
				Mouse.setNativeCursor(inGameCursor);
			} catch (LWJGLException e) {
				e.printStackTrace();
			}
		} else {
			try {
				Mouse.setNativeCursor(defaultCursor);
			} catch (LWJGLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void closeDisplay() {
		Display.destroy();
	}
	
	public static long getCurrentTimeMillis() {
		return Sys.getTime() * 1000 / Sys.getTimerResolution();
	}
	
	public static int getFrameTimeMillis() {
		return frameTimeMillis;
	}
	
	public static float getFrameTimeSeconds() {
		return frameTimeSeconds;
	}
	
	public static int getMouseDX() {
		return mouseDX;
	}
	
	public static int getMouseDY() {
		return mouseDY;
	}
}
