package graphics;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;

import chunkShader.ChunkShader;

public class Renderer {

	private static Matrix4f projectionMatrix;
	private static Matrix4f viewMatrix;
	
	private static ChunkShader chunkShader;
	
	private static final float RED = 0.25f;
	private static final float GREEN = 1;
	private static final float BLUE = 1;
	
	public static void createRenderer() {
		GL11.glEnable(GL11.GL_CULL_FACE);
		GL11.glCullFace(GL11.GL_BACK);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthFunc(GL11.GL_LESS);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		
		createProjectionMatrix();
		
		chunkShader = new ChunkShader(projectionMatrix);
	}
	
	public static void prepare(Matrix4f viewMatrix) {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glClearColor(RED, GREEN, BLUE, 1);
		
		Renderer.viewMatrix = viewMatrix;
	}
	
	public static void prepareChunkRenderer(Light light) {
		chunkShader.start();
		chunkShader.updateViewMatrix(viewMatrix);
		chunkShader.updateLight(light);
	}
	
	public static void endChunkRendering() {
		chunkShader.stop();
	}
	
	public static void destroy() {
		chunkShader.destroy();
	}

	private static final float NEAR_PLANE = 0.01f;
	private static final float FAR_PLANE = 1000;
	private static final float FOV = (float)Math.toRadians(70);
	private static void createProjectionMatrix() {
		float aspectRatio = (float) Display.getWidth() / Display.getHeight();
		float yScale = 1 / (float) Math.tan(FOV / 2);
		float xScale = yScale / aspectRatio;
		float frustumLength = FAR_PLANE - NEAR_PLANE;
		
		projectionMatrix = new Matrix4f();
		projectionMatrix.m00 = xScale;
		projectionMatrix.m11 = yScale;
		projectionMatrix.m22 = -((FAR_PLANE + NEAR_PLANE) / frustumLength);
		projectionMatrix.m23 = -1;
		projectionMatrix.m32 = -2 * FAR_PLANE * NEAR_PLANE / frustumLength;
		projectionMatrix.m33 = 0;
	}
}
