package graphics;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import utils.Maths;

public class Camera {

	private static final float MAX_PITCH = (float)Math.PI / 4;
	private static final float ROTATE_SPEED = (float)Math.PI / 2;
	private static final float SPEED = 80;
	
	private Matrix4f viewMatrix = new Matrix4f();
	
	private Vector3f position;
	private float pitch;
	private float yaw;
	private float roll;
	
	public Camera(Vector3f position) {
		this.position = position;
		updateViewMatrix();
	}
	
	private void rotate() {
		if(Mouse.isButtonDown(0)) {
			pitch += Mouse.getDY() * 0.005f;
			if(pitch > MAX_PITCH) {
				pitch = MAX_PITCH;
			} if(pitch < -MAX_PITCH) {
				pitch = -MAX_PITCH;
			}
		}
		
		if(Keyboard.isKeyDown(Keyboard.KEY_A)) {
			yaw -= ROTATE_SPEED * DisplayManager.getFrameTimeSeconds();
		} if(Keyboard.isKeyDown(Keyboard.KEY_D)) {
			yaw += ROTATE_SPEED * DisplayManager.getFrameTimeSeconds();
		}
	}
	
	private void move() {
		if(Keyboard.isKeyDown(Keyboard.KEY_W)) {
			position.x += (float)Math.sin(yaw) * SPEED * DisplayManager.getFrameTimeSeconds();
			position.z -= (float)Math.cos(yaw) * SPEED * DisplayManager.getFrameTimeSeconds();
		} if(Keyboard.isKeyDown(Keyboard.KEY_S)) {
			position.x -= (float)Math.sin(yaw) * SPEED * DisplayManager.getFrameTimeSeconds();
			position.z += (float)Math.cos(yaw) * SPEED * DisplayManager.getFrameTimeSeconds();
		} 
		
		if(Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
			position.y += SPEED * DisplayManager.getFrameTimeSeconds();
		} if(Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
			position.y -= SPEED * DisplayManager.getFrameTimeSeconds();
		}
	}
	
	public void update() {
		rotate();
		move();
		updateViewMatrix();
	}
	
	public Matrix4f toMatrix() {
		return viewMatrix;
	}
	
	private void updateViewMatrix() {
		viewMatrix.setIdentity();
		Matrix4f.rotate(pitch, Maths.X_AXIS, viewMatrix, viewMatrix);
		Matrix4f.rotate(yaw, Maths.Y_AXIS, viewMatrix, viewMatrix);
		Matrix4f.rotate(roll, Maths.Z_AXIS, viewMatrix, viewMatrix);
		Vector3f negativeCameraPos = new Vector3f(-position.x, -position.y, -position.z);
		Matrix4f.translate(negativeCameraPos, viewMatrix, viewMatrix);
	}
	
	public Vector3f getPosition() {
		return position;
	}
}
