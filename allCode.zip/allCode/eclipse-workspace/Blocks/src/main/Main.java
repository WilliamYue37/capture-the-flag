package main;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import graphics.Camera;
import graphics.DisplayManager;
import graphics.Light;
import graphics.Renderer;
import model.Loader;
import world.World;

public class Main {

	public static void main(String[] args) {
		DisplayManager.createDisplay(1200, 800, "BLOCKS");
		Renderer.createRenderer();
		
		Camera camera = new Camera(new Vector3f());
		Light light = new Light(camera.getPosition(), new Vector3f(1,1,1));
		World world = new World(10, 7);
		
		while(!Display.isCloseRequested()) {
			camera.update();
			
			Renderer.prepare(camera.toMatrix());
			world.render(light);
			DisplayManager.updateDisplay();
		}
		
		Renderer.destroy();
		Loader.destroy();
		DisplayManager.closeDisplay();
	}
}
