package chunkShader;

import org.lwjgl.util.vector.Matrix4f;

import graphics.Light;
import graphics.ShaderProgram;

public class ChunkShader extends ShaderProgram {

	private static final String VERTEX_FILE = "src/chunkShader/ChunkVertexShader.txt";
	private static final String GEOMETRY_FILE = "src/chunkShader/ChunkGeometryShader.txt";
	private static final String FRAGMENT_FILE = "src/chunkShader/ChunkFragmentShader.txt";
	
	private int location_projectionMatrix;
	private int location_viewMatrix;
	private int location_lightPosition;
	private int location_lightColor;
	
	public ChunkShader(Matrix4f projectionMatrix) {
		super(VERTEX_FILE, GEOMETRY_FILE, FRAGMENT_FILE);
		start();
		loadMatrix(location_projectionMatrix, projectionMatrix);
		stop();
	}

	protected void bindAttributes() {
		bindAttribute(0, "position");
		bindAttribute(1, "color");
	}

	protected void getAllUniformLocations() {
		location_projectionMatrix = getUniformLocation("projectionMatrix");
		location_viewMatrix = getUniformLocation("viewMatrix");
		location_lightPosition = getUniformLocation("lightPosition");
		location_lightColor = getUniformLocation("lightColor");
	}

	protected void connectTextureUnits() {}
	
	public void updateViewMatrix(Matrix4f viewMatrix) {
		loadMatrix(location_viewMatrix, viewMatrix);
	}
	
	public void updateLight(Light light) {
		loadVector(location_lightPosition, light.getPosition());
		loadVector(location_lightColor, light.getColor());
	}
}
