package world;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector3f;

import model.Loader;
import model.Model;

public class ChunkMesh {

	private Model model;
	private List<Vector3f> positions = new ArrayList<Vector3f>();
	private List<Vector3f> colors = new ArrayList<Vector3f>();
	private List<Integer> indices = new ArrayList<Integer>();
	
	protected void finalize() {
		float[] pos = new float[positions.size() * 3];
		float[] col = new float[colors.size() * 3];
		int[] ind = new int[indices.size()];
		
		for(int i = 0; i < positions.size(); i++) {
			pos[i * 3] = positions.get(i).x;
			pos[i * 3 + 1] = positions.get(i).y;
			pos[i * 3 + 2] = positions.get(i).z;
			
			col[i * 3] = colors.get(i).x;
			col[i * 3 + 1] = colors.get(i).y;
			col[i * 3 + 2] = colors.get(i).z;
		} for(int i = 0; i < indices.size(); i++) {
			ind[i] = indices.get(i);
		}
		
		model = Loader.loadToVAO(pos, col, ind);
		
		positions.clear();
		colors.clear();
		indices.clear();
	}
	
	private void addPoint(Vector3f p, Vector3f color) {
		for(int i = 0; i < positions.size(); i++) {
			if(positions.get(i).equals(p) && colors.get(i).equals(color)) {
				indices.add(i);
				return;
			}
		}
		
		indices.add(positions.size());
		positions.add(p);
		colors.add(color);
	}
	
	protected void addTriangle(Vector3f a, Vector3f b, Vector3f c, Vector3f color) {
		addPoint(a, color);
		addPoint(b, color);
		addPoint(c, color);
	}
	
	protected void render() {
		model.render();
	}
}
