package world;

import org.lwjgl.util.vector.Vector3f;

public class Cube {

	private static final int TOP = 0;
	private static final int BOTTOM = 1;
	private static final int LEFT = 2;
	private static final int RIGHT = 3;
	private static final int FRONT = 4;
	private static final int BACK = 5;
	
	private static final int LEFT_BOTTOM_BACK = 0;
	private static final int LEFT_BOTTOM_FRONT = 1;
	private static final int LEFT_TOP_BACK = 2;
	private static final int LEFT_TOP_FRONT = 3;
	private static final int RIGHT_BOTTOM_BACK = 4;
	private static final int RIGHT_BOTTOM_FRONT = 5;
	private static final int RIGHT_TOP_BACK = 6;
	private static final int RIGHT_TOP_FRONT = 7;
	
	private static final float CUBE_SIZE = 4;
	
	private World world;
	private int x;
	private int y;
	private int z;
	
	private Face[] faces = new Face[6];
	private Vector3f[] vertices = new Vector3f[8];
	private Vector3f color;
	
	public Cube(World world, int x, int y, int z, Vector3f color) {
		this.world = world;
		this.x = x;
		this.y = y;
		this.z = z;
		this.color = color;
		
		createGeometry();
	}
	
	private boolean addFace(ChunkMesh mesh, int face) {
		int xOffset = 0;
		int yOffset = 0;
		int zOffset = 0;
		
		switch(face) {
		case TOP :
			yOffset = 1;
			break;
		case BOTTOM :
			yOffset = -1;
			break;
		case LEFT :
			xOffset = -1;
			break;
		case RIGHT :
			xOffset = 1;
			break;
		case FRONT :
			zOffset = 1;
			break;
		case BACK :
			zOffset = -1;
			break;
		}
		
		int x = this.x + xOffset;
		int y = this.y + yOffset;
		int z = this.z + zOffset;
		
		if(!world.cubeAt(x, y, z)) {
			faces[face].addToMesh(mesh);
			return true;
		} else {
			return false;
		}
	}
	
	protected boolean addToMesh(ChunkMesh mesh) {
		boolean added = false;
		if(addFace(mesh, TOP)) { added = true; }
		if(addFace(mesh, BOTTOM)) { added = true; }
		if(addFace(mesh, LEFT)) { added = true; }
		if(addFace(mesh, RIGHT)) { added = true; }
		if(addFace(mesh, FRONT)) { added = true; }
		if(addFace(mesh, BACK)) { added = true; }
		return added;
	}
	
	private void createGeometry() {
		float x = this.x * CUBE_SIZE;
		float y = this.y * CUBE_SIZE;
		float z = this.z * CUBE_SIZE;
		
		vertices[LEFT_BOTTOM_BACK] = new Vector3f(x, y, z);
		vertices[LEFT_BOTTOM_FRONT] = new Vector3f(x, y, z + CUBE_SIZE);
		vertices[LEFT_TOP_BACK] = new Vector3f(x, y + CUBE_SIZE, z);
		vertices[LEFT_TOP_FRONT] = new Vector3f(x, y + CUBE_SIZE, z + CUBE_SIZE);
		vertices[RIGHT_BOTTOM_BACK] = new Vector3f(x + CUBE_SIZE, y, z);
		vertices[RIGHT_BOTTOM_FRONT] = new Vector3f(x + CUBE_SIZE, y, z + CUBE_SIZE);
		vertices[RIGHT_TOP_BACK] = new Vector3f(x + CUBE_SIZE, y + CUBE_SIZE, z);
		vertices[RIGHT_TOP_FRONT] = new Vector3f(x + CUBE_SIZE, y + CUBE_SIZE, z + CUBE_SIZE);
		
		faces[TOP] = new Face(vertices[LEFT_TOP_BACK], vertices[LEFT_TOP_FRONT], vertices[RIGHT_TOP_BACK], vertices[RIGHT_TOP_FRONT], color, false);
		faces[BOTTOM] = new Face(vertices[LEFT_BOTTOM_BACK], vertices[LEFT_BOTTOM_FRONT], vertices[RIGHT_BOTTOM_BACK], vertices[RIGHT_BOTTOM_FRONT], color, true);
		faces[LEFT] = new Face(vertices[LEFT_BOTTOM_BACK], vertices[LEFT_BOTTOM_FRONT], vertices[LEFT_TOP_BACK], vertices[LEFT_TOP_FRONT], color, false);
		faces[RIGHT] = new Face(vertices[RIGHT_BOTTOM_BACK], vertices[RIGHT_BOTTOM_FRONT], vertices[RIGHT_TOP_BACK], vertices[RIGHT_TOP_FRONT], color, true);
		faces[FRONT] = new Face(vertices[LEFT_BOTTOM_FRONT], vertices[LEFT_TOP_FRONT], vertices[RIGHT_BOTTOM_FRONT], vertices[RIGHT_TOP_FRONT], color, true);
		faces[BACK] = new Face(vertices[LEFT_BOTTOM_BACK], vertices[LEFT_TOP_BACK], vertices[RIGHT_BOTTOM_BACK], vertices[RIGHT_TOP_BACK], color, false);
	}
}
