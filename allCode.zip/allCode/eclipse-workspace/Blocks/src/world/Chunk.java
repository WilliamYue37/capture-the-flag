package world;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector3f;

public class Chunk {
	
	protected static final int CHUNK_SIZE = 16;
	
	private Cube[][][] cubes = new Cube[CHUNK_SIZE][CHUNK_SIZE][CHUNK_SIZE];
	
	private ChunkMesh mesh = new ChunkMesh();
	private List<Cube> cubeShell = new ArrayList<Cube>();
	
	public Chunk(World world, int x, int y, int z, int width) {
		for(int a = 0; a < CHUNK_SIZE; a++) {
			for(int c = 0; c < CHUNK_SIZE; c++) {
				int cubeX = a + x * CHUNK_SIZE;
				int cubeZ = c + z * CHUNK_SIZE;
				int height = HeightsGenerator.getHeight(cubeX, cubeZ, width * Chunk.CHUNK_SIZE);
				int b = 0;
				int cubeY = y * CHUNK_SIZE;
				while(b < CHUNK_SIZE && cubeY <= height) {
					Vector3f color;
					if(cubeY == 0) {
						color = new Vector3f(0,0,0);
					} else if(cubeY == height) {
						color = new Vector3f((float)Math.random() * 0.4f, 1, (float)Math.random() * 0.6f);
					} else if(cubeY > HeightsGenerator.MIN_TERRAIN_HEIGHT - 1) {
						color = new Vector3f((float)Math.random() * 0.5f + 0.25f, (float)Math.random() * 0.4f, (float)Math.random() * 0.2f);
					} else {
						float g = (float)Math.random() * 0.5f + 0.25f;
						color = new Vector3f(g,g,g);
					}
					
					cubes[a][b][c] = new Cube(world, cubeX, cubeY, cubeZ, color);
					
					b++;
					cubeY++;
				}
			}
		}
		
		/*
		for(int a = 0; a < CHUNK_SIZE; a++) {
			for(int c = 0; c < CHUNK_SIZE; c++) {
				float height;
				if(top) {
					height = HeightsGenerator.getHeight(a + CHUNK_SIZE * x, c + CHUNK_SIZE * z);
				} else {
					height = CHUNK_SIZE;
				}
				
				for(int b = 0; b < height; b++) {
					float g = (float)Math.random() * 0.5f + 0.25f;
					Vector3f color = new Vector3f(g,g,g); // gray
					if(bottom && b == 0) { color = new Vector3f(); } // black
					if(top && b > DIRT_HEIGHT) { color = new Vector3f((float)Math.random() * 0.5f + 0.25f, (float)Math.random() * 0.4f, (float)Math.random() * 0.2f); } // brown
					if(top && b == height - 1) { color = new Vector3f((float)Math.random() * 0.4f, 1, (float)Math.random() * 0.6f); } // green
					cubes[a][b][c] = new Cube(world, a + CHUNK_SIZE * x, b + CHUNK_SIZE * y, c + CHUNK_SIZE * z, color);
				}
			}
		}
		*/
	}
	
	protected boolean cubeAt(int x, int y, int z) {
		if(x < 0 || x >= CHUNK_SIZE ||
				y < 0 || y >= CHUNK_SIZE || 
				z < 0 || z >= CHUNK_SIZE) {
			return false;
		} else {
			return cubes[x][y][z] != null;
		}
	}
	
	private void addCube(int x, int y, int z) {
		if(cubeAt(x,y,z)) {
			if(cubes[x][y][z].addToMesh(mesh)) {
				cubeShell.add(cubes[x][y][z]);
			}
		}
	}
	
	protected void updateMesh() {
		cubeShell.clear();
		for(int x = 0; x < CHUNK_SIZE; x++) {
			for(int y = 0; y < CHUNK_SIZE; y++) {
				for(int z = 0; z < CHUNK_SIZE; z++) {
					addCube(x,y,z);
				}
			}
		}
		mesh.finalize();
	}
	
	protected void render() {
		mesh.render();
	}
}
