package world;

public class HeightsGenerator {
	
	protected static final int MIN_TERRAIN_HEIGHT = 30;
	protected static final int GRASS_START_HEIGHT = 40;
	protected static final int MAX_TERRAIN_HEIGHT = 50;
	
	private static final float HILL1_START = 0.2f;
	private static final float HILL1_STOP = 0.4f;
	private static final float HILL2_START = 0.6f;
	private static final float HILL2_STOP = 0.8f;
	
	private static int calculateHillHeight(float f) {
		return (int)(-4 * (MAX_TERRAIN_HEIGHT - GRASS_START_HEIGHT) * (f - 0.5f) * (f - 0.5f)) + MAX_TERRAIN_HEIGHT;
//		if(f < 0.5) {
//			return (int)(2 * f * (MAX_TERRAIN_HEIGHT - MIN_TERRAIN_HEIGHT) + MIN_TERRAIN_HEIGHT);
//		} else {
//			return (int)(-2 * (f - 1) * (MAX_TERRAIN_HEIGHT - MIN_TERRAIN_HEIGHT) + MIN_TERRAIN_HEIGHT);
//		}
	}
	
	public static int getHeight(int x, int z, int width) {
		float f = (float)x / width;
		if(f < HILL1_START) {
			return GRASS_START_HEIGHT;
		} else if(f < HILL1_STOP) {
			return calculateHillHeight((f - HILL1_START) / (HILL1_STOP - HILL1_START));
		} else if(f < HILL2_START) {
			return GRASS_START_HEIGHT;
		} else if(f < HILL2_STOP) {
			return calculateHillHeight((f - HILL2_START) / (HILL2_STOP - HILL2_START));
		} else {
			return GRASS_START_HEIGHT;
		}
	}
}
