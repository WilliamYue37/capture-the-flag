package world;

import graphics.Light;
import graphics.Renderer;

public class World {

	private Chunk[][][] chunks;
	private int width;
	private int height;
	private int length;
	
	public World(int width, int length) {
		this.width = width;
		this.height = HeightsGenerator.MAX_TERRAIN_HEIGHT / Chunk.CHUNK_SIZE + 1;
		this.length = length;
		
		chunks = new Chunk[width][height][length];
		for(int x = 0; x < width; x++) {
			for(int y = 0; y < height; y++) {
				for(int z = 0; z < length; z++) {
					chunks[x][y][z] = new Chunk(this, x, y, z, width);
				}
			}
		}
		
		for(Chunk[][] cAA : chunks) {
			for(Chunk[] cA : cAA) {
				for(Chunk c : cA) {
					c.updateMesh();
				}
			}
		}
	}
	
	public boolean cubeAt(int x, int y, int z) {
		int chunkX = x / Chunk.CHUNK_SIZE;
		int chunkY = y / Chunk.CHUNK_SIZE;
		int chunkZ = z / Chunk.CHUNK_SIZE;
		int cubeX = x % Chunk.CHUNK_SIZE;
		int cubeY = y % Chunk.CHUNK_SIZE;
		int cubeZ = z % Chunk.CHUNK_SIZE;
		
		if(chunkX >= 0 && chunkX < width &&
				chunkY >= 0 && chunkY < height &&
				chunkZ >= 0 && chunkZ < length) {
			return chunks[chunkX][chunkY][chunkZ].cubeAt(cubeX, cubeY, cubeZ);
		} else {
			return false;
		}
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public int getLength() {
		return length;
	}
	
	public void render(Light light) {
		Renderer.prepareChunkRenderer(light);
		for(Chunk[][] cAA : chunks) {
			for(Chunk[] cA : cAA) {
				for(Chunk c : cA) {
					c.render();
				}
			}
		}
		Renderer.endChunkRendering();
	}
}
