package world;

import org.lwjgl.util.vector.Vector3f;

public class Face {

	private Vector3f a;
	private Vector3f b;
	private Vector3f c;
	private Vector3f d;
	private Vector3f color;
	private boolean flip;
	
	public Face(Vector3f a, Vector3f b, Vector3f c, Vector3f d, Vector3f color, boolean flip) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.color = color;
		this.flip = flip;
	}
	
	protected void addToMesh(ChunkMesh mesh) {
		if(flip) {
			mesh.addTriangle(b, a, c, color);
			mesh.addTriangle(b, c, d, color);
		} else {
			mesh.addTriangle(a, b, c, color);
			mesh.addTriangle(c, b, d, color);
		}
	}
}
