package model;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public class Texture {

	private int textureID;
	
	public Texture(String name) {
		textureID = Loader.loadTexture(name);
	}
	
	public void bind(int target) {
		GL13.glActiveTexture(GL13.GL_TEXTURE0 + target);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureID);
	}
}
