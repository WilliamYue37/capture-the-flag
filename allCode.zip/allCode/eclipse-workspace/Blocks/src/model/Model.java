package model;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class Model {

	private int vaoID;
	private int drawCount;
	private int drawMode;
	private boolean hasIndexBuffer;
	private int vbos;
	
	public Model(int vaoID, int drawCount, boolean hasIndexBuffer, int drawMode, int vbos) {
		this.vaoID = vaoID;
		this.drawCount = drawCount;
		this.hasIndexBuffer = hasIndexBuffer;
		this.drawMode = drawMode;
		this.vbos = vbos;
	}
	
	public void start() {
		GL30.glBindVertexArray(vaoID);
		for(int i = 0; i < vbos; i++) {
			GL20.glEnableVertexAttribArray(i);
		}
	}
	
	public void draw() {
		if(hasIndexBuffer) {
			GL11.glDrawElements(drawMode, drawCount, GL11.GL_UNSIGNED_INT, 0);
		} else {
			GL11.glDrawArrays(drawMode, 0, drawCount);
		}
	}
	
	public void stop() {
		for(int i = 0; i < vbos; i++) {
			GL20.glDisableVertexAttribArray(i);
		}
		GL30.glBindVertexArray(0);
	}
	
	public void render() {
		start();
		draw();
		stop();
	}
}
