package graphics;

import java.util.List;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;

import entity.RenderableEntity;
import entityShader.EntityShader;
import levelShader.LevelShader;
import model.Model;

public class Renderer {

	private static Matrix4f projectionMatrix;
	private static Matrix4f viewMatrix;
	private static LevelShader levelShader;
	private static EntityShader entityShader;
	
	public static void createRenderer(int maxLights) {
		GL11.glEnable(GL11.GL_CULL_FACE);
		GL11.glCullFace(GL11.GL_BACK);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDepthFunc(GL11.GL_LESS);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		
		createProjectionMatrix();
		
		levelShader = new LevelShader(projectionMatrix, maxLights);
		entityShader = new EntityShader(projectionMatrix, maxLights);
	}
	
	public static void prepare(Matrix4f viewMatrix) {
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glClearColor(0.25f, 1, 1, 1);
		
		Renderer.viewMatrix = viewMatrix;
	}
	
	public static void prepareEntityRenderer(List<Light> lights) {
		entityShader.start();
		entityShader.updateViewMatrix(viewMatrix);
		entityShader.updateLights(lights);
	}
	
	public static void renderEntity(RenderableEntity entity) {
		entityShader.updateTransformationMatrix(entity.getTransformationMatrix());
		entityShader.updateDiffuseMap(entity.getTexture());
		Model model = entity.getModel();
		model.render();
	}
	
	public static void endEntityRendering() {
		entityShader.stop();
	}
	
	public static void prepareLevelRenderer(List<Light> lights) {
		levelShader.start();
		levelShader.updateViewMatrix(viewMatrix);
		levelShader.updateLights(lights);
	}
	
	public static void endLevelRendering() {
		levelShader.stop();
	}
	
	public static void destroy() {
		levelShader.destroy();
		entityShader.destroy();
	}
	
	private static final float NEAR_PLANE = 0.01f;
	private static final float FAR_PLANE = 1000;
	private static final float FOV = (float)Math.toRadians(70);
	private static void createProjectionMatrix() {
		float aspectRatio = (float) Display.getWidth() / Display.getHeight();
		float yScale = 1 / (float) Math.tan(FOV / 2);
		float xScale = yScale / aspectRatio;
		float frustumLength = FAR_PLANE - NEAR_PLANE;
		
		projectionMatrix = new Matrix4f();
		projectionMatrix.m00 = xScale;
		projectionMatrix.m11 = yScale;
		projectionMatrix.m22 = -((FAR_PLANE + NEAR_PLANE) / frustumLength);
		projectionMatrix.m23 = -1;
		projectionMatrix.m32 = -2 * FAR_PLANE * NEAR_PLANE / frustumLength;
		projectionMatrix.m33 = 0;
	}
}
