package graphics;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import utils.Maths;

public class Camera {

	private Matrix4f viewMatrix = new Matrix4f();
	
	private Vector3f position;
	private float pitch;
	private float yaw;
	private float roll;
	
	private static final float MAX_PITCH = (float)Math.PI / 4;

	private void rotate() {
		pitch -= DisplayManager.getMouseDY() * 0.001f;
		if(pitch > MAX_PITCH) {
			pitch = MAX_PITCH;
		} if(pitch < -MAX_PITCH) {
			pitch = -MAX_PITCH;
		}

		yaw += DisplayManager.getMouseDX() * 0.001f;
	}
	
	public void update() {
		rotate();
		createViewMatrix();
	}
	
	private void createViewMatrix() {
		viewMatrix.setIdentity();
		Matrix4f.rotate(pitch, Maths.X_AXIS, viewMatrix, viewMatrix);
		Matrix4f.rotate(yaw, Maths.Y_AXIS, viewMatrix, viewMatrix);
		Matrix4f.rotate(roll, Maths.Z_AXIS, viewMatrix, viewMatrix);
		Vector3f negativeCameraPos = new Vector3f(-position.x, -position.y, -position.z);
		Matrix4f.translate(negativeCameraPos, viewMatrix, viewMatrix);
	}
	
	public Matrix4f getViewMatrix() {
		return viewMatrix;
	}
	
	public Vector3f getPosition() {
		return position;
	}
	
	public void setPosition(Vector3f position) {
		this.position = position;
	}
	
	public float getYaw() {
		return yaw;
	}
}
