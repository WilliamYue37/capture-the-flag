package graphics;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL32;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

public abstract class ShaderProgram {

	private int programID;
	private int vertexID;
	private int geometryID;
	private int fragmentID;
	private boolean hasGeometryShader = false;
	
	private static FloatBuffer matrixBuffer = BufferUtils.createFloatBuffer(16);
	
	protected int maxLights;
	
	public ShaderProgram(String vertexFile, String fragmentFile, int maxLights) {
		this.maxLights = maxLights;
		vertexID = loadShader(vertexFile, GL20.GL_VERTEX_SHADER, maxLights);
		fragmentID = loadShader(fragmentFile, GL20.GL_FRAGMENT_SHADER, maxLights);
		programID = GL20.glCreateProgram();
		GL20.glAttachShader(programID, vertexID);
		GL20.glAttachShader(programID, fragmentID);
		bindAttributes();
		GL20.glLinkProgram(programID);
		GL20.glValidateProgram(programID);
		getAllUniformLocations();
		start();
		connectTextureUnits();
		stop();
	}
	
	public ShaderProgram(String vertexFile, String geometryFile, String fragmentFile, int maxLights) {
		this.maxLights = maxLights;
		hasGeometryShader = true;
		vertexID = loadShader(vertexFile, GL20.GL_VERTEX_SHADER, maxLights);
		geometryID = loadShader(geometryFile, GL32.GL_GEOMETRY_SHADER, maxLights);
		fragmentID = loadShader(fragmentFile, GL20.GL_FRAGMENT_SHADER, maxLights);
		programID = GL20.glCreateProgram();
		GL20.glAttachShader(programID, vertexID);
		GL20.glAttachShader(programID, geometryID);
		GL20.glAttachShader(programID, fragmentID);
		bindAttributes();
		GL20.glLinkProgram(programID);
		GL20.glValidateProgram(programID);
		getAllUniformLocations();
		start();
		connectTextureUnits();
		stop();
	}
	
	protected abstract void bindAttributes();
	protected abstract void getAllUniformLocations();
	protected abstract void connectTextureUnits();
	
	protected void bindAttribute(int attriubuteNumber, String variableName) {
		GL20.glBindAttribLocation(programID, attriubuteNumber, variableName);
	}
	
	protected void loadBoolean(int location, boolean value) {
		GL20.glUniform1i(location, value?1:0);
	}
	
	protected void loadInt(int location, int value) {
		GL20.glUniform1i(location, value);
	}
	
	protected void loadFloat(int location, float value) {
		GL20.glUniform1f(location, value);
	}
	
	protected void loadVector(int location, Vector3f vector) {
		GL20.glUniform3f(location, vector.x, vector.y, vector.z);
	}
	
	protected void loadVector(int location, Vector2f vector) {
		GL20.glUniform2f(location, vector.x, vector.y);
	}
	
	protected void loadMatrix(int location, Matrix4f matrix) {
		matrix.store(matrixBuffer);
		matrixBuffer.flip();
		GL20.glUniformMatrix4(location, false, matrixBuffer);
	}
	
	protected int getUniformLocation(String uniformName) {
		return GL20.glGetUniformLocation(programID, uniformName);
	}
	
	public void start() {
		GL20.glUseProgram(programID);
	}
	
	public void stop() {
		GL20.glUseProgram(0);
	}
	
	public void destroy() {
		stop();
		GL20.glDetachShader(programID, vertexID);
		if(hasGeometryShader) { GL20.glDetachShader(programID, geometryID); }
		GL20.glDetachShader(programID, fragmentID);
		GL20.glDeleteShader(vertexID);
		if(hasGeometryShader) { GL20.glDeleteProgram(geometryID); }
		GL20.glDeleteShader(fragmentID);
		GL20.glDeleteProgram(programID);
	}
	
	@SuppressWarnings("deprecation")
	private static int loadShader(String file, int type, int maxLights) {
	    StringBuilder shaderSource = new StringBuilder();  
	    try {
	    	boolean addedMaxLights = false;
	        BufferedReader reader = new BufferedReader(new FileReader(file));
	        String line;
	        while((line = reader.readLine()) != null) {
	    	    shaderSource.append(line).append("//\n");
	    	    if(!addedMaxLights) {
	    	    	addedMaxLights = true;
	    	        shaderSource.append("const int maxLights = " + maxLights + ";");
	    	    }
	        }
	        reader.close();
	    } catch(Exception e) {
	        System.err.println("Unreadable file.");
	        e.printStackTrace();
		    System.exit(-1);
		}
        int shaderID = 0;
        try {
        	shaderID = GL20.glCreateShader(type);
        	GL20.glShaderSource(shaderID, shaderSource);
    		GL20.glCompileShader(shaderID);
        } catch(Exception e) {
        	System.err.println("Could not create shader id for " + file);
        	e.printStackTrace();
        	System.exit(-1);
        }
		if(GL20.glGetShader(shaderID, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
		    System.out.println(GL20.glGetShaderInfoLog(shaderID, 500));
		    System.err.println("Could not compile shader. " + file);
		    System.exit(-1);
		}
		return shaderID;
	}
}
