package model;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class Loader {

	private static List<Integer> vaos = new ArrayList<Integer>();
	private static List<Integer> vbos = new ArrayList<Integer>();
	private static List<Integer> textures = new ArrayList<Integer>();
	
	public static String loadFile(String path) {
		try {
			StringBuilder builder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader("res/" + path + ".txt"));
            String line;
            while((line = reader.readLine()) != null) {
                builder.append(line + "\n");
            }
            reader.close();
            return builder.toString();
        } catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static BufferedImage loadImage(String file) {
		try {
			return ImageIO.read(new File("res/" + file));
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static int loadTexture(String file) {
		Texture texture = null;
		try {
			texture = TextureLoader.getTexture(file.substring(file.length() - 3).toUpperCase(), new FileInputStream("res/" + file));
			GL30.glGenerateMipmap(GL11.GL_TEXTURE_2D);
			GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR_MIPMAP_LINEAR);
			GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, 0);
//			if(GLContext.getCapabilities().GL_EXT_texture_filter_anisotropic && anisotropic) {
//				float amount = Math.min(4, GL11.glGetFloat(EXTTextureFilterAnisotropic.GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT));
//				GL11.glTexParameterf(GL11.GL_TEXTURE_2D, EXTTextureFilterAnisotropic.GL_TEXTURE_MAX_ANISOTROPY_EXT, amount);
//			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		int textureID = texture.getTextureID();
		textures.add(textureID);
		return textureID;
	}
	
	public static Model loadToVAO(float[] positions, float[] textureCoords, int[] indices) {
		int vaoID = createVAO();
		bindIndicesBuffer(indices);
		storeDataInAttributeList(0, positions, 3);
		storeDataInAttributeList(1, textureCoords, 2);
		unbindVAO();
		return new Model(vaoID, indices.length, true, GL11.GL_TRIANGLES, 2);
	}

	private static int createVAO() {
		int vaoID = GL30.glGenVertexArrays();
		GL30.glBindVertexArray(vaoID);
		vaos.add(vaoID);
		return vaoID;
	}
	
	private static void bindIndicesBuffer(int[] indices) {
		int vboID = GL15.glGenBuffers();
		vbos.add(vboID);
		GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, vboID);
		IntBuffer buffer = storeDataInIntBuffer(indices);
		GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
	}
	
	private static void storeDataInAttributeList(int attributeNumber, float[] data, int dimensions) {
		int vboID = GL15.glGenBuffers();
		vbos.add(vboID);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vboID);
		FloatBuffer buffer = storeDataInFloatBuffer(data);
		GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
		GL20.glVertexAttribPointer(attributeNumber, dimensions, GL11.GL_FLOAT, false, 0, 0);
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
	}
	
	private static FloatBuffer storeDataInFloatBuffer(float[] data) {
		FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(data.length);
		floatBuffer.put(data);
		floatBuffer.flip();
		return floatBuffer;
	}
	
	private static IntBuffer storeDataInIntBuffer(int[] data) {
		IntBuffer intBuffer = BufferUtils.createIntBuffer(data.length);
		intBuffer.put(data);
		intBuffer.flip();
		return intBuffer;
	}
	
	private static void unbindVAO() {
		GL30.glBindVertexArray(0);
	}
	
	public static void destroy() {
		System.out.println("VAOs: " + vaos.size());
		System.out.println("VBOs: " + vbos.size());
		long lastTime = System.currentTimeMillis();
		for(int vao : vaos) {
			GL30.glDeleteVertexArrays(vao);
		} for(int vbo : vbos) {
			GL15.glDeleteBuffers(vbo);
		} for(int texture : textures) {
			GL11.glDeleteTextures(texture);
		}
		System.out.println("Delete VAO and VBO data: " + (System.currentTimeMillis() - lastTime));
	}
}
