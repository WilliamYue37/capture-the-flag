package levelShader;

import java.util.List;

import org.lwjgl.util.vector.Matrix4f;

import graphics.Light;
import graphics.ShaderProgram;
import model.Texture;

public class LevelShader extends ShaderProgram {

	private static final String VERTEX_FILE = "src/levelShader/LevelVertexShader.txt";
	private static final String GEOMETRY_FILE = "src/levelShader/LevelGeometryShader.txt";
	private static final String FRAGMENT_FILE = "src/levelShader/LevelFragmentShader.txt";
	
	private int location_projectionMatrix;
	private int location_viewMatrix;
	private int location_diffuseMap;
	private int location_normalMap;
	private int[] location_lightColor;
	private int[] location_lightPosition;
	private int[] location_lightAttenuation;
	private int location_numLights;
	
	private Texture texture;
	private Texture normalMap;
	
	public LevelShader(Matrix4f projectionMatrix, int maxLights) {
		super(VERTEX_FILE, GEOMETRY_FILE, FRAGMENT_FILE, maxLights);
		texture = new Texture("textureAtlas.png");
		normalMap = new Texture("normalMapAtlas.png");
		start();
		loadMatrix(location_projectionMatrix, projectionMatrix);
		stop();
	}
	
	protected void bindAttributes() {
		bindAttribute(0, "position");
		bindAttribute(1, "textureCoords");
	}

	protected void getAllUniformLocations() {
		location_projectionMatrix = getUniformLocation("projectionMatrix");
		location_viewMatrix = getUniformLocation("viewMatrix");
		location_diffuseMap = getUniformLocation("diffuseMap");
		location_normalMap = getUniformLocation("normalMap");
		location_lightPosition = new int[maxLights];
		location_lightColor = new int[maxLights];
		location_lightAttenuation = new int[maxLights];
		for(int i = 0; i < maxLights; i++) {
			location_lightPosition[i] = getUniformLocation("lightPosition[" + i + "]");
			location_lightColor[i] = getUniformLocation("lightColor[" + i + "]");
			location_lightAttenuation[i] = getUniformLocation("lightAttenuation[" + i + "]");
		}
		location_numLights = getUniformLocation("numLights");
	}
	
	protected void connectTextureUnits() {
		loadInt(location_diffuseMap, 0);
		loadInt(location_normalMap, 1);
	}
	
	public void updateViewMatrix(Matrix4f viewMatrix) {
		loadMatrix(location_viewMatrix, viewMatrix);
	}
	
	public void updateLights(List<Light> lights) {
		loadInt(location_numLights, lights.size());
		for(int i = 0; i < lights.size(); i++) {
			loadVector(location_lightPosition[i], lights.get(i).getPosition());
			loadVector(location_lightColor[i], lights.get(i).getColor());
			loadVector(location_lightAttenuation[i], lights.get(i).getAttenuation());
		}
	}

	public void start() {
		super.start();
		if(texture != null) {
			texture.bind(0);
			normalMap.bind(1);
		}
	}
}
