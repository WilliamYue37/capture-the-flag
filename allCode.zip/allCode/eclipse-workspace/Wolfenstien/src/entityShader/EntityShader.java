package entityShader;

import java.util.List;

import org.lwjgl.util.vector.Matrix4f;

import graphics.Light;
import graphics.ShaderProgram;
import model.Texture;

public class EntityShader extends ShaderProgram {

	private static final String VERTEX_FILE = "src/entityShader/EntityVertexShader.txt";
	private static final String GEOMETRY_FILE = "src/entityShader/EntityGeometryShader.txt";
	private static final String FRAGMENT_FILE = "src/entityShader/EntityFragmentShader.txt";
	
	private int location_transformationMatrix;
	private int location_viewMatrix;
	private int location_projectionMatrix;
	private int location_diffuseMap;
	private int[] location_lightColor;
	private int[] location_lightPosition;
	private int[] location_lightAttenuation;
	private int location_numLights;
	
	public EntityShader(Matrix4f projectionMatrix, int maxLights) {
		super(VERTEX_FILE, GEOMETRY_FILE, FRAGMENT_FILE, maxLights);
		start();
		loadMatrix(location_projectionMatrix, projectionMatrix);
		stop();
	}

	protected void bindAttributes() {
		bindAttribute(0, "position");
		bindAttribute(1, "textureCoords");
	}

	protected void getAllUniformLocations() {
		location_projectionMatrix = getUniformLocation("projectionMatrix");
		location_viewMatrix = getUniformLocation("viewMatrix");
		location_transformationMatrix = getUniformLocation("transformationMatrix");
		location_diffuseMap = getUniformLocation("diffuseMap");
		location_lightPosition = new int[maxLights];
		location_lightColor = new int[maxLights];
		location_lightAttenuation = new int[maxLights];
		for(int i = 0; i < maxLights; i++) {
			location_lightPosition[i] = getUniformLocation("lightPosition[" + i + "]");
			location_lightColor[i] = getUniformLocation("lightColor[" + i + "]");
			location_lightAttenuation[i] = getUniformLocation("lightAttenuation[" + i + "]");
		}
		location_numLights = getUniformLocation("numLights");
	}

	protected void connectTextureUnits() {
		loadInt(location_diffuseMap, 0);
	}
	
	public void updateDiffuseMap(Texture texture) {
		texture.bind(0);
	}
	
	public void updateViewMatrix(Matrix4f viewMatrix) {
		loadMatrix(location_viewMatrix, viewMatrix);
	}
	
	public void updateTransformationMatrix(Matrix4f transformationMatrix) {
		loadMatrix(location_transformationMatrix, transformationMatrix);
	}
	
	public void updateLights(List<Light> lights) {
		loadInt(location_numLights, lights.size());
		for(int i = 0; i < lights.size(); i++) {
			loadVector(location_lightPosition[i], lights.get(i).getPosition());
			loadVector(location_lightColor[i], lights.get(i).getColor());
			loadVector(location_lightAttenuation[i], lights.get(i).getAttenuation());
		}
	}
}
