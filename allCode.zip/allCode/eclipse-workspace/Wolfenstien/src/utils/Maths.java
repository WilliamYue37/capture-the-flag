package utils;

import org.lwjgl.util.vector.Vector3f;

public class Maths {

	public static final Vector3f X_AXIS = new Vector3f(1,0,0);
	public static final Vector3f Y_AXIS = new Vector3f(0,1,0);
	public static final Vector3f Z_AXIS = new Vector3f(0,0,1);
	
	public static Vector3f mul(Vector3f a, Vector3f b, Vector3f c) {
		float x = a.x * b.x;
		float y = a.y * b.y;
		float z = a.z * b.z;
		
		if(c != null) {
			c.x = x;
			c.y = y;
			c.z = z;
		}
		
 		return new Vector3f(x,y,z);
	}
}
