package physics;

import org.lwjgl.util.vector.Vector3f;

import level.Level;

public class PhysicsEngine {
	
	public static void move(Vector3f position, Vector3f velocity, Level level) {
		float x = position.x + velocity.x;
		if(velocity.x > 0) {
			if(level.canMove(x + Level.TILE_SIZE / 8, position.z + Level.TILE_SIZE / 8) && 
					level.canMove(x - Level.TILE_SIZE / 8, position.z - Level.TILE_SIZE / 8)) {
				position.x = x;
			}
		} if(velocity.x < 0) {
			if(level.canMove(x - Level.TILE_SIZE / 8, position.z + Level.TILE_SIZE / 8) && 
					level.canMove(x - Level.TILE_SIZE / 8, position.z - Level.TILE_SIZE / 8)) {
				position.x = x;
			}
		}
		
		float z = position.z + velocity.z;
		if(velocity.z > 0) {
			if(level.canMove(position.x + Level.TILE_SIZE / 8, z + Level.TILE_SIZE / 8) && 
					level.canMove(position.x - Level.TILE_SIZE / 8, z + Level.TILE_SIZE / 8)) {
				position.z = z;
			}
		} if(velocity.z < 0) {
			if(level.canMove(position.x + Level.TILE_SIZE / 8, z - Level.TILE_SIZE / 8) && 
					level.canMove(position.x - Level.TILE_SIZE / 8, z - Level.TILE_SIZE / 8)) {
				position.z = z;
			}
		}
	}
}
