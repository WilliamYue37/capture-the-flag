package main;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import entity.Door;
import graphics.Camera;
import graphics.DisplayManager;
import graphics.Renderer;
import level.Level;
import model.Loader;

public class Main {

	public static void main(String[] args) {
		DisplayManager.createDisplay(1200, 800, "Wolfenstien");
		DisplayManager.changeCursor(true);
		Door.createDoor();
		
		Camera camera = new Camera();
		Level level = new Level("testLevel.png", camera);
		
		Renderer.createRenderer(level.getLights().size());
		
		while(!Display.isCloseRequested() && !Keyboard.isKeyDown(Keyboard.KEY_END)) {
			camera.update();
			level.update();
			
			Renderer.prepare(camera.getViewMatrix());
			level.render();
			DisplayManager.updateDisplay();
		}
		
		Loader.destroy();
		Renderer.destroy();
		DisplayManager.closeDisplay();
	}
}
