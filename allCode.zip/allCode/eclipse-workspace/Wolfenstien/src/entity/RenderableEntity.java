package entity;

import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import model.Model;
import model.Texture;
import utils.Maths;

public class RenderableEntity {

	private Model model;
	private Texture texture;
	private Matrix4f transformationMatrix = new Matrix4f();
	private boolean transformationMatrixUpdated = false;
	
	private Vector3f position;
	private float rotationY;
	
	public RenderableEntity(Model model, Texture texture, Vector3f position, float rotationY) {
		this.model = model;
		this.texture = texture;
		this.position = position;
		this.rotationY = rotationY;
	}
	
	public Model getModel() {
		return model;
	}
	
	public Texture getTexture() {
		return texture;
	}
	
	public Matrix4f getTransformationMatrix() {
		if(!transformationMatrixUpdated) {
			updateTranformationMatrix();
			transformationMatrixUpdated = true;
		}
		return transformationMatrix;
	}
	
	public Vector3f getPosition() {
		return position;
	}
	
	public float getRotationY() {
		return rotationY;
	}
	
	public void setPosition(Vector3f position) {
		this.position.set(position);
		transformationMatrixUpdated = false;
	}
	
	public void increasePosition(Vector3f inc) {
		Vector3f.add(position, inc, position);
		transformationMatrixUpdated = false;
	}

	private void updateTranformationMatrix() {
		transformationMatrix.setIdentity();
		Matrix4f.translate(position, transformationMatrix, transformationMatrix);
		Matrix4f.rotate(rotationY, Maths.Y_AXIS, transformationMatrix, transformationMatrix);
	}
}
