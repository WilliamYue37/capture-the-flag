package entity;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;

import graphics.DisplayManager;
import level.Level;
import model.Loader;
import model.Model;
import model.Texture;

public class Door extends RenderableEntity {

	private static float DISTANCE_TO_OPEN = 10;
	private static float DISTANCE_TO_CLOSE = 5;
	
	private static Model DOOR_MODEL;
	private static Texture DOOR_TEXTURE;

	private static final float TIME_TO_OPEN = 1.5f;
	private float openTime = TIME_TO_OPEN;
	private float closeTime = TIME_TO_OPEN;
	
	private Vector3f centerPosition;
	private Vector3f startPosition;
	private Vector3f move;
	private Vector3f destination;
	
	private boolean xAxis;
	
	private static final float f = Level.TILE_SIZE;
	private static final float g = Level.TILE_SIZE / 3;
	public static void createDoor() {
		DOOR_TEXTURE = new Texture("doorTexture.png");
		
		float[] positions = { 0,0,g, f,0,g, 0,0,f-g, f,0,f-g, 0,f,g, f,f,g, 0,f,f-g, f,f,f-g };
		float[] textureCoords = { 0,1, 1,1, 0,1, 1,1, 0,0, 1,0, 0,0, 1,0 };
		int[] indices = { 1,0,4, 5,1,4, 2,3,6, 3,7,6, 0,2,4, 2,6,4, 5,3,1, 5,7,3 };
		
		DOOR_MODEL = Loader.loadToVAO(positions, textureCoords, indices);
	}
	
	public Door(Vector3f position, boolean xAxis, int x, int z) {
		super(DOOR_MODEL, DOOR_TEXTURE, position, xAxis ? (float)Math.PI/2 : 0);
		this.xAxis = xAxis;
		startPosition = new Vector3f(position);
		move = new Vector3f((float)Math.cos(getRotationY()) * Level.TILE_SIZE, 0, (float)Math.sin(getRotationY()) * Level.TILE_SIZE);
		destination = Vector3f.add(move, startPosition, null);
		centerPosition = new Vector3f(x * Level.TILE_SIZE + Level.TILE_SIZE / 2, 0, z * Level.TILE_SIZE + Level.TILE_SIZE / 2);
	}
	
	private boolean playerInRange(Player player, float radius) {
		float distance = Vector3f.sub(centerPosition, player.getPosition(), null).lengthSquared();
		return distance <= radius * radius;
	}
	
	public boolean canMove(float x, float z) {
		Point2D.Float position = new Point2D.Float(x,z);
		Rectangle2D.Float bounds = new Rectangle2D.Float();
		float xOffset;
		float zOffset;
		if(xAxis) {
			xOffset = g;
			zOffset = 0;
		} else {
			xOffset = 0;
			zOffset = g;
		}
		bounds.x = getPosition().x + xOffset;
		bounds.y = getPosition().z - (xAxis ? Level.TILE_SIZE : 0) + zOffset;
		bounds.width = Level.TILE_SIZE - xOffset * 2;
		bounds.height = Level.TILE_SIZE - zOffset * 2;
		return !bounds.contains(position);
	}
	
	public void update(Player player) {
		if(Keyboard.isKeyDown(Keyboard.KEY_SPACE) && playerInRange(player, DISTANCE_TO_OPEN) && openTime >= TIME_TO_OPEN) {
			openTime = TIME_TO_OPEN - closeTime;
			closeTime = 0;
		}
		
		if(openTime < TIME_TO_OPEN) {
			openTime += DisplayManager.getFrameTimeSeconds();
			if(openTime >= TIME_TO_OPEN) {
				setPosition(destination);
			} else {
				Vector3f move = new Vector3f(this.move);
				move.scale(DisplayManager.getFrameTimeSeconds() / TIME_TO_OPEN);
				increasePosition(move);
			}
		}
		
		else if(closeTime < TIME_TO_OPEN && (!playerInRange(player, DISTANCE_TO_CLOSE) || closeTime != 0)) {
			closeTime += DisplayManager.getFrameTimeSeconds();
			if(closeTime >= TIME_TO_OPEN) {
				closeTime = TIME_TO_OPEN;
				setPosition(startPosition);
			} else {
				Vector3f move = new Vector3f(this.move);
				move.scale(-DisplayManager.getFrameTimeSeconds() / TIME_TO_OPEN);
				increasePosition(move);
			}
		}
	}
}
