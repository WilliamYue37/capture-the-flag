package entity;

import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector3f;

import graphics.Camera;
import graphics.DisplayManager;
import level.Level;
import physics.PhysicsEngine;

public class Player {

	private static final float SPEED = 22;
	private Vector3f position;
	
	private Level level;
	private Camera camera;
	
	public Player(Camera camera, Level level) {
		position = level.getPlayerStartPosition();
		this.camera = camera;
		camera.setPosition(position);
		this.level = level;
	}
	
	private void move() {
		float rotation = camera.getYaw();
		Vector3f velocity = new Vector3f();
		
		if(Keyboard.isKeyDown(Keyboard.KEY_W)) {
			velocity.x += (float)Math.sin(rotation);
			velocity.z -= (float)Math.cos(rotation);
		} else if(Keyboard.isKeyDown(Keyboard.KEY_S)) {
			velocity.x -= (float)Math.sin(rotation);
			velocity.z += (float)Math.cos(rotation);
		} 
		if(Keyboard.isKeyDown(Keyboard.KEY_A)) {
			velocity.x -= (float)Math.sin(rotation + (float)Math.PI / 2);
			velocity.z += (float)Math.cos(rotation + (float)Math.PI / 2);
		} if(Keyboard.isKeyDown(Keyboard.KEY_D)) {
			velocity.x -= (float)Math.sin(rotation - (float)Math.PI / 2);
			velocity.z += (float)Math.cos(rotation - (float)Math.PI / 2);
		}
		
		velocity.scale(SPEED * DisplayManager.getFrameTimeSeconds());
		PhysicsEngine.move(position, velocity, level);
	}
	
	public void update() {
		move();
		camera.setPosition(position);
	}
	
	public Vector3f getPosition() {
		return position;
	}
}
