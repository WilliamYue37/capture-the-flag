package level;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import entity.Door;
import entity.Player;
import graphics.Camera;
import graphics.Light;
import graphics.Renderer;
import model.Loader;
import model.Model;

public class Level {
	
	private static final int PLAYER_START = 1;
	private static final int LIGHT = 2;
	private static final int X_DOOR = 3;
	private static final int Z_DOOR = 4;
	
	public static final float TILE_SIZE = 4;
	
	private BufferedImage levelImage;
	private Model model;
	private List<Light> lights = new ArrayList<Light>();

	private Vector3f playerStartPosition;
	private Player player;
	private List<Door> doors = new ArrayList<Door>();
	
	public Level(String file, Camera camera) {
		levelImage = Loader.loadImage(file);
		createModel();
		player = new Player(camera, this);
		lights.add(new Light(playerStartPosition,
				new Vector3f(1,0,0),
				new Vector3f(0.1f, 0.01f, 0.01f)));
	}
	
	public void update() {
		player.update();
		for(Door door : doors) {
			door.update(player);
		}
	}
	
	private boolean noDoor(float x, float z) { 
		for(Door door : doors) {
			if(!door.canMove(x, z)) {
				return false;
			}
		}
		
		return true;
	}
	
	public boolean canMove(float x, float z) {
		int localX = (int)(x / TILE_SIZE);
		int localZ = (int)(z / TILE_SIZE);
		return validSquare(localX, localZ) && noDoor(x, z);
	}
	
	private int addElement(int x, int z) {
		int rgb = levelImage.getRGB(x,z);
		switch(rgb & 0xff) {
		case 0:
			break;
		case PLAYER_START :
			playerStartPosition = new Vector3f(TILE_SIZE * x, TILE_SIZE / 2, TILE_SIZE * z);
			break;
		case LIGHT :
			lights.add(new Light(new Vector3f(TILE_SIZE * x, TILE_SIZE / 2, TILE_SIZE * z),
						new Vector3f(1,1,1),
						new Vector3f(0.1f, 0.01f, 0.01f)));
			break;
		case X_DOOR :
			doors.add(new Door(new Vector3f(x * TILE_SIZE, 0, z * TILE_SIZE + TILE_SIZE), true, x, z));
			break;
		case Z_DOOR:
			doors.add(new Door(new Vector3f(x * TILE_SIZE, 0, z * TILE_SIZE), false, x, z));
			break;
		default :
			System.out.println("Unknown element ID: " + (rgb & 0xff));
		}
		
		return (rgb >> 8) & 0xff;
	}
	
	private boolean validSquare(int x, int z) {
		if(x < 0) { return false; }
		if(z < 0) { return false; }
		if(x >= levelImage.getWidth()) { return false; }
		if(z >= levelImage.getHeight()) { return false; }
		return levelImage.getRGB(x,z) != 0;
	}
	
	private void addWall(List<Vector3f> positions, List<Vector2f> textureCoords, List<Integer> indices, int x, int z, boolean xAxis, boolean farSide, int textureID) {
		float xOffset = xAxis ? 0 : TILE_SIZE;
		float zOffset = xAxis ? TILE_SIZE : 0;
		float xSideOffset = xAxis ? farSide ? TILE_SIZE : 0 : 0; 
		float zSideOffset = xAxis ? 0 : farSide ? TILE_SIZE : 0;
		Vector3f a = new Vector3f(x * TILE_SIZE + xSideOffset, 0, z * TILE_SIZE + zSideOffset);
		Vector3f b = new Vector3f(x * TILE_SIZE + xSideOffset + xOffset, 0, z * TILE_SIZE + zSideOffset + zOffset);
		Vector3f c = new Vector3f(x * TILE_SIZE + xSideOffset, TILE_SIZE, z * TILE_SIZE + zSideOffset);
		Vector3f d = new Vector3f(x * TILE_SIZE + xSideOffset + xOffset, TILE_SIZE, z * TILE_SIZE + zSideOffset + zOffset);
		addSquare(positions, textureCoords, indices, farSide != xAxis, a, b, c, d, textureID);
	}

	private void createModel() {
		List<Vector3f> positions = new ArrayList<Vector3f>();
		List<Vector2f> textureCoords = new ArrayList<Vector2f>();
		List<Integer> indices = new ArrayList<Integer>();
		
		for(int x = 0; x < levelImage.getWidth(); x++) {
			for(int z = 0; z < levelImage.getHeight(); z++) {
				if(validSquare(x,z)) {
					int textureID = addElement(x,z);
					addTile(positions, textureCoords, indices, x, z, true, textureID);
					addTile(positions, textureCoords, indices, x, z, false, textureID);
					
					if(!validSquare(x-1, z)) {
						addWall(positions, textureCoords, indices, x, z, true, false, textureID);
					} if(!validSquare(x+1, z)) {
						addWall(positions, textureCoords, indices, x, z, true, true, textureID);
					} if(!validSquare(x, z-1)) {
						addWall(positions, textureCoords, indices, x, z, false, false, textureID);
					} if(!validSquare(x, z+1)) {
						addWall(positions, textureCoords, indices, x, z, false, true, textureID);
					}
					
					
				}
			}
		}
		
		storeInVAO(positions, textureCoords, indices);
	}
	
	private void addVertex(List<Vector3f> positions, List<Vector2f> textureCoords, List<Integer> indices, Vector3f position, Vector2f textureCoord) {
		for(int i = 0; i < positions.size(); i++) {
			if(positions.get(i).equals(position) && textureCoords.get(i).equals(textureCoord)) {
				indices.add(i);
				return;
			}
		}
		
		indices.add(positions.size());
		positions.add(position);
		textureCoords.add(textureCoord);
	}
	
	private void addTile(List<Vector3f> positions, List<Vector2f> textureCoords, List<Integer> indices, int x, int z, boolean floor, int textureID) {
		float height = floor ? 0 : TILE_SIZE;
		Vector3f a = new Vector3f(x * TILE_SIZE, height, z * TILE_SIZE);
		Vector3f b = new Vector3f(x * TILE_SIZE + TILE_SIZE, height, z * TILE_SIZE);
		Vector3f c = new Vector3f(x * TILE_SIZE, height, z * TILE_SIZE + TILE_SIZE);
		Vector3f d = new Vector3f(x * TILE_SIZE + TILE_SIZE, height, z * TILE_SIZE + TILE_SIZE);
		addSquare(positions, textureCoords, indices, floor, a, b, c, d, textureID);
	}
	
	private static final float ERROR = 1f/1024; 
	private void addSquare(List<Vector3f> positions, List<Vector2f> textureCoords, List<Integer> indices, boolean flip, Vector3f a, Vector3f b, Vector3f c, Vector3f d, int textureID) {
		float x = 1f/(textureID % 2 + 1);
		float y = 1f/(textureID / 2 + 1);
		Vector2f texA = new Vector2f(x + ERROR, y + ERROR);
		Vector2f texB = new Vector2f(texA.x + 0.5f - ERROR * 2, texA.y);
		Vector2f texC = new Vector2f(texA.x, texA.y + 0.5f - ERROR * 2);
		Vector2f texD = new Vector2f(texA.x + 0.5f - ERROR * 2, texA.y + 0.5f - ERROR * 2);
		
		if(flip) {
			addVertex(positions, textureCoords, indices, a, texA);
			addVertex(positions, textureCoords, indices, c, texC);
			addVertex(positions, textureCoords, indices, b, texB);
			
			addVertex(positions, textureCoords, indices, b, texB);
			addVertex(positions, textureCoords, indices, c, texC);
			addVertex(positions, textureCoords, indices, d, texD);
		} else {
			addVertex(positions, textureCoords, indices, c, texC);
			addVertex(positions, textureCoords, indices, a, texA);
			addVertex(positions, textureCoords, indices, b, texB);
			
			addVertex(positions, textureCoords, indices, c, texC);
			addVertex(positions, textureCoords, indices, b, texB);
			addVertex(positions, textureCoords, indices, d, texD);
		}
	}
	
	private void storeInVAO(List<Vector3f> positions, List<Vector2f> textureCoords, List<Integer> indices) {
		float[] pos = new float[positions.size() * 3];
		float[] coords = new float[textureCoords.size() * 2];
		int[] ind = new int[indices.size()];
		
		for(int i = 0; i < positions.size(); i++) {
			pos[i * 3] = positions.get(i).x;
			pos[i * 3 + 1] = positions.get(i).y;
			pos[i * 3 + 2] = positions.get(i).z;
		}
		
		for(int i = 0; i < textureCoords.size(); i++) {
			coords[i * 2] = textureCoords.get(i).x;
			coords[i * 2 + 1] = textureCoords.get(i).y;
		}
		
		for(int i = 0; i < indices.size(); i++) {
			ind[i] = indices.get(i);
		}
		
		model = Loader.loadToVAO(pos, coords, ind);
	}
	
	public void render() {
		Renderer.prepareLevelRenderer(lights);
		model.render();
		Renderer.endLevelRendering();
		
		Renderer.prepareEntityRenderer(lights);
		for(Door door : doors) {
			Renderer.renderEntity(door);
		}
		Renderer.endEntityRendering();
	}
	
	public List<Light> getLights() {
		return lights;
	}
	
	public Vector3f getPlayerStartPosition() {
		return playerStartPosition;
	}
}
