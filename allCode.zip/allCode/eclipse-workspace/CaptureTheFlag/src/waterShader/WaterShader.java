package waterShader;

import org.lwjgl.util.vector.Matrix4f;

import graphics.Light;
import graphics.ShaderProgram;

public class WaterShader extends ShaderProgram {

	private static final String VERTEX_FILE = "src/waterShader/WaterVertexShader.txt";
	private static final String GEOMETRY_FILE = "src/waterShader/WaterGeometryShader.txt";
	private static final String FRAGMENT_FILE = "src/waterShader/WaterFragmentShader.txt";
	
	private int location_projectionMatrix;
	private int location_viewMatrix;
	private int location_waveHeight;
	private int location_waveOffset;
	private int location_sunDirection;
	private int location_sunColor;
	
	public WaterShader(Matrix4f projectionMatrix) {
		super(VERTEX_FILE, GEOMETRY_FILE, FRAGMENT_FILE);
		start();
		loadMatrix(location_projectionMatrix, projectionMatrix);
		stop();
	}
	
	protected void bindAttributes() {
		bindAttribute(0, "position");
		bindAttribute(1, "color");
	}

	protected void getAllUniformLocations() {
		location_projectionMatrix = getUniformLocation("projectionMatrix");
		location_viewMatrix = getUniformLocation("viewMatrix");
		location_waveHeight = getUniformLocation("waveHeight");
		location_waveOffset = getUniformLocation("waveOffset");
		location_sunDirection = getUniformLocation("sunDirection");
		location_sunColor = getUniformLocation("sunColor");
	}

	protected void connectTextureUnits() {}
	
	public void updateViewMatrix(Matrix4f viewMatrix) {
		loadMatrix(location_viewMatrix, viewMatrix);
	}
	
	public void updateWaveHeight(float waveHeight) {
		loadFloat(location_waveHeight, waveHeight);
	}
	
	public void updateWaveOffset(float waveOffset) {
		loadFloat(location_waveOffset, waveOffset);
	}
	
	public void updateSun(Light sun) {
		loadVector(location_sunDirection, sun.getDirection());
		loadVector(location_sunColor, sun.getColor());
	}
}
