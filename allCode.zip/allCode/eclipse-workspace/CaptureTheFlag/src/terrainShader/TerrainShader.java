package terrainShader;

import org.lwjgl.util.vector.Matrix4f;

import graphics.Light;
import graphics.ShaderProgram;

public class TerrainShader extends ShaderProgram {

	private static String VERTEX_FILE = "src/terrainShader/TerrainVertexShader.txt";
	private static String GEOMETRY_FILE = "src/terrainShader/TerrainGeometryShader.txt";
	private static String FRAGMENT_FILE = "src/terrainShader/TerrainFragmentShader.txt";
	
	private int location_projectionMatrix;
	private int location_viewMatrix;
	private int location_sunDirection;
	private int location_sunColor;
	
	public TerrainShader(Matrix4f projectionMatrix) {
		super(VERTEX_FILE, GEOMETRY_FILE, FRAGMENT_FILE);
		start();
		loadMatrix(location_projectionMatrix, projectionMatrix);
		stop();
	}

	protected void bindAttributes() {
		bindAttribute(0, "position");
		bindAttribute(1, "color");
	}

	protected void getAllUniformLocations() {
		location_projectionMatrix = getUniformLocation("projectionMatrix");
		location_viewMatrix = getUniformLocation("viewMatrix");
		location_sunDirection = getUniformLocation("sunDirection");
		location_sunColor = getUniformLocation("sunColor");
	}

	protected void connectTextureUnits() {}
	
	public void updateViewMatrix(Matrix4f viewMatrix) {
		loadMatrix(location_viewMatrix, viewMatrix);
	}
	
	public void updateSun(Light sun) {
		loadVector(location_sunDirection, sun.getDirection());
		loadVector(location_sunColor, sun.getColor());
	}
}
