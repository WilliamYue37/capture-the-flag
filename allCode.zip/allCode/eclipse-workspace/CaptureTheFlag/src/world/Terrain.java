package world;

import java.awt.image.BufferedImage;

import org.lwjgl.util.vector.Vector4f;

import model.Loader;
import model.Model;

public class Terrain {

	private Model model;
	private float[][] heights;
	private int points;
	
	private float rockHeight;
	private float snowHeight;
	private float sandHeight;
	private float terrainHeight;
	
	public Terrain(float terrainHeight, BufferedImage heightMap, float rockHeight, float snowHeight, float sandHeight) {
		this.rockHeight = rockHeight;
		this.snowHeight = snowHeight;
		this.sandHeight = sandHeight;
		this.terrainHeight = terrainHeight;
		createModel(heightMap);
	}

	private Vector4f calculateHeightColor(BufferedImage heightMap, int x, int z) {
		Vector4f heightColor = new Vector4f();
		float r = heightMap.getRGB(x, z) & 0xff;
		float height = r / 0xff;
		heights[x][z] = height;
		heightColor.x = height * terrainHeight;
		
		if(height < sandHeight) {
			heightColor.y = (float)Math.random() * 0.25f + 0.55f;
			heightColor.z = (float)Math.random() * 0.25f + 0.55f;
			heightColor.w = (float)Math.random() * 0.2f + 0.1f;
		} else if(height < rockHeight) {
			heightColor.y = (float)Math.random() * 0.2f;
			heightColor.z = (float)Math.random() * 0.2f + 0.8f;
			heightColor.w = (float)Math.random() * 0.2f + 0.1f;
		} else if(height < snowHeight) {
			float g = (float)Math.random() * 0.5f + 0.25f;
			heightColor.y = g;
			heightColor.z = g;
			heightColor.w = g;
		} else {
			heightColor.y = 1;
			heightColor.z = 1;
			heightColor.w = 1;
		}
		
		return heightColor;
	}
	
	private void createModel(BufferedImage heightMap) {
		points = heightMap.getWidth();
		heights = new float[points][points];
		float[] positions = new float[points * points * 3];
		float[] colors = new float[points * points * 3];
		int index = 0;
		for(int x = 0; x < points; x++) {
			for(int z = 0; z < points; z++) {
				positions[index] = x;
				positions[index + 2] = z;
				
				Vector4f heightColor = calculateHeightColor(heightMap, x, z);
				
				positions[index + 1] = heightColor.x;
				colors[index] = heightColor.y;
				colors[index + 1] = heightColor.z;
				colors[index + 2] = heightColor.w;
				
				index += 3;
			}
		}
		
		int[] indices = new int[(points - 1) * (points - 1) * 6];
		index = 0;
		for(int x = 0; x < points - 1; x++) {
			for(int y = 0; y < points - 1; y++) {
				indices[index++] = x + y * points;
				indices[index++] = x + y * points + 1;
				indices[index++] = x + y * points + points;
				
				indices[index++] = x + y * points + 1;
				indices[index++] = x + y * points + points + 1;
				indices[index++] = x + y * points + points;
			}
		}

		model = Loader.loadToTerrainVAO(positions, colors, indices);
	}
	
	public float getHeight(int x, int z, boolean applyWorldHeight) {
		if(applyWorldHeight) {
			return heights[x][z] * terrainHeight;
		} else {
			return heights[x][z];
		}
	}
	
	public void render() {
		model.render();
	}
	
	public int getSize() {
		return points;
	}
}
