package world;

import graphics.DisplayManager;
import model.Loader;
import model.Model;

public class Water {

	private Model model;
	private float waveSpeed;
	
	public Water(float height, int points, float waveSpeed) {
		this.waveSpeed = waveSpeed;
		createModel(height, points);
	}

	private void createModel(float height, int points) {
		float[] positions = new float[points * points * 4];
		float[] colors = new float[points * points * 3];
		int pIndex = 0;
		int cIndex = 0;
		
		for(int x = 0; x < points; x++) {
			for(int z = 0; z < points; z++) {
				positions[pIndex++] = x;
				positions[pIndex++] = height;
				positions[pIndex++] = z;
				positions[pIndex++] = (float)Math.random() * (float)Math.PI * 2;
				
				colors[cIndex++] = (float)Math.random() * 0.2f;
				colors[cIndex++] = (float)Math.random() * 0.2f + 0.1f;
				colors[cIndex++] = 1;
			}
		}
		
		int[] indices = new int[(points - 1) * (points - 1) * 6];
		int index = 0;
		for(int x = 0; x < points - 1; x++) {
			for(int y = 0; y < points - 1; y++) {
				indices[index++] = x + y * points;
				indices[index++] = x + y * points + 1;
				indices[index++] = x + y * points + points;
				
				indices[index++] = x + y * points + 1;
				indices[index++] = x + y * points + points + 1;
				indices[index++] = x + y * points + points;
			}
		}
		
		model = Loader.loadToWaterVAO(positions, colors, indices);
	}
	
	public void render() {
		model.render();
	}
	
	public float getWaveOffset() {
		return DisplayManager.getCurrentTimeSeconds() * waveSpeed;
	}
}
