package world;

import java.awt.image.BufferedImage;

import org.lwjgl.util.vector.Vector3f;

import graphics.Light;
import graphics.Renderer;
import model.Loader;

public class World {

	private Terrain terrain;
	private Water water;
	private Light sun = new Light((Vector3f)new Vector3f(-1, -2, -1).normalise(), new Vector3f(1, 1, 1), true);
	
	private BufferedImage heightMap;
	private float terrainHeight;
	private float snowHeight = 1;
	private float rockHeight = 1;
	private float sandHeight = 0;
	private float waterHeight = -1;
	private float waveHeight = 0;
	private float waveSpeed = 0;

	private Wall redWall;
	private Wall purpleWall;
	
	public World(String file) {
		readFile(file);
		terrain = new Terrain(terrainHeight, heightMap, rockHeight, snowHeight, sandHeight);
		if(waterHeight != -1) {
			water = new Water(terrainHeight * waterHeight, heightMap.getWidth(), waveSpeed);
		}
		Renderer.changeWaveHeight(waveHeight);
	}
	
	private void readFile(String file) {
		String data = Loader.loadFile(file);
		String[] tokens = data.split("\\s+");
		
		int wallAllign = -1;
		float wallHeight = -1;
		float wallWidth = -1;
		float wallRed = -1;
		float wallPurple = -1;
		
		for(int i = 0; i < tokens.length / 2; i++) {
			String code = tokens[i * 2];
			String value = tokens[i * 2 + 1];
			if(code.equals("heightMap")) {
				heightMap = Loader.loadImage(value);
			} else if(code.equals("waterHeight")) {
				waterHeight = Float.parseFloat(value);
			} else if(code.equals("rockHeight")) {
				rockHeight = Float.parseFloat(value);
			} else if(code.equals("snowHeight")) {
				snowHeight = Float.parseFloat(value);
			} else if(code.equals("sandHeight")) {
				sandHeight = Float.parseFloat(value);
			} else if(code.equals("terrainHeight")) {
				terrainHeight = Float.parseFloat(value);
			} else if(code.equals("waveHeight")) {
				waveHeight = Float.parseFloat(value);
			} else if(code.equals("waveSpeed")) {
				waveSpeed = Float.parseFloat(value);
			} else if(code.equals("wallAllign")) { 
				if(value.equals("x")) {
					wallAllign = 0;
				} if(value.equals("z")) {
					wallAllign = 1;
				}
			} else if(code.equals("wallHeight")) {
				wallHeight = Float.parseFloat(value);
			} else if(code.equals("wallWidth")) {
				wallWidth = Float.parseFloat(value);
			} else if(code.equals("wallRed")) {
				wallRed = Float.parseFloat(value);
			} else if(code.equals("wallPurple")) {
				wallPurple = Float.parseFloat(value);
			} else {
				System.err.println("Unknown world code: " + code);
			}
		}
		
		if(wallAllign != -1 && wallHeight != -1 && wallWidth != -1) {
			if(wallRed != -1) {
				redWall = new Wall(true, wallRed, wallAllign == 0, wallHeight, wallWidth, heightMap.getWidth(), terrainHeight);
			} if(wallPurple != -1) {
				purpleWall = new Wall(false, wallPurple, wallAllign == 0, wallHeight, wallWidth, heightMap.getWidth(), terrainHeight);
			}
		}
	}
	
	public void update() {
		
	}
	
	public void render() {
		Renderer.prepareTerrainShader(sun);
		terrain.render();
		if(redWall != null) { redWall.render(); }
		if(purpleWall != null) { purpleWall.render(); }
		Renderer.endTerrainRendering();
		
		if(water != null) {
			Renderer.prepareWaterRenderer(sun, water.getWaveOffset());
			water.render();
			Renderer.endWaterRendering();
		}
	}
}
