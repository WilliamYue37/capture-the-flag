package world;

import org.lwjgl.util.vector.Vector3f;

import model.Loader;
import model.Model;

public class Wall {

	private Model model;
	
	private boolean xAxis;
	private float f;
	private float height;
	private float width;
	
	public Wall(boolean red, float f, boolean xAxis, float height, float width, float terrainSize, float terrainHeight) {
		this.f = f;
		this.xAxis = xAxis;
		this.height = height;
		this.width = width;
		createModel(terrainSize, terrainHeight, red);
	}
	
	private void storePosition(int i, Vector3f position, float[] positions) {
		positions[i * 3] = position.x;
		positions[i * 3 + 1] = position.y;
		positions[i * 3 + 2] = position.z;
	}
	
	private void createModel(float terrainSize, float terrainHeight, boolean red) {
		float[] positions = new float[24];
		
		float xOffset = xAxis ? terrainSize / 2 : width * terrainSize / 2;
		float zOffset = xAxis ? width * terrainSize / 2 : terrainSize / 2;
		float x = xAxis ? terrainSize / 2 : f * terrainSize;
		float z = xAxis ? f * terrainSize : terrainSize / 2;
		storePosition(0, new Vector3f(x + xOffset, 0, z + zOffset), positions);
		storePosition(1, new Vector3f(x - xOffset, 0, z + zOffset), positions);
		storePosition(2, new Vector3f(x + xOffset, 0, z - zOffset), positions);
		storePosition(3, new Vector3f(x - xOffset, 0, z - zOffset), positions);
		
		storePosition(4, new Vector3f(x + xOffset, terrainHeight * height, z + zOffset), positions);
		storePosition(5, new Vector3f(x - xOffset, terrainHeight * height, z + zOffset), positions);
		storePosition(6, new Vector3f(x + xOffset, terrainHeight * height, z - zOffset), positions);
		storePosition(7, new Vector3f(x - xOffset, terrainHeight * height, z - zOffset), positions);
		
		float[] colors = new float[24];
		for(int i = 0; i < 8; i++) {
			colors[i * 2] = 1;
			colors[i * 3 + 2] = red ? 0 : 1;
		}
		
		int[] indices = { 0,4,1, 1,4,5, 2,3,6, 3,7,6 };
		
		model = Loader.loadToTerrainVAO(positions, colors, indices);
	}
	
	public void render() {
		model.render();
	}
}
