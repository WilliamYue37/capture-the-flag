package main;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import graphics.Camera;
import graphics.DisplayManager;
import graphics.Renderer;
import model.Loader;
import world.World;

public class Main {

	public static void main(String[] args) {
		DisplayManager.createDisplay(1200, 800, "Capture The Flag");
		Renderer.createRenderer();
		Camera camera = new Camera(new Vector3f());
		World world = new World("splitWorld");
		
		while(!Display.isCloseRequested()) {
			world.update();
			camera.update();
			Renderer.prepare(camera.toMatrix());
			world.render();
			DisplayManager.updateDisplay();
		}
		
		Loader.destroy();
		Renderer.destory();
		DisplayManager.closeDisplay();
	}
}
