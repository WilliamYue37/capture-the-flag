package graphics;

import org.lwjgl.util.vector.Vector3f;

public class Light {

	private Vector3f position;
	private Vector3f color;
	private Vector3f direction;
	private boolean directional;
	
	public Light(Vector3f vec, Vector3f color, boolean directional) {
		this.directional = directional;
		if(directional) {
			direction = vec;
		} else {
			position = vec;
		}
		
		this.color = color;
	}

	public Vector3f getPosition() {
		return position;
	}

	public Vector3f getColor() {
		return color;
	}

	public void setColor(Vector3f color) {
		this.color = color;
	}

	public Vector3f getDirection() {
		return direction;
	}
	
	public boolean isDirectional() {
		return directional;
	}
}
