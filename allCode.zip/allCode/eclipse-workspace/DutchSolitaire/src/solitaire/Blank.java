package solitaire;

public class Blank extends Card {

	private int x;
	private int y;
	
	public Blank() {
		super(0, 15);
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
