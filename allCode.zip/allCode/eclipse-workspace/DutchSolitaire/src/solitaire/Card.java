package solitaire;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import main.Main;

public class Card {

	protected static final int WIDTH = Main.WIDTH / 14;
	protected static final int HEIGHT = Main.HEIGHT / 4;
	
	protected static final int HEARTS = 0;
	protected static final int CLUBS = 1;
	protected static final int DIAMONDS = 2;
	protected static final int SPADES = 3;
	
	private final int suit;
	private final int value;
	private BufferedImage image;
	
	public Card(int suit, int value) {
		this.suit = suit;
		this.value = value;
		loadImage();
	}
	
	public void draw(Graphics g, int x, int y) {
		g.drawImage(image, x * WIDTH, y * HEIGHT, WIDTH, HEIGHT, null);
	}
	
	private void loadImage() {
		String name = value + "";
		
		switch(suit) {
		case HEARTS : 
			name += "h";
			break;
		case CLUBS :
			name += "c";
			break;
		case DIAMONDS :
			name += "d";
			break;
		case SPADES :
			name += "s";
			break;
		}
		
		image = Main.loadImage(name);
	}
	
	protected int getValue() {
		return value;
	}
	
	protected int getSuit() {
		return suit;
	}
}
