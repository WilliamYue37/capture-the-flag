package solitaire;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class Solitaire {
	
	private Card[][] cards = new Card[14][4];
	
	private boolean tileSelected;
	private int selectedX;
	private int selectedY;
	
	private boolean won;
	
	public Solitaire() {
		fillBoard();
	}
	
	private boolean canMove(int x, int y) {
		if(cards[x][y] instanceof Blank) {
			if(cards[selectedX][selectedY].getValue() == 2 && x == 0) {
				return true;
			}
			
			else if((cards[selectedX][selectedY].getValue() + 1 == cards[x + 1][y].getValue() && cards[selectedX][selectedY].getSuit() == cards[x + 1][y].getSuit()) || 
					((x > 0 && cards[selectedX][selectedY].getValue() - 1 == cards[x - 1][y].getValue() && cards[selectedX][selectedY].getSuit() == cards[x - 1][y].getSuit()))) {
				return true;
			}
		}
		
		return false;
	}
	
	private void testWinner() {
		for(int j = 0; j < 4; j++) {
			int suit = cards[13][j].getSuit();
			if(!(cards[0][j] instanceof Blank)) {
				return;
			}
			
			for(int i = 1; i < 13; i++) {
				if(cards[i][j].getSuit() != suit || cards[i][j].getValue() != i + 1) {
					return;
				}
			}
		}
		
		won = false;
	}
	
	private void move(int x, int y) {
		Card temp = cards[x][y];
		cards[x][y] = cards[selectedX][selectedY];
		cards[selectedX][selectedY] = temp;
		((Blank)temp).setPosition(selectedX, selectedY);
	}
	
	public void mousePressed(int x, int y) {
		if(won) { return; }
		int tileX = x / Card.WIDTH;
		if(tileX == 13) { return; }
		int tileY = y / Card.HEIGHT;
		
		boolean testSelected = !tileSelected;
		
		if(tileSelected) {
			if(canMove(tileX, tileY)) {
				move(tileX, tileY);
				tileSelected = false;
			} else {
				testSelected = true;
			}
		}
		
		if(testSelected) {
			if(!(cards[tileX][tileY] instanceof Blank)) {
				selectedX = tileX;
				selectedY = tileY;
				tileSelected = true;
			}
		}
		
		testWinner();
	}
	
	private void fillBoard() {
		List<Card> allCards = new ArrayList<Card>();
		for(int value = 2; value < 15; value++) {
			for(int suit = 0; suit < 4; suit++) {
				if(value == 14) {
					allCards.add(new Blank());
				} else {
					allCards.add(new Card(suit, value));
				}
			}
		}
		
		for(int i = 0; i < 13; i++) {
			for(int j = 0; j < 4; j++) {
				Card card = allCards.remove((int)(Math.random() * allCards.size()));
				if(card instanceof Blank) {
					((Blank)card).setPosition(i, j);
				}
				cards[i][j] = card;
			}
		}
		
		List<Integer> aces = new ArrayList<Integer>();
		aces.add(0); aces.add(1); aces.add(2); aces.add(3);
		for(int j = 0; j < 4; j++) {
			int card = (int)(Math.random() * aces.size());
			cards[13][j] = new Card(aces.remove(card), 14);
		}
	}

	public boolean won() {
		return won;
	}
	
	public void draw(Graphics g) {
		for(int i = 0; i < 14; i++) {
			for(int j = 0; j < 4; j++) {
			cards[i][j].draw(g, i, j);
			}
		}
			
		if(tileSelected) {
			g.setColor(Color.RED);
			for(int i = 0; i < 10; i++) {
				g.drawRect(selectedX * Card.WIDTH + i, selectedY * Card.HEIGHT + i, Card.WIDTH - i * 2, Card.HEIGHT - i * 2);
			}
		}
	}
}
