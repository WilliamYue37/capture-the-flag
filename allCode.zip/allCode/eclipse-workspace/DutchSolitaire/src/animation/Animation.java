package animation;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public abstract class Animation {

	protected int size;
	
	protected int x;
	protected float y;
	
	protected boolean shouldRemove = false;
	protected boolean completed;
	
	private long lastTime = System.currentTimeMillis();
	private int timePerFrame;
	
	private BufferedImage[] frames;
	private int currentFrame = 0;
	
	protected AnimationMaster am;
	
	public Animation(BufferedImage[] frames, int timePerFrame, AnimationMaster am, int x, int y, int size) {
		this.frames = frames;
		this.timePerFrame = timePerFrame;
		this.am = am;
		this.x = x;
		this.y = y;
		this.size = size;
	}
	
	protected abstract void destroy();
	protected abstract void updateComp();
	
	public void update() {
		updateComp();
		if(System.currentTimeMillis() - lastTime >= timePerFrame) {
			lastTime = System.currentTimeMillis();
			currentFrame++;
			if(currentFrame == frames.length) {
				currentFrame = 0;
				completed = true;
			}
		}
	}
	
	public void draw(Graphics g) {
		g.drawImage(frames[currentFrame], x, (int)y, size, size, null);
	}
}
