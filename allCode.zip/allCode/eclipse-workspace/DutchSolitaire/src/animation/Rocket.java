package animation;

public class Rocket extends Animation {
	
	private static final float SPEED = 100;
	private long lastTime = System.currentTimeMillis();
	
	private int lifeTime = (int)(Math.random() * 3000) + 3500;
	private long creationTime = System.currentTimeMillis();

	public Rocket(AnimationMaster am, int x, int y) {
		super(Assets.ROCKET_FRAMES, 500, am, x, y, (int)(Math.random() * 2) == 0 ? 64 : 128);
	}
	
	protected void updateComp() {
		y -= SPEED * (System.currentTimeMillis() - lastTime) / 1000f;
		lastTime = System.currentTimeMillis();
		if(System.currentTimeMillis() - creationTime >= lifeTime) {
			shouldRemove = true;
		}
	}
	
	protected void destroy() {
		am.addAmination(new Burst(am, x, (int)y, size));
	}
}
