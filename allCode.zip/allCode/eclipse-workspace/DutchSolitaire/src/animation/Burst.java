package animation;

public class Burst extends Animation {

	public Burst(AnimationMaster am, int x, int y, int size) {
		super(Assets.getRandomBurstFrames(), 500, am, x, y, size);
	}

	protected void updateComp() {
		if(completed) {
			shouldRemove = true;
		}
	}
	
	protected void destroy() {}
}
