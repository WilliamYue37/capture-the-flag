package animation;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class Assets {

	public static BufferedImage[] ROCKET_FRAMES;
	
	private static BufferedImage[] red_burst;
	private static BufferedImage[] blue_burst;
	private static BufferedImage[] purple_burst;
	public static BufferedImage[] getRandomBurstFrames() {
		int i = (int)(Math.random() * 3);
		if(i == 0) {
			return red_burst;
		} else if(i == 1) {
			return purple_burst;
		} else {
			return blue_burst;
		}
	}
	
	public static void createAssets() {
		ROCKET_FRAMES = new BufferedImage[3];
		BufferedImage rocket = loadImage("rocket.png");
		int w = rocket.getWidth() / 3;
		for(int i = 0; i < 3; i++) {
			ROCKET_FRAMES[i] = rocket.getSubimage(w * i, 0, w, rocket.getHeight());
		}
		
		red_burst = new BufferedImage[5];
		blue_burst = new BufferedImage[5];
		purple_burst = new BufferedImage[5];
		BufferedImage burst = loadImage("blast.png");
		w = burst.getWidth() / 5;
		int h = burst.getHeight() / 3;
		for(int i = 0; i < 5; i++) {
			purple_burst[i] = burst.getSubimage(w * i, 0, w, h);
			blue_burst[i] = burst.getSubimage(w * i, h, w, h);
			red_burst[i] = burst.getSubimage(w * i, h * 2, w, h);
		}
	}
	
	private static BufferedImage loadImage(String name) {
		try {
			return ImageIO.read(new File("res/" + name));
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
