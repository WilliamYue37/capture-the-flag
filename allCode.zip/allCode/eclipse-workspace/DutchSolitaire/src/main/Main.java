package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import animation.AnimationMaster;
import animation.Assets;
import solitaire.Solitaire;

@SuppressWarnings("serial")
public class Main extends JPanel implements MouseListener, ActionListener, KeyListener {

	public static final int WIDTH = 800;
	public static final int HEIGHT = 500;
	private static final int Y_OFFSET = 29;
	private static final int X_OFFSET = 6;
	
	public static void main(String[] args) {
		Assets.createAssets();
		
		JFrame frame = new JFrame("Dutch Solitaire");
		frame.setSize(WIDTH + X_OFFSET, HEIGHT + Y_OFFSET);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		frame.setFocusable(true);
		Main main = new Main();
		frame.add(main);
		frame.addMouseListener(main);
		frame.addKeyListener(main);
		frame.setVisible(true);
	}
	
	private Solitaire solitaire;
	private AnimationMaster am;
	
	private Main() {
		solitaire = new Solitaire();
		repaint();
	}
	
	public void actionPerformed(ActionEvent e) {
		am.update();
		repaint();
	}
	
	public void paint(Graphics g) {
		if(am == null) {
			solitaire.draw(g);
		} else {
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, WIDTH, HEIGHT);
			am.draw(g);
		}
	}
	
	public static BufferedImage loadImage(String name) {
		try {
			return ImageIO.read(new File("S:/Computer Science 3/CS3 3rd 9 weeks/Student version - DutchSolitaire/Labs07/CardImages/" + name + ".gif"));
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private void displayWinner() {
		am = new AnimationMaster();
		Timer timer = new Timer(10, this);
		timer.start();
		repaint();
	}
	
	public void mousePressed(MouseEvent e) {
		solitaire.mousePressed(e.getX() - X_OFFSET, e.getY() - Y_OFFSET);
		if(solitaire.won()) {
			displayWinner();
		}
		repaint();
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_W) {
			displayWinner();
		}
	}

	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
}
