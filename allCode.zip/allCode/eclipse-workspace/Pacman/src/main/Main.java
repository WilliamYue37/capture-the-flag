package main;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import levelEditor.LevelEditor;
import pacman.Game;

@SuppressWarnings("serial")
public class Main extends JPanel implements KeyListener, MouseListener, MouseMotionListener, ActionListener {

	public static final int WIDTH = 600;
	public static final int EXTRA_WIDTH= 200;
	public static final int HEIGHT = 800;
	private static final int Y_OFFSET = 28;
	private static final int X_OFFSET = 4;
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("Chess");
		frame.setSize(WIDTH + EXTRA_WIDTH + X_OFFSET, HEIGHT + Y_OFFSET);
		frame.setLocationRelativeTo(null);
		frame.setFocusable(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Main main = new Main();
		frame.add(main);
		frame.addKeyListener(main);
		frame.addMouseListener(main);
		frame.addMouseMotionListener(main);
		frame.setVisible(true);
	}

	private boolean inGame;
	private LevelEditor levelEditor;
	private Game game;
	
	private Main() {
		inGame = JOptionPane.showConfirmDialog(null, "No for game, yes for editor") == JOptionPane.NO_OPTION;
		if(inGame) {
			game = new Game();
		} else {
			levelEditor = new LevelEditor();
		}
		
		
		Timer timer = new Timer(25, this);
		timer.start();
	}
	
	public void paint(Graphics g) {
		if(inGame) {
			game.draw(g);
		} else {
			levelEditor.draw(g);
		}
	}

	private static boolean[] keys = new boolean[255];
	private static boolean[] lastKeys = new boolean[255];
	
	public void keyPressed(KeyEvent e) {
		keys[e.getKeyCode()] = true;
	}
	
	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}
	
	public static boolean isKeyDown(int key) {
		return keys[key];
	}
	
	public void keyTyped(KeyEvent e) {}

	public void actionPerformed(ActionEvent e) {
		if(inGame) {
			game.update();
		} else {
			levelEditor.update();
		}
		
		repaint();
		lastMouseDown = mouseDown;
		for(int i = 0; i < 255; i++) {
			lastKeys[i] = keys[i];
		}
	}
	
	public static BufferedImage loadImage(String path) {
		try {
			return ImageIO.read(new File("res/" + path));
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	private static int mouseX = 0;
	private static int mouseY = 0;
	private static boolean lastMouseDown;
	private static boolean mouseDown;
	
	public static int getMouseX() {
		return mouseX - X_OFFSET;
	}
	
	public static int getMouseY() {
		return mouseY - Y_OFFSET;
	}
	
	public static boolean isMouseDown() {
		return mouseDown;
	}
	
	public static boolean isMousePressed() {
		return mouseDown && !lastMouseDown;
	}
	
	public static boolean isKeyPressed(int key) {
		return keys[key] && !lastKeys[key];
	}
	
	public void mousePressed(MouseEvent e) {
		mouseDown = true;
	}
	
	public void mouseReleased(MouseEvent e) {
		mouseDown = false;
	}
	
	public void mouseDragged(MouseEvent e) {
		mouseX = e.getX();
		mouseY = e.getY();
	}

	public void mouseMoved(MouseEvent e) {
		mouseX = e.getX();
		mouseY = e.getY();
	}

	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
}
