package levelEditor;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import javax.swing.JOptionPane;

import board.Board;
import main.Main;

public class LevelEditor {

	private Board board;
	
	private Rectangle[] buttons = new Rectangle[9];
	private int currentTileType;
	
	private static final int DOT = 0;
	private static final int POWER_DOT = 1;
	private static final int WALL = 2;
	private static final int BORDER = 3;
	private static final int RED_START = 4;
	private static final int PINK_START = 5;
	private static final int BLUE_START = 6;
	private static final int ORANGE_START = 7;
	private static final int PLAYER_START = 8;
	
	public LevelEditor() {
		for(int i = 0; i < buttons.length; i++) {
			buttons[i] = new Rectangle(Main.WIDTH + Main.EXTRA_WIDTH / 2 - 32, 10 + i * 72, 64, 64);
		}
		
		openNewLevel();
	}
	
	private void openNewLevel() {
		String levelNumber = JOptionPane.showInputDialog("Enter number of level to edit");
		int number = Integer.parseInt(levelNumber);
		if(JOptionPane.showConfirmDialog(null, "No for new level, yes to load level") == JOptionPane.NO_OPTION) {
			String levelSize = JOptionPane.showInputDialog("Enter tile size for new level");
			int size = Integer.parseInt(levelSize);
			board = new Board(number, size);
		} else {
			board = new Board(number);
		}
	}
	
	public void update() {
		if(Main.isKeyPressed(KeyEvent.VK_DELETE)) {
			for(int x = 0; x < board.getWidth(); x++) {
				for(int y = 0; y < board.getHeight(); y++) {
					board.changeTile(x, y, Board.DOT);
				}
			}
		}
		
		if(Main.isKeyPressed(KeyEvent.VK_L)) {
			openNewLevel();
		}
		
		if(Main.isKeyPressed(KeyEvent.VK_S)) {
			board.writeFile();
		}
		
		if(Main.isMousePressed()) {
			int x = Main.getMouseX() / board.getSize();
			int y = Main.getMouseY() / board.getSize();
			board.changeTile(x, y, convertTileType());
			
			for(int i = 0; i < buttons.length; i++) {
				if(buttons[i].contains(Main.getMouseX(), Main.getMouseY())) {
					currentTileType = i;
				}
			}
		}
	}
	
	public void draw(Graphics g) {
		board.draw(g, true);
		
		g.setColor(Color.GRAY);
		g.fillRect(Main.WIDTH, 0, Main.EXTRA_WIDTH, Main.HEIGHT);
		for(int i = 0; i < buttons.length; i++) {
			drawTile(g, buttons[i].x, buttons[i].y, buttons[i].width, buttons[i].height, i);
		}
	}
	
	public void drawTile(Graphics g, int x, int y, int width, int height, int i) {
		if(i == currentTileType) {
			g.setColor(Color.RED);
			g.fillRect(x - 2, y - 2, width + 4, height + 4);
		}
		
		if(i == DOT || i == POWER_DOT) {
			g.setColor(Color.BLACK);
		} else if(i == WALL) {
			g.setColor(Color.BLUE);
		} else if(i == BORDER) {
			g.setColor(Color.WHITE);
		} if(i == RED_START) {
			g.setColor(Color.RED);
		} else if(i == PINK_START) {
			g.setColor(Color.PINK);
		} else if(i == ORANGE_START) {
			g.setColor(Color.ORANGE);
		} else if(i == BLUE_START) {
			g.setColor(Color.CYAN);
		} else if(i == PLAYER_START) {
			g.setColor(Color.YELLOW);
		}
		
		g.fillRect(x, y, width, height);
		if(i == POWER_DOT) {
			g.setColor(Color.WHITE);
			g.fillOval(x + width / 4, y + height / 4, width / 2, height / 2);
		}
	}
	
	private char convertTileType() {
		switch(currentTileType) {
		case DOT : return Board.DOT;
		case POWER_DOT : return Board.POWER_DOT;
		case WALL : return Board.WALL;
		case BORDER : return Board.BORDER;
		case RED_START : return Board.RED;
		case PINK_START : return Board.PINK;
		case BLUE_START : return Board.BLUE;
		case ORANGE_START : return Board.ORANGE;
		case PLAYER_START : return Board.PLAYER_START;
		default : return Board.WALL;
		}
	}
}
