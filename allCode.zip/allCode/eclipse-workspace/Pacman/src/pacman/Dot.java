package pacman;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import board.Board;

public class Dot {

	private Player player;
	protected int size;
	protected int x;
	protected int y;
	
	private boolean shouldRemove = false;
	
	public Dot(Board board, int x, int y, Player player) {
		size = board.getSize() / 4;
		this.x = x * board.getSize() + board.getSize() / 2;
		this.y = y * board.getSize() + board.getSize() / 2;
		this.player = player;
	}
	
	public void update() {
		if(player.getBounds().intersects(new Rectangle(x - size / 2, y - size / 2, size, size))) {
			shouldRemove = true;
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillOval(x - size / 2, y - size / 2, size, size);
	}
	
	public boolean shouldRemove() {
		return shouldRemove;
	}
	
	public void setPlayer(Player player) {
		this.player = player;
	}
}
