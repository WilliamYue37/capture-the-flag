package pacman;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import board.Board;
import main.Main;

public class Player {

	private static final int UP = 0;
	private static final int DOWN = 1;
	private static final int LEFT = 2;
	private static final int RIGHT = 3;
	
	private int requestedDirection = LEFT;
	private int currentDirection = LEFT;
	
	private Board board;
	private int x;
	private int y;
	private int size;
	
	private int speed;
	
	public Player(Board board, int x, int y) {
		this.board = board;
		this.size = board.getSize() - 2;
		this.x = x * board.getSize() + 1;
		this.y = y * board.getSize() + 1;
		speed = board.getSize() / 10;
	}
	
	private boolean canMove(int x, int y) {
		int tileX = x / board.getSize();
		int tileY = y / board.getSize();
		char c = board.tileAt(tileX, tileY);
		return c == Board.DOT || c == Board.PLAYER_START || c == Board.POWER_DOT;
	}
	
	private boolean canMove(int direction) {
		Rectangle bounds = getBounds();
		switch(direction) {
		case UP :
			bounds.y -= speed;
			break;
		case DOWN :
			bounds.y += speed;
			break;
		case LEFT :
			bounds.x -= speed;
			break;
		case RIGHT :
			bounds.x += speed;
			break;
		}
		
		return canMove(bounds.x, bounds.y) && canMove(bounds.x + bounds.width, bounds.y) && 
				canMove(bounds.x, bounds.y + bounds.height) && canMove(bounds.x + bounds.width, bounds.y + bounds.height);
	}
	
	private void updateInput() {
		if(Main.isKeyPressed(KeyEvent.VK_UP)) {
			requestedDirection = UP;
		} if(Main.isKeyPressed(KeyEvent.VK_DOWN)) {
			requestedDirection = DOWN;
		} if(Main.isKeyPressed(KeyEvent.VK_LEFT)) {
			requestedDirection = LEFT;
		} if(Main.isKeyPressed(KeyEvent.VK_RIGHT)) {
			requestedDirection = RIGHT;
		}
	}
	
	public void update() {
		updateInput();
		
		if(canMove(requestedDirection)) {
			currentDirection = requestedDirection;
		}
		
		if(canMove(currentDirection)) {
			switch(currentDirection) {
			case UP :
				y -= speed;
				break;
			case DOWN :
				y += speed;
				break;
			case LEFT :
				x -= speed;
				break;
			case RIGHT :
				x += speed;
				break;
			}
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.YELLOW);
		g.fillOval(x, y, size, size);
	}
	
	public Rectangle getBounds() {
		return new Rectangle(x, y, size, size);
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
