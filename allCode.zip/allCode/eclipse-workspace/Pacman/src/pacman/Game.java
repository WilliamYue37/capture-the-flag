package pacman;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import board.Board;
import main.Main;

public class Game {

	private static final int DOT_SCORE = 10;
	private static final int POWER_DOT_SCORE = 100;
	
	private Board board;
	private Player player;
	
	private List<Dot> dots;
	private List<Ghost> ghosts;
	
	private int score;
	private int currentLevel;
	
	public Game() {
		currentLevel = 1;
		setGame(currentLevel, true);
	}
	
	public void playerDead() {
		setGame(currentLevel, false);
	}
	
	private void setGame(int level, boolean isNew) {
		board = new Board(level);
		ghosts = new ArrayList<Ghost>();
		if(isNew) {
			dots = new ArrayList<Dot>();
		}
		
		Point playerPosition = board.findPoint(Board.PLAYER_START);
		player = new Player(board, playerPosition.x, playerPosition.y);
		
		if(isNew) {
			for(int x = 0; x < board.getWidth(); x++) {
				for(int y = 0; y < board.getHeight(); y++) {
					if(board.tileAt(x, y) == Board.DOT) {
						dots.add(new Dot(board, x, y, player));
					} else if(board.tileAt(x, y) == Board.POWER_DOT) {
						dots.add(new PowerDot(board, x, y, player));
					}
				}
			}
		} else {
			for(Dot dot : dots) {
				dot.setPlayer(player);
			}
		}
		
		Point redPoint = board.findPoint(Board.RED);
		Point pinkPoint = board.findPoint(Board.PINK);
		Point bluePoint = board.findPoint(Board.BLUE);
		Point orangePoint = board.findPoint(Board.ORANGE);
		ghosts.add(new Ghost(Ghost.RED, this, player, redPoint.x, redPoint.y));
		ghosts.add(new Ghost(Ghost.PINK, this, player, pinkPoint.x, pinkPoint.y));
		ghosts.add(new Ghost(Ghost.BLUE, this, player, bluePoint.x, bluePoint.y));
		ghosts.add(new Ghost(Ghost.ORANGE, this, player, orangePoint.x, orangePoint.y));
	}
	
	public void update() {
		player.update();
		
		for(int i = 0; i < ghosts.size(); i++) {
			ghosts.get(i).update();
		}
		
		for(int i = 0; i < dots.size(); i++) {
			dots.get(i).update();
			if(dots.get(i).shouldRemove()) {
				if(dots.remove(i--) instanceof PowerDot) {
					score += POWER_DOT_SCORE;
					for(Ghost ghost : ghosts) {
						ghost.setBlue();
					}
				} else {
					score += DOT_SCORE;
				}
			}
		}
		
		if(dots.size() == 0) {
			setGame(++currentLevel, true);
		}
	}
	
	public void draw(Graphics g) {
		board.draw(g, false);
		for(Dot dot : dots) {
			dot.draw(g);
		}
		player.draw(g);
		for(Ghost ghost : ghosts) {
			ghost.draw(g);
		}
		
		g.setColor(Color.WHITE);
		g.fillRect(Main.WIDTH, 0, Main.EXTRA_WIDTH, Main.HEIGHT);
		g.setColor(Color.BLUE);
		g.drawString(score + "", Main.WIDTH + Main.EXTRA_WIDTH / 2, 100);
	}
	
	public Board getBoard() {
		return board;
	}
	
	public void addPoints(int points) {
		score += points;
	}
}
