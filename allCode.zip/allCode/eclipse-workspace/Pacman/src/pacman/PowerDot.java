package pacman;

import board.Board;

public class PowerDot extends Dot {

	private int minSize;
	private int maxSize;
	
	public PowerDot(Board board, int x, int y, Player player) {
		super(board, x, y, player);
		minSize = board.getSize() / 3;
		maxSize = board.getSize() * 2 / 3;
	}
	
	private static final float SCALE = 3;
	private long lastTime = System.currentTimeMillis();
	private float timer = 0;
	public void update() {
		super.update();
		timer += (System.currentTimeMillis() - lastTime) / 1000f;
		lastTime = System.currentTimeMillis();
		size = (int)(Math.abs(Math.sin(timer * SCALE)) * (maxSize - minSize)) + minSize;
	}
}
