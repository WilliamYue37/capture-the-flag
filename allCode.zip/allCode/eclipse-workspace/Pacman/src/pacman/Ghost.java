package pacman;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.List;

import board.Board;
import pathfinder.Pathfinder;

public class Ghost {

	public static final int RED = 0;
	public static final int PINK = 1;
	public static final int BLUE = 2;
	public static final int ORANGE = 3;
	
	private Player player;
	private int color;
	private Board board;
	private Game game;
	
	private int x;
	private int y;
	private int startX;
	private int startY;
	private int size;
	
	private Pathfinder pathfinder;
	
	private int boardSize;
	
	private long stateTimer;
	private int chaseStateTime;
	private int wanderStateTime;
	private int waitStateTime;
	private int state = WAIT_STATE;
	private static final int CHASE_STATE = 0;
	private static final int WANDER_STATE = 1;
	private static final int BLUE_STATE = 2;
	private static final int WAIT_STATE = 3;
	private static final int EYE_STATE = 4;
	
	private static int points;
	
	public Ghost(int color, Game game, Player player, int x, int y) {
		this.game = game;
		board = game.getBoard();
		this.player = player;
		this.color = color;
		this.x = x * board.getSize() + 1;
		this.y = y * board.getSize() + 1;
		startX = x;
		startY = y;
		size = board.getSize() - 2;
		pathfinder = new Pathfinder(board);
		boardSize = board.getSize();
		speed = boardSize / 10;
		updateTarget();
		
		setStateTimes();
		stateTimer = System.currentTimeMillis();
	}
	
	private void setStateTimes() {
		switch(color) {
		case RED :
			chaseStateTime = Integer.MAX_VALUE;
			wanderStateTime = 0;
			waitStateTime = 0;
			break;
		case PINK :
			chaseStateTime = 20000;
			wanderStateTime = 2000;
			waitStateTime = 2000;
			break;
		case ORANGE :
			chaseStateTime = 8000;
			wanderStateTime = 8000;
			waitStateTime = 4000;
			break;
		case BLUE :
			chaseStateTime = 12000;
			wanderStateTime = 3000;
			waitStateTime = 6000;
			break;
		}
	}
	
	private int getCurrentStateTime() {
		switch(state) {
		case CHASE_STATE :
			return chaseStateTime;
		case WANDER_STATE :
			return wanderStateTime;
		case BLUE_STATE :
			return 5000;
		case WAIT_STATE :
			return waitStateTime;
		case EYE_STATE :
			return Integer.MAX_VALUE;
		}
		
		return -1;
	}
	
	private void changeState() {
		if(state == CHASE_STATE) {
			state = WANDER_STATE;
		} else {
			state = CHASE_STATE;
		}
	}
	
	public void setBlue() {
		points = 200;
		if(state != EYE_STATE) {
			state = BLUE_STATE;
			stateTimer = System.currentTimeMillis();
			updateTarget();
		}
	}
	
	private Point getRandomPoint() {
		int x = (int)(Math.random() * board.getWidth());
		int y = (int)(Math.random() * board.getHeight());
		if(board.tileAt(x, y) == Board.WALL) {
			return getRandomPoint();
		} else {
			return new Point(x, y);
		}
	}
	
	private void updateTarget() {
		List<Point> path = null;
		int tileTargetX = -1;
		int tileTargetY = -1;
		switch(state) {
		case CHASE_STATE :
			tileTargetX = player.getX() / boardSize;
			tileTargetY = player.getY() / boardSize;
			break;
		case WAIT_STATE :
			targetX = x;
			targetY = y;
			return;
		case WANDER_STATE :
		case BLUE_STATE :
			Point point = getRandomPoint();
			tileTargetX = point.x;
			tileTargetY = point.y;
			break;
		case EYE_STATE :
			tileTargetX = startX;
			tileTargetY = startY;
		}
		
		path = pathfinder.getPathTo(x / boardSize, y / boardSize, tileTargetX, tileTargetY);
		int target = 0;
		if(path.size() >= 2) {
			target = path.size() - 2;
		}
		targetX = path.get(target).x * boardSize + 1;
		targetY = path.get(target).y * boardSize + 1;
	}
	
	private void testCollision() {
		if(state != EYE_STATE && player.getBounds().intersects(new Rectangle(x, y, size, size))) {
			if(state == BLUE_STATE) {
				state = EYE_STATE;
				stateTimer = System.currentTimeMillis();
				game.addPoints(points);
				points *= 2;
			} else {
				game.playerDead();
			}
		}
	}
	
	private int speed;
	private int targetX;
	private int targetY;
	public void update() {
		if(System.currentTimeMillis() - stateTimer >= getCurrentStateTime()) {
			stateTimer = System.currentTimeMillis();
			changeState();
			updateTarget();
		}

		if(targetX > x) {
			x += speed;
			if(targetX < x) {
				x = targetX;
			}
		} else if(targetX < x) {
			x -= speed;
			if(targetX > x) {
				x = targetX;
			}
		} else if(targetY > y) {
			y += speed;
			if(targetY < y) {
				targetY = y;
			}
		} else if(targetY < y) {
			y -= speed;
			if(targetY > y) {
				y = targetY;
			}
		} else {
			updateTarget();
		}
		
		if(state == EYE_STATE && x / boardSize == startX && y / boardSize == startY) {
			state = CHASE_STATE;
			stateTimer = System.currentTimeMillis();
		}
		
		testCollision();
	}
	
	private void setColor(Graphics g) {
		switch(color) {
		case RED :
			g.setColor(Color.RED);
			break;
		case PINK :
			g.setColor(Color.PINK);
			break;
		case BLUE :
			g.setColor(Color.CYAN);
			break;
		case ORANGE :
			g.setColor(Color.ORANGE);
			break;
		}
	}
	
	public void draw(Graphics g) {
		if(state == BLUE_STATE) {
			int stateTimer = (int)(System.currentTimeMillis() - this.stateTimer);
			if(stateTimer > 3500 && stateTimer % 250 > 125) {
				setColor(g);
			} else {
				g.setColor(Color.BLUE);
			}
		} else if(state == EYE_STATE) {
			g.setColor(Color.WHITE);
		} else {
			setColor(g);
		}
		
		g.fillOval(x, y, size, size);
	}
}
