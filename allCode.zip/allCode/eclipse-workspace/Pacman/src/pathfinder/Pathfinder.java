package pathfinder;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

import board.Board;

public class Pathfinder {

	private Node[][] nodes;
	private int width;
	private int height;
	
	public Pathfinder(Board board) {
		width = board.getWidth();
		height = board.getHeight();
		nodes = new Node[width][height];
		fillMovement(board);
	}
	
	private void fillMovement(Board board) {
		for(int x = 0; x < width; x++) {
			for(int y = 0; y < height; y++) {
				nodes[x][y] = new Node(x, y, board.tileAt(x, y) == Board.WALL);
			}
		}
	}
	
	private void addNode(Queue<Node> openList, List<Node> closedList, Node parent, int x, int y, int startX, int startY, int targetX, int targetY) {
		if(x >= 0 && x < width && y >= 0 && y < height && !nodes[x][y].isSolid() && !closedList.contains(nodes[x][y])) {
			if(openList.contains(nodes[x][y])) {
				nodes[x][y].update(parent);
			} else {
				openList.add(nodes[x][y]);
				nodes[x][y].update(startX, startY, targetX, targetY, parent);
			}
		}
	}
	
	private void addNodes(Queue<Node> openList, List<Node> closedList, Node center, int startX, int startY, int targetX, int targetY) {
		int x = center.getX();
		int y = center.getY();
		addNode(openList, closedList, center, x - 1, y, startX, startY, targetX, targetY);
		addNode(openList, closedList, center, x + 1, y, startX, startY, targetX, targetY);
		addNode(openList, closedList, center, x, y - 1, startX, startY, targetX, targetY);
		addNode(openList, closedList, center, x, y + 1, startX, startY, targetX, targetY);
	}
	
	private List<Point> tracePath(Node node) {
		List<Point> path = new ArrayList<Point>();
		while(node != null) {
			path.add(node.getPoint());
			node = node.getParent();
		}
		
		return path;
	}
	
	public List<Point> getPathTo(int startX, int startY, int targetX, int targetY) {
		Queue<Node> openList = new PriorityQueue<Node>();
		List<Node> closedList = new ArrayList<Node>();

		nodes[startX][startY].update(startX, startY, targetX, targetY);
		openList.add(nodes[startX][startY]);
		
		while(!openList.isEmpty()) {
			Node node = openList.remove();
			closedList.add(node);
			
			if(node.equals(nodes[targetX][targetY])) {
				return tracePath(node);
			}
			
			closedList.add(node);
			addNodes(openList, closedList, node, startX, startY, targetX, targetY);
		}
		
		return null;
	}
}
