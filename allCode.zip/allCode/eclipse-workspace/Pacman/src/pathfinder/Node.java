package pathfinder;

import java.awt.Point;

public class Node implements Comparable<Node> {

	private final Point point;
	private final int x;
	private final int y;
	private final boolean solid;
	
	private int hCost;
	private int gCost;
	private int fCost;
	private Node parent;
	
	public Node(int x, int y, boolean solid) {
		this.x = x;
		this.y = y;
		this.solid = solid;
		point = new Point(x, y);
	}
	
	public void update(Node parent) {
		if(this.parent == null || parent.gCost < this.parent.gCost) {
			this.parent = parent;
		}
	}
	
	public void update(int startX, int startY, int targetX, int targetY, Node parent) {
		gCost = (int)Math.sqrt((startX - x) * (startX - x) + (startY - y) * (startY - y));
		hCost = (int)Math.sqrt((targetX - x) * (targetX - x) + (targetY - y) * (targetY - y));
		fCost = gCost + hCost;
		this.parent = parent;
	}
	
	public void update(int startX, int startY, int targetX, int targetY) {
		update(startX, startY, targetX, targetY, null);
	}
	
	public Node getParent() {
		return parent;
	}
	
	public Point getPoint() {
		return point;
	}
	
	public int getFCost() {
		return fCost;
	}
	
	public boolean isSolid() {
		return solid;
	}
	
	public int compareTo(Node node) {
		return fCost - node.getFCost();
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public boolean equals(Object o) {
		if(o instanceof Node) {
			Node node = (Node)o;
			return node.x == x && node.y == y;
		} else {
			return false;
		}
	}
}
