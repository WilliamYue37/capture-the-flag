package board;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import main.Main;

public class Board {

	public static final char DOT = (char)0;
	public static final char WALL = 'w';
	public static final char RED = 'r';
	public static final char PINK = 'p';
	public static final char BLUE = 'b';
	public static final char ORANGE = 'o';
	public static final char BORDER = 'B';
	public static final char POWER_DOT = 'P';
	public static final char PLAYER_START = 's';
	
	private String path;
	
	private char[][] tiles;
	private int width;
	private int height;
	private int size;
	
	public Board(int levelNumber, int size) {
		this.size = size;
		width = Main.WIDTH / size;
		height = Main.HEIGHT / size;
		tiles = new char[width][height];
		path = "res/levels/level" + levelNumber + ".txt";
	}
	
	public Board(int levelNumber) {
		path = "res/levels/level" + levelNumber + ".txt";
		readFile();
	}
	
	public Point findPoint(char type) {
		for(int x = 0; x < width; x++) {
			for(int y = 0; y < height; y++) {
				if(tiles[x][y] == type) {
					return new Point(x, y);
				}
			}
		}
		
		return null;
	}
	
	public char tileAt(int x, int y) {
		if(x < 0 || y < 0 || x >= width || y >= height) { return WALL; }
		return tiles[x][y];
	}
	
	public void draw(Graphics g, boolean displayCapabilities) {
		for(int x = 0; x < width; x++) {
			for(int y = 0; y < height; y++) {
				if(displayCapabilities) {
					if(tiles[x][y] == DOT || tiles[x][y] == POWER_DOT) {
						g.setColor(Color.BLACK);
					} else if(tiles[x][y] == WALL) {
						g.setColor(Color.BLUE);
					} else if(tiles[x][y] == BORDER) {
						g.setColor(Color.WHITE);
					} else if(tiles[x][y] == RED) {
						g.setColor(Color.RED);
					} else if(tiles[x][y] == PINK) {
						g.setColor(Color.PINK);
					} else if(tiles[x][y] == ORANGE) {
						g.setColor(Color.ORANGE);
					} else if(tiles[x][y] == BLUE) {
						g.setColor(Color.CYAN);
					} else if(tiles[x][y] == PLAYER_START) {
						g.setColor(Color.YELLOW);
					}
				} else {
					if(tiles[x][y] == WALL) {
						g.setColor(Color.BLUE);
					} else if(tiles[x][y] == BORDER) {
						g.setColor(Color.WHITE);
					} else {
						g.setColor(Color.BLACK);
					}
				}
				
				g.fillRect(x * size, y * size, size, size);
				if(tiles[x][y] == POWER_DOT && displayCapabilities) {
					g.setColor(Color.WHITE);
					g.fillOval(x * size + size / 4, y * size + size / 4, size / 2, size / 2);
				}
			}
		}
	}
	
	public void changeTile(int x, int y, char tile) {
		if(x < 0 || y < 0 || x >= width || y >= height) {
			return;
		}
		
		tiles[x][y] = tile;
	}
	
	public int getSize() {
		return size;
	}
	
	private void readFile() {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(path)));
			size = Integer.parseInt(reader.readLine());
			width = Integer.parseInt(reader.readLine());
			height = Integer.parseInt(reader.readLine());
			tiles = new char[width][height];
			for(int y = 0; y < height; y++) {
				String[] row = reader.readLine().split(" ");
				for(int x = 0; x < width; x++) {
					tiles[x][y] = row[x].charAt(0);
				}
			}
			
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void writeFile() {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(path)));
			writer.write(size + ""); writer.newLine();
			writer.write(width + ""); writer.newLine();
			writer.write(height + ""); writer.newLine();
			for(int y = 0; y < height; y++) {
				for(int x = 0; x < width; x++) {
					writer.write(tiles[x][y] + " ");
				}
				writer.newLine();
			}
			
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
}
