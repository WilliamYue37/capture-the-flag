package physics;

import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import chunk.Chunk;
import chunk.Cube;
import chunk.World;
import engine.physics.AABB;

public class Physics {

	private static Vector4f getNearestCollision(AABB aabb, Vector3f velocity, World world) {
		Vector4f fLow = new Vector4f(1, 1, 1, 1);
		for(Chunk[][] cAA : world.getChunks()) {
			for(Chunk[] cA : cAA) {
				for(Chunk c : cA) {
					for(Cube cube : c.getCubeShell()) {
						AABB a = cube.getAABB();
						Vector4f f = a.sweptCollision(aabb, velocity);
						if(fLow.x > f.x) {
							fLow = f;
						}
					}
				}
			}
		}
		
		return fLow;
	}

	private static final float ERROR = 0.001f;
	
	public static final int NO_COLLISION = 0;
	public static final int BOTTOM_COLLISION = -1;
	public static final int TOP_COLLISION = 1;
	public static int moveSlide(AABB aabb, Vector3f velocity, World world) {
		return moveSlide(aabb, velocity, world, NO_COLLISION);
	}
	
	private static int moveSlide(AABB aabb, Vector3f velocity, World world, int collision) {
		if(velocity.lengthSquared() <= ERROR * ERROR) { return collision; }
		
		Vector4f fLow = getNearestCollision(aabb, velocity, world);
		Vector3f move = new Vector3f(velocity);
		move.scale(fLow.x - ERROR);
		aabb.move(move);
		Vector3f newVelocity = new Vector3f(velocity);
		newVelocity.x *= fLow.y;
		newVelocity.y *= fLow.z;
		newVelocity.z *= fLow.w;
		newVelocity.scale(1 - fLow.x + ERROR);

		if(fLow.z == 0) {
			if(velocity.y > 0) {
				collision = TOP_COLLISION;
			} if(velocity.y < 0) {
				collision = BOTTOM_COLLISION;
			}
		}
		
		return moveSlide(aabb, newVelocity, world, collision);
	}
}
