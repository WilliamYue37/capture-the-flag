package chunk;

import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector3f;

import engine.model.Loader;
import engine.model.Model;
import engine.physics.AABB;

public class Chunk {

	protected static final int SIZE = 16;
	private Cube[][][] cubes = new Cube[SIZE][SIZE][SIZE];
	
	private boolean modelDated = true;
	private List<Cube> cubeShell = new ArrayList<Cube>();
	private Model model;
	
	private World world;
	private int worldX;
	private int worldY;
	private int worldZ;
	
	public Chunk(World world, int x, int y, int z, boolean fill) {
		this.world = world;
		worldX = x;
		worldY = y;
		worldZ = z;
		
		if(fill) {
			for(int a = 0; a < SIZE; a++) {
				for(int b = 0; b < SIZE; b++) {
					for(int c = 0; c < SIZE; c++) {
						Vector3f color = new Vector3f();
						color.x = (float)Math.random();
						color.y = (float)Math.random();
						color.z = (float)Math.random();
						cubes[a][b][c] = new Cube(a + x * SIZE, b + y * SIZE, c + z * SIZE, color);
					}
				}
			}
		}
	}
	
	protected boolean cubeAt(int x, int y, int z) {
		if(x < 0) { return false; }
		if(y < 0) { return false; }
		if(z < 0) { return false; }
		if(x >= SIZE) { return false; }
		if(y >= SIZE) { return false; }
		if(z >= SIZE) { return false; }
		return cubes[x][y][z] != null;
	}
	
	private void addCube(int x, int y, int z, List<Vector3f> positions, List<Vector3f> colors, List<Integer> indices) {
		if(!cubeAt(x, y, z)) { return; }
		boolean added = false;
		if(!world.cubeAt(x + worldX * SIZE, y + worldY * SIZE + 1, z + worldZ * SIZE)) { cubes[x][y][z].addFace(AABB.TOP, positions, colors, indices); added = true; }
		if(!world.cubeAt(x + worldX * SIZE, y + worldY * SIZE - 1, z + worldZ * SIZE)) { cubes[x][y][z].addFace(AABB.BOTTOM, positions, colors, indices); added = true; }
		if(!world.cubeAt(x + worldX * SIZE - 1, y + worldY * SIZE, z + worldZ * SIZE)) { cubes[x][y][z].addFace(AABB.LEFT, positions, colors, indices); added = true; }
		if(!world.cubeAt(x + worldX * SIZE + 1, y + worldY * SIZE, z + worldZ * SIZE)) { cubes[x][y][z].addFace(AABB.RIGHT, positions, colors, indices); added = true; }
		if(!world.cubeAt(x + worldX * SIZE, y + worldY * SIZE, z + worldZ * SIZE - 1)) { cubes[x][y][z].addFace(AABB.FRONT, positions, colors, indices); added = true; }
		if(!world.cubeAt(x + worldX * SIZE, y + worldY * SIZE, z + worldZ * SIZE + 1)) { cubes[x][y][z].addFace(AABB.BACK, positions, colors, indices); added = true; }
		if(added) {
			cubeShell.add(cubes[x][y][z]);
		}
	}
	
	protected void createModel() {
		modelDated = false;
		cubeShell.clear();
		List<Vector3f> positions = new ArrayList<Vector3f>();
		List<Vector3f> colors = new ArrayList<Vector3f>();
		List<Integer> indices = new ArrayList<Integer>();
		
		for(int x = 0; x < SIZE; x++) {
			for(int y = 0; y < SIZE; y++) {
				for(int z = 0; z < SIZE; z++) {
					addCube(x, y, z, positions, colors, indices);
				}
			}
		}

		Loader.createVAO();
		Loader.bindIndicesBuffer(indices);
		Loader.storeVec3DataInAttributeList(0, positions);
		Loader.storeVec3DataInAttributeList(1, colors);
		model = Loader.finalize(GL11.GL_TRIANGLES, indices.size());
	}
	
	protected void setCube(int x, int y, int z, Cube cube) {
		cubes[x][y][z] = cube;
		modelDated = true;
	}
	
	protected void neighborChanged() {
		modelDated = true;
	}
	
	protected void render() {
		if(modelDated) {
			createModel();
		}
		
		if(!cubeShell.isEmpty()) {
			model.render();
		}
	}
	
	public List<Cube> getCubeShell() {
		return cubeShell;
	}
}
