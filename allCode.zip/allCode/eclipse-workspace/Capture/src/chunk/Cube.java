package chunk;

import java.util.List;

import org.lwjgl.util.vector.Vector3f;

import engine.physics.AABB;

public class Cube {

	public static final float SIZE = 4;
	
	private static final int BOTTOM_LEFT_FRONT = 0;
	private static final int BOTTOM_LEFT_BACK = 1;
	private static final int BOTTOM_RIGHT_FRONT = 2;
	private static final int BOTTOM_RIGHT_BACK = 3;
	private static final int TOP_LEFT_FRONT = 4;
	private static final int TOP_LEFT_BACK = 5;
	private static final int TOP_RIGHT_FRONT = 6;
	private static final int TOP_RIGHT_BACK = 7;
	private Vector3f[] vertices = new Vector3f[8];

	private Face[] faces = new Face[6];
	
	private Vector3f color;
	
	private Vector3f coords;
	private int x;
	private int y;
	private int z;
	
	private AABB aabb;
	
	public Cube(int x, int y, int z, Vector3f color) {
		coords = new Vector3f(x, y, z);
		this.x = x;
		this.y = y;
		this.z = z;
		this.color = color;
		
		createGeometry();
	}
	
	private void createGeometry() {
		Vector3f base = new Vector3f(x, y, z);
		base.scale(SIZE);
		
		vertices[BOTTOM_LEFT_FRONT] = base;
		vertices[BOTTOM_LEFT_BACK] = new Vector3f(base.x, base.y, base.z + SIZE);
		vertices[BOTTOM_RIGHT_FRONT] = new Vector3f(base.x + SIZE, base.y, base.z);
		vertices[BOTTOM_RIGHT_BACK] = new Vector3f(base.x + SIZE, base.y, base.z + SIZE);
		vertices[TOP_LEFT_FRONT] = new Vector3f(base.x, base.y + SIZE, base.z);
		vertices[TOP_LEFT_BACK] = new Vector3f(base.x, base.y + SIZE, base.z + SIZE);
		vertices[TOP_RIGHT_FRONT] = new Vector3f(base.x + SIZE, base.y + SIZE, base.z);
		vertices[TOP_RIGHT_BACK] = new Vector3f(base.x + SIZE, base.y + SIZE, base.z + SIZE);
		
		aabb = new AABB(vertices[BOTTOM_LEFT_FRONT], vertices[TOP_RIGHT_BACK]);
		
		faces[AABB.TOP] = new Face(vertices[TOP_LEFT_FRONT], vertices[TOP_LEFT_BACK], vertices[TOP_RIGHT_FRONT], vertices[TOP_RIGHT_BACK], color);
		faces[AABB.BOTTOM] = new Face(vertices[BOTTOM_LEFT_FRONT], vertices[BOTTOM_RIGHT_FRONT], vertices[BOTTOM_LEFT_BACK], vertices[BOTTOM_RIGHT_BACK], color);
		faces[AABB.FRONT] = new Face(vertices[BOTTOM_LEFT_FRONT], vertices[TOP_LEFT_FRONT], vertices[BOTTOM_RIGHT_FRONT], vertices[TOP_RIGHT_FRONT], color);
		faces[AABB.BACK] = new Face(vertices[BOTTOM_LEFT_BACK], vertices[BOTTOM_RIGHT_BACK], vertices[TOP_LEFT_BACK], vertices[TOP_RIGHT_BACK], color);
		faces[AABB.LEFT] = new Face(vertices[BOTTOM_LEFT_FRONT], vertices[BOTTOM_LEFT_BACK], vertices[TOP_LEFT_FRONT], vertices[TOP_LEFT_BACK], color);
		faces[AABB.RIGHT] = new Face(vertices[BOTTOM_RIGHT_FRONT], vertices[TOP_RIGHT_FRONT], vertices[BOTTOM_RIGHT_BACK], vertices[TOP_RIGHT_BACK], color);
	}
	
	protected void addFace(int face, List<Vector3f> positions, List<Vector3f> colors, List<Integer> indices) {
		faces[face].connect(positions, colors, indices);
	}
	
	private class Face {
		
		private Vector3f a;
		private Vector3f b;
		private Vector3f c;
		private Vector3f d;
		private Vector3f color;
		
		private Face(Vector3f a, Vector3f b, Vector3f c, Vector3f d, Vector3f color) {
			this.a = a;
			this.b = b;
			this.c = c;
			this.d = d;
			this.color = color;
		}
		
		private void addPoint(Vector3f pos, List<Vector3f> positions, List<Vector3f> colors, List<Integer> indices) {
			for(int i = 0; i < positions.size(); i++) {
				if(positions.get(i).equals(pos) && colors.get(i).equals(color)) {
					indices.add(i);
					return;
				}
			}
			
			indices.add(positions.size());
			positions.add(pos);
			colors.add(color);
		}
		
		private void connect(List<Vector3f> positions, List<Vector3f> colors, List<Integer> indices) {
			addPoint(a, positions, colors, indices);
			addPoint(b, positions, colors, indices);
			addPoint(c, positions, colors, indices);
			
			addPoint(c, positions, colors, indices);
			addPoint(b, positions, colors, indices);
			addPoint(d, positions, colors, indices);
		}
	}
	
	public AABB getAABB() {
		return aabb;
	}
	
	public Vector3f getCoords() {
		return coords;
	}
	
	public Vector3f getOffsetCoords(int face) {
		Vector3f coords = new Vector3f(this.coords);
		switch(face) {
		case AABB.TOP :
			coords.y++;
			break;
		case AABB.BOTTOM :
			coords.y--;
			break;
		case AABB.LEFT :
			coords.x--;
			break;
		case AABB.RIGHT :
			coords.x++;
			break;
		case AABB.FRONT :
			coords.z--;
			break;
		case AABB.BACK :
			coords.z++;
			break;
		default :
			return null;
		}
		
		return coords;
	}
}
