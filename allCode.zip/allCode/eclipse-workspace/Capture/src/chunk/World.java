package chunk;

import org.lwjgl.util.vector.Vector3f;

import engine.physics.AABB;
import engine.util.MousePicker;
import entity.Player;

public class World {

	private Chunk[][][] chunks;
	private int width;
	private int height;
	private int length;
	
	private Player player; // player should be part of world ( map maybe to seperate out code)
	public void setPlayer(Player player) { this.player = player; }
	
	public World(int width, int height, int length) {
		chunks = new Chunk[width][height + 1][length];
		this.width = width;
		this.height = height + 1;
		this.length = length;
		
		for(int x = 0; x < width; x++) {
			for(int z = 0; z < length; z++) {
				chunks[x][height][z] = new Chunk(this, x, height, z, false);
				for(int y = 0; y < height; y++) {
					chunks[x][y][z] = new Chunk(this, x, y, z, true);
				}
			}
		}
	}
	
	public boolean cubeAt(int x, int y, int z) {
		int chunkX = x / Chunk.SIZE;
		int chunkY = y / Chunk.SIZE;
		int chunkZ = z / Chunk.SIZE;
		int cubeX = x % Chunk.SIZE;
		int cubeY = y % Chunk.SIZE; 
		int cubeZ = z % Chunk.SIZE;
		
		if(chunkOutOfBounds(chunkX, chunkY, chunkZ)) { return false; }
		
		return chunks[chunkX][chunkY][chunkZ].cubeAt(cubeX, cubeY, cubeZ);
	}
	
	private boolean chunkOutOfBounds(int chunkX, int chunkY, int chunkZ) {
		if(chunkX < 0) { return true; }
		if(chunkY < 0) { return true; }
		if(chunkZ < 0) { return true; }
		if(chunkX >= width) { return true; }
		if(chunkY >= height) { return true; }
		if(chunkZ >= length) { return true; }
		return false;
	}
	
	public void render() {
		for(Chunk[][] cAA : chunks) {
			for(Chunk[] cA : cAA) {
				for(Chunk c : cA) {
					c.render();
				}
			}
		}
	}
	
	public void setCube(int x, int y, int z, Vector3f color, boolean replace) {
		if(!replace && cubeAt(x, y, z)) { return; }
		Cube cube = null;
		if(color != null) {
			cube = new Cube(x, y, z, color);
			if(cube.getAABB().intersects(player.getBounds())) {
				return;
			}
		}
		
		int chunkX = x / Chunk.SIZE;
		int chunkY = y / Chunk.SIZE;
		int chunkZ = z / Chunk.SIZE;
		int cubeX = x % Chunk.SIZE;
		int cubeY = y % Chunk.SIZE; 
		int cubeZ = z % Chunk.SIZE;
		
		if(chunkOutOfBounds(chunkX, chunkY, chunkZ) || cubeX < 0 || cubeY < 0 || cubeZ < 0) { return; }
		if(cubeX == 0 && !chunkOutOfBounds(chunkX - 1, chunkY, chunkZ)) { chunks[chunkX - 1][chunkY][chunkZ].neighborChanged(); }
		if(cubeY == 0 && !chunkOutOfBounds(chunkX, chunkY - 1, chunkZ)) { chunks[chunkX][chunkY - 1][chunkZ].neighborChanged(); }
		if(cubeZ == 0 && !chunkOutOfBounds(chunkX, chunkY, chunkZ - 1)) { chunks[chunkX][chunkY][chunkZ - 1].neighborChanged(); }
		if(cubeX == Chunk.SIZE - 1 && !chunkOutOfBounds(chunkX + 1, chunkY, chunkZ)) { chunks[chunkX + 1][chunkY][chunkZ].neighborChanged(); }
		if(cubeY == Chunk.SIZE - 1 && !chunkOutOfBounds(chunkX, chunkY + 1, chunkZ)) { chunks[chunkX][chunkY + 1][chunkZ].neighborChanged(); }
		if(cubeZ == Chunk.SIZE - 1 && !chunkOutOfBounds(chunkX, chunkY, chunkZ + 1)) { chunks[chunkX][chunkY][chunkZ + 1].neighborChanged(); }
		
		chunks[chunkX][chunkY][chunkZ].setCube(cubeX, cubeY, cubeZ, cube);
	}
	
	public void update() {
		updateMouseRayInfo();
	}
	
	public void editWorld(boolean place) {
		if(intersection == null) { return; }
		Vector3f color;
		Vector3f coords;
		
		if(place) {
			int face = intersection.getAABB().faceOfPoint(intersectionPoint);
			coords = intersection.getOffsetCoords(face);
			color = new Vector3f(1, 1, 1);
		} else {
			coords = intersection.getCoords();
			color = null;
		}
		
		if(coords != null) {
			setCube((int)coords.x, (int)coords.y, (int)coords.z, color, true);
		}
	}
	
	public Vector3f getIntersectionCubeCoords() {
		if(intersection == null) {
			return null;
		} else {
			return intersection.getCoords();
		}
	}
	
	private static final float REACH = 40;
	private Cube intersection;
	private Vector3f intersectionPoint;
	private void updateMouseRayInfo() {
		intersection = null;
		intersectionPoint =  null;
		float fLow = -1;
		Vector3f origin = player.getCamera().getPosition();
		Vector3f ray = new Vector3f(MousePicker.getCurrentRay());
		ray.scale(REACH);
		for(Chunk[][] cAA : chunks) {
			for(Chunk[] cA : cAA) {
				for(Chunk c : cA) {
					for(Cube cube : c.getCubeShell()) {
						AABB aabb = cube.getAABB();
						float f = aabb.getRayIntersection(origin, ray);
						if((f < fLow || fLow == -1) && f != -1) {
							fLow = f;
							intersection = cube;
						}
					}
				}
			}
		}

		if(intersection != null) {
			ray.scale(fLow);
			intersectionPoint = Vector3f.add(origin, ray, null);
		}
	}
	
	public Chunk[][][] getChunks() {
		return chunks;
	}
}
