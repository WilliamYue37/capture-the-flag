package main;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import chunk.World;
import chunkShader.ChunkShader;
import cubeOutlineShader.CubeOutlineShader;
import engine.graphics.Camera;
import engine.graphics.DisplayManager;
import engine.graphics.Light;
import engine.graphics.Renderer;
import engine.util.MousePicker;
import entity.Player;

public class Main {

	public static void main(String[] args) {
		DisplayManager.createDisplay(1200, 800, "Capture The Flag");
		Camera camera = new Camera(new Vector3f());
		Renderer.createRenderer(camera, 0.25f, 1, 1);
		
		DisplayManager.setCursorFixed(true);
		DisplayManager.setFixedCursorType(DisplayManager.CIRCLE);
		
		Light sun = new Light((Vector3f)new Vector3f(-1, -2, -1).normalise(), new Vector3f(1, 1, 1), true);
		World world = new World(2, 2, 2);
		ChunkShader chunkShader = new ChunkShader();
		CubeOutlineShader cubeOutlineShader = new CubeOutlineShader();
		
		Player player = new Player(new Vector3f(-10, -10, -10), camera, world);
		
		while(!Display.isCloseRequested() && !Keyboard.isKeyDown(Keyboard.KEY_END)) {
			MousePicker.update();
			world.update();
			camera.adjustFirstPerson();
			player.update();
			
			Renderer.prepare();
			
			chunkShader.start();
			chunkShader.updateSun(sun);
			world.render();
			chunkShader.stop();
			
			Vector3f coords = world.getIntersectionCubeCoords();
			if(coords != null) {
				cubeOutlineShader.start();
				cubeOutlineShader.outlineCube(coords);
				cubeOutlineShader.stop();
			}
			
			DisplayManager.updateDisplay();
		}
		
		DisplayManager.closeDisplay();
	}
}
