package entity;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector3f;

import chunk.Cube;
import chunk.World;
import engine.graphics.Camera;
import engine.graphics.DisplayManager;
import engine.physics.AABB;
import physics.Physics;

public class Player {

	private AABB bounds;
	private float angle;
	private World world;
	private Camera camera;
	
	private static final Vector3f RADIUS = new Vector3f(Cube.SIZE / 3, Cube.SIZE / 3 * 2, Cube.SIZE / 3);
	private static final float CAMERA_OFFSET = Cube.SIZE / 10;
	private static final float SPEED = 40;
	private static final float GRAVITY = -200;
	private static final float MAX_VELOCITY = 200;
	private static final float JUMP_VELOCITY = 50;
	private float yVelocity = 0;
	private boolean flying = true;
	private boolean lastFlyingPressed;
	private boolean canJump = true;
	
	private boolean lastEditMade = false;
	
	public Player(Vector3f position, Camera camera, World world) {
		this.world = world;
		world.setPlayer(this);
		this.camera = camera;
		camera.setPosition(position);
		Vector3f min = Vector3f.sub(position, RADIUS, null);
		Vector3f max = Vector3f.add(position, RADIUS, null);
		bounds = new AABB(min, max);
	}
	
	private void move() {
		if(Keyboard.isKeyDown(Keyboard.KEY_TAB) && !lastFlyingPressed) { 
			flying = !flying;
			yVelocity = 0;
		}
		lastFlyingPressed = Keyboard.isKeyDown(Keyboard.KEY_TAB);
		
		Vector3f velocity = new Vector3f();

		if(Keyboard.isKeyDown(Keyboard.KEY_W)) {
			velocity.x += (float)Math.sin(angle) * DisplayManager.getFrameTimeSeconds() * SPEED;
			velocity.z -= (float)Math.cos(angle) * DisplayManager.getFrameTimeSeconds() * SPEED;
		} if(Keyboard.isKeyDown(Keyboard.KEY_S)) {
			velocity.x -= (float)Math.sin(angle) * DisplayManager.getFrameTimeSeconds() * SPEED;
			velocity.z += (float)Math.cos(angle) * DisplayManager.getFrameTimeSeconds() * SPEED;
		}
		
		if(Keyboard.isKeyDown(Keyboard.KEY_A)) {
			velocity.x -= (float)Math.sin(angle + Math.PI / 2) * DisplayManager.getFrameTimeSeconds() * SPEED;
			velocity.z += (float)Math.cos(angle +  + Math.PI / 2) * DisplayManager.getFrameTimeSeconds() * SPEED;
		} if(Keyboard.isKeyDown(Keyboard.KEY_D)) {
			velocity.x -= (float)Math.sin(angle - Math.PI / 2) * DisplayManager.getFrameTimeSeconds() * SPEED;
			velocity.z += (float)Math.cos(angle - Math.PI / 2) * DisplayManager.getFrameTimeSeconds() * SPEED;
		}
		
		if(flying) {
			if(Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
				velocity.y += DisplayManager.getFrameTimeSeconds() * SPEED;
			} if(Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
				velocity.y -= DisplayManager.getFrameTimeSeconds() * SPEED;
			}
		} else {
			if(Keyboard.isKeyDown(Keyboard.KEY_SPACE) && canJump) {
				yVelocity = JUMP_VELOCITY;
			} else if(yVelocity > -MAX_VELOCITY) {
				yVelocity += DisplayManager.getFrameTimeSeconds() * GRAVITY;
			}
			
			velocity.y = yVelocity * DisplayManager.getFrameTimeSeconds();
		}
		
		int collision = Physics.moveSlide(bounds, velocity, world);
		if(collision != Physics.NO_COLLISION) {
			yVelocity = 0;
			canJump = collision == Physics.BOTTOM_COLLISION;
		} else {
			canJump = false;
		}

		camera.setPosition(new Vector3f(bounds.getCenter().x, bounds.getMax().y - CAMERA_OFFSET, bounds.getCenter().z));
	}
	
	public void update() {
		angle = camera.getRotation();
		move();
		editWorld();
	}
	
	private void editWorld() {
		if(Mouse.isButtonDown(0) && !lastEditMade) {
			world.editWorld(true);
		} if(Mouse.isButtonDown(1) && !lastEditMade) {
			world.editWorld(false);
		}
		
		lastEditMade = Mouse.isButtonDown(0) || Mouse.isButtonDown(1);
	}
	
	public AABB getBounds() {
		return bounds;
	}
	
	public Camera getCamera() {
		return camera;
	}
}
