package cubeOutlineShader;

import java.util.List;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import chunk.Cube;
import engine.graphics.ShaderProgram;
import engine.model.Loader;
import engine.model.Model;

public class CubeOutlineShader extends ShaderProgram {

	private static final String VERTEX_FILE = "src/cubeOutlineShader/CubeOutlineVertexShader.txt";
	private static final String FRAGMENT_FILE = "src/cubeOutlineShader/CubeOutlineFragmentShader.txt";
	
	private Model model;
	private static int location_transformationMatrix;
	
	public CubeOutlineShader() {
		super(VERTEX_FILE, FRAGMENT_FILE, true);
		createCubeModel();
	}
	
	protected void bindAttributes() {
		bindAttribute(0, "position");
		
		setAttribute(ShaderProgram.CULL_FACE, true);
		setAttribute(ShaderProgram.BLEND, true);
	}

	protected void getAllUniformLocations() {
		location_transformationMatrix = getUniformLocation("transformationMatrix");
	}

	protected void connectTextureUnits() {}
	
	private static Matrix4f transformationMatrix = new Matrix4f();
	private void updateOutlinePosition(Vector3f position) {
		transformationMatrix.setIdentity();
		Matrix4f.translate(position, transformationMatrix, transformationMatrix);
		loadMatrix(location_transformationMatrix, transformationMatrix);
	}
	
	private void createCubeModel() {
//		float a = Cube.SIZE / 8;
//		float b = Cube.SIZE - Cube.SIZE / 8;
		float c = Cube.SIZE;
		float[] positions = { 0,0,0, c,0,0, 0,c,0, c,c,0, 0,0,c, c,0,c, 0,c,c, c,c,c };
		int[] indices = { 0,2,1, 1,2,3, 4,5,6, 5,7,6, 0,1,4, 1,5,4, 2,6,3, 3,6,7, 0,4,2, 4,6,2, 1,3,5, 5,3,7 };
		
		Loader.createVAO();
		Loader.bindIndicesBuffer(indices);
		Loader.storeFloatDataInAttributeList(0, positions, 3);
		model = Loader.finalize(GL11.GL_TRIANGLES, indices.length);
	}
	
	public void outlineCubes(List<Vector3f> coords) {
		model.start();
		for(Vector3f coord : coords) {
			updateOutlinePosition(coord);
			model.draw();
		}
		model.stop();
	}
	
	public void outlineCube(Vector3f coords) {
		updateOutlinePosition((Vector3f)new Vector3f(coords).scale(Cube.SIZE));
		model.render();
	}
}
