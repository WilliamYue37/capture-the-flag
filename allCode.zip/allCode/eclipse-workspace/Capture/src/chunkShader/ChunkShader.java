package chunkShader;

import engine.graphics.Light;
import engine.graphics.ShaderProgram;

public class ChunkShader extends ShaderProgram {

	private static final String VERTEX_FILE = "src/chunkShader/ChunkVertexShader.txt";
	private static final String GEOMETRY_FILE = "src/chunkShader/ChunkGeometryShader.txt";
	private static final String FRAGMENT_FILE = "src/chunkShader/ChunkFragmentShader.txt";
	
	private int location_sunDirection;
	private int location_sunColor;
	
	public ChunkShader() {
		super(VERTEX_FILE, GEOMETRY_FILE, FRAGMENT_FILE, true);
	}

	protected void bindAttributes() {
		bindAttribute(0, "position");
		bindAttribute(1, "color");
		
		setAttribute(ShaderProgram.CULL_FACE, true);
		setAttribute(ShaderProgram.BLEND, true);
	}

	protected void getAllUniformLocations() {
		location_sunColor = getUniformLocation("sunColor");
		location_sunDirection = getUniformLocation("sunDirection");
	}
	
	protected void connectTextureUnits() {}
	
	public void updateSun(Light sun) {
		loadVector(location_sunDirection, sun.getDirection());
		loadVector(location_sunColor, sun.getColor());
	}
}
