package main;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import animation.AnimationMaster;
import animation.Assets;
import tictactoe.Board;

@SuppressWarnings("serial")
public class Main extends JPanel implements MouseListener, ActionListener {

	public static final int SIZE = 900;
	private static final int Y_OFFSET = 29;
	private static final int X_OFFSET = 6;
	
	public static void main(String[] args) {
		Assets.createAssets();
		
		JFrame frame = new JFrame("Ultimate Tic Tac Toe");
		frame.setSize(SIZE + X_OFFSET, SIZE + Y_OFFSET);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setFocusable(true);
		Main main = new Main();
		frame.add(main);
		frame.addMouseListener(main);
		frame.setVisible(true);
	}
	
	private Board board;
	private AnimationMaster am;
	
	private Main() {
		board = new Board();
		repaint();
	}
	
	public void paint(Graphics g) {
		board.draw(g);
		if(am != null) {
			am.draw(g);
		}
	}

	public void mousePressed(MouseEvent e) {
		if(am != null) { return; }
		board.mousePressed(e.getX() - X_OFFSET, e.getY() - Y_OFFSET);
		if(!board.canPlay()) {
			am = new AnimationMaster();
			Timer timer = new Timer(25, this);
			timer.start();
		}
		repaint();
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

	public void actionPerformed(ActionEvent arg0) {
		am.update();
		repaint();
	}
}
