package tictactoe;

import java.awt.Color;
import java.awt.Graphics;

import main.Main;

public class Tile implements Playable {

	private int type = N;

	protected int OFFSET = 5;
	protected static final int SIZE = Main.SIZE / 9;
	private int x;
	private int y;

	public Tile(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public boolean isX() {
		return type == X;
	}

	public boolean isO() {
		return type == O;
	}
	
	public void draw(Graphics g) {
		if(isX()) {
			g.setColor(Color.RED);
			g.drawLine(x * SIZE + OFFSET, y * SIZE + OFFSET, x * SIZE + SIZE - OFFSET, y * SIZE + SIZE - OFFSET);
			g.drawLine(x * SIZE + SIZE - OFFSET, y * SIZE + OFFSET, x * SIZE + OFFSET, y * SIZE + SIZE - OFFSET);
		}
		
		if(isO()) {
			g.setColor(Color.GREEN);
			g.drawOval(x * SIZE + OFFSET, y * SIZE + OFFSET, SIZE - OFFSET * 2, SIZE - OFFSET * 2);
		}
	}
	
	public boolean play(boolean x) {
		if(type == N) {
			type = x ? X : O;
			return true;
		} else {
			return false;
		}
	}
}
