package tictactoe;

import java.awt.Color;
import java.awt.Graphics;

import main.Main;

public class Square extends Winnable implements Playable {

	protected static final int SIZE = Main.SIZE / 3;
	private static final int OFFSET = 10;
	private int x;
	private int y;

	private static final Color RED = new Color(255, 200, 200);
	private static final Color GREEN = new Color(200, 255, 200);
	private static final Color GRAY = new Color(200, 200, 200);
	private static final Color CYAN = new Color(200, 255, 255);
	
	private Board board;
	
	public Square(int x, int y, Board board) {
		this.x = x;
		this.y = y;
		this.board = board;
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				tiles[i][j] = new Tile(x * 3 + i, y * 3 + j);
			}
		}
	}

	public boolean play(int i, int j, boolean x) {
		boolean played = ((Tile)tiles[i][j]).play(x);
		if(played) { update(); }
		return played;
	}
	
	public void draw(Graphics g) {
		if(xWon()) {
			g.setColor(RED);
		} else if(oWon()) {
			g.setColor(GREEN);
		} else if(isTie()) {
			g.setColor(GRAY);
		} else if(board.canPlay(x, y)) {
			g.setColor(CYAN);
		} else {
			g.setColor(Color.WHITE);
		}

		g.fillRect(x * SIZE, y * SIZE, SIZE, SIZE);
		
		g.setColor(Color.BLACK);
		g.drawLine(x * SIZE + SIZE / 3, y * SIZE + OFFSET, x * SIZE + SIZE / 3, y * SIZE + SIZE - OFFSET);
		g.drawLine(x * SIZE + SIZE * 2 / 3, y * SIZE + OFFSET, x * SIZE + SIZE * 2 / 3, y * SIZE + SIZE - OFFSET);
		g.drawLine(x * SIZE + OFFSET, y * SIZE + SIZE / 3, x * SIZE + SIZE - OFFSET, y * SIZE + SIZE / 3);
		g.drawLine(x * SIZE + OFFSET, y * SIZE + SIZE * 2 / 3, x * SIZE + SIZE - OFFSET, y * SIZE + SIZE * 2 / 3);
		
		for(Playable[] pA : tiles) {
			for(Playable p : pA) {
				p.draw(g);
			}
		}
	}
	
	public boolean isX() {
		return xWon();
	}
	
	public boolean isO() {
		return oWon();
	}
}
