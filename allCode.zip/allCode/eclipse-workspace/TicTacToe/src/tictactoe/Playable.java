package tictactoe;

import java.awt.Graphics;

public interface Playable {
	
	public static final int N = 0;
	public static final int X = 1;
	public static final int O = 2;
	
	public boolean isX();
	public boolean isO();
	
	public void draw(Graphics g);
}
