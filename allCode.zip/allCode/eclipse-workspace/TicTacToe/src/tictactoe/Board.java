package tictactoe;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import main.Main;

public class Board extends Winnable {

	private static final int SIZE = Main.SIZE;
	private static final int THICKNESS = 6;
	
	private boolean xTurn = true;
	private List<Point> playable = new ArrayList<Point>();
	
	public Board() {
		playable.add(new Point(1, 1));
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				tiles[i][j] = new Square(i, j, this);
			}
		}
	}

	public void draw(Graphics g) {
		for(Playable[] pA : tiles) {
			for(Playable p : pA) {
				p.draw(g);
			}
		}
		
		g.setColor(Color.BLACK);
		g.fillRect(SIZE / 3 - THICKNESS / 2, 0, THICKNESS, SIZE);
		g.fillRect(SIZE * 2 / 3 - THICKNESS / 2, 0, THICKNESS, SIZE);
		g.fillRect(0, SIZE / 3 - THICKNESS / 2, SIZE, THICKNESS);
		g.fillRect(0, SIZE * 2 / 3 - THICKNESS / 2, SIZE, THICKNESS);
	}
	
	protected boolean canPlay(int sx, int sy) {
		for(Point p : playable) {
			if(p.x == sx && p.y == sy) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean testWinner() {
		update();
		if(xWon()) {
			System.out.println("X wins!!!!!!!!!!!!!!!!");
			return true;
		} if(oWon()) {
			System.out.println("O wins!!!!!!!!!!!!!!!!");
			return true;
		} if(isTie()) {
			System.out.println("TIE!!!!!!!!!!!!!!!!!!!");
			return true;
		}
		
		return false;
	}
	
	public void mousePressed(int x, int y) {
		int sx = x / Square.SIZE;
		int sy = y / Square.SIZE;
		
		if(!canPlay(sx, sy)) { return; }
		
		int tx = (x / Tile.SIZE) % 3;
		int ty = (y / Tile.SIZE) % 3;
		
		if(((Square)tiles[sx][sy]).play(tx, ty, xTurn)) {
			xTurn = !xTurn;
			playable.clear();
			if(testWinner()) { return; }
			if(((Square)tiles[tx][ty]).canPlay()) {
				playable.add(new Point(tx, ty));
			} else {
				for(int i = 0; i < 3; i++) {
					for(int j = 0; j < 3; j++) {
						if(((Square)tiles[i][j]).canPlay()) {
							playable.add(new Point(i, j));
						}
					}
				}
			}
		}
	}
}
