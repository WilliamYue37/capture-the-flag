package tictactoe;

public abstract class Winnable {

	protected Playable[][] tiles = new Playable[3][3];

	private boolean tie;
	private boolean xWon;
	private boolean oWon;
	
	private boolean is(boolean x, int i, int j) {
		if(i < 0 || i >= 3 || j < 0 || j >= 3) { return false; }
		return x ? tiles[i][j].isX() : tiles[i][j].isO();
	}

	private boolean checkTile(boolean x, int i, int j) {
		if(is(x, i, j)) {
			if(is(x, i - 1, j) && is(x, i + 1, j)) {
				return true;
			}
			
			if(is(x, i, j - 1) && is(x, i, j + 1)) {
				return true;
			}
			
			if(is(x, i - 1, j + 1) && is(x, i + 1, j - 1)) {
				return true;
			}
			
			if(is(x, i - 1, j - 1) && is(x, i + 1, j + 1)) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean won(boolean x) {
		return checkTile(x, 1, 1) || checkTile(x, 1, 0) || checkTile(x, 0, 1) || checkTile(x, 2, 1) || checkTile(x, 1, 2);
	}
	
	protected void update() {
		if(won(true)) {
			xWon = true;
			return;
		}
		
		if(won(false)) {
			oWon = true;
			return;
		}
		
		tie = true;
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				if(!tiles[i][j].isO() && !tiles[i][j].isX()) {
					tie = false;
					return;
				}
			}
		}
	}
	
	public boolean isTie() {
		return tie;
	}
	
	public boolean xWon() {
		return xWon;
	}
	
	public boolean oWon() {
		return oWon;
	}
	
	public boolean canPlay() {
		return !tie && !xWon && !oWon;
	}
}
