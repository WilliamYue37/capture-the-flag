package animation;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import main.Main;

public class AnimationMaster {

	private List<Animation> anims = new ArrayList<Animation>();
	
	private static int ROCKET_TIME = 1000;
	private long lastTime = System.currentTimeMillis();
	
	public AnimationMaster() {
		addRocket();
		addRocket();
		addRocket();
	}
	
	private void addRocket() {
		Rocket rocket = new Rocket(this, (int)(Math.random() * Main.SIZE), (int)(Math.random() * 100) + Main.SIZE);
		anims.add(rocket);
	}
	
	protected void addAmination(Animation anim) {
		anims.add(anim);
	}
	
	public void update() {
		if(System.currentTimeMillis() - lastTime >= ROCKET_TIME) {
			addRocket();
			lastTime = System.currentTimeMillis();
		}
		
		for(int i = 0; i < anims.size(); i++) {
			anims.get(i).update();
			if(anims.get(i).shouldRemove) {
				anims.get(i).destroy();
				anims.remove(i--);
			}
		}
	}
	
	public void draw(Graphics g) {
		for(Animation anim : anims) {
			anim.draw(g);
		}
	}
}
