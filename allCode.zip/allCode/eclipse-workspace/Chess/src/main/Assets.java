package main;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class Assets {

	public static BufferedImage blackPawn;
	public static BufferedImage blackKnight;
	public static BufferedImage blackBishop;
	public static BufferedImage blackRook;
	public static BufferedImage blackQueen;
	public static BufferedImage blackKing;
	
	public static BufferedImage whitePawn;
	public static BufferedImage whiteKnight;
	public static BufferedImage whiteBishop;
	public static BufferedImage whiteRook;
	public static BufferedImage whiteQueen;
	public static BufferedImage whiteKing;

	public static void createAssets() {
		BufferedImage white = loadImage("white pieces.png");
		int width = white.getWidth() / 3;
		int height = white.getHeight() / 2;
		whitePawn = white.getSubimage(width * 2, height, width, height);
		whiteKnight = white.getSubimage(0, height, width, height);
		whiteBishop = white.getSubimage(width, height, width, height);
		whiteRook = white.getSubimage(width * 2, 0, width, height);
		whiteQueen = white.getSubimage(width, 0, width, height);
		whiteKing = white.getSubimage(0, 0, width, height);
		
		BufferedImage black = loadImage("black pieces.png");
		blackPawn = black.getSubimage(width * 2, height, width, height);
		blackKnight = black.getSubimage(0, height, width, height);
		blackBishop = black.getSubimage(width, height, width, height);
		blackRook = black.getSubimage(width * 2, 0, width, height);
		blackQueen = black.getSubimage(width, 0, width, height);
		blackKing = black.getSubimage(0, 0, width, height);
	}
	
	private static BufferedImage loadImage(String name) {
		try {
			return ImageIO.read(new File("res/" + name));
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
