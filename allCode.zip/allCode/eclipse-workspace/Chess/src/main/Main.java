package main;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

import chess.Board;

@SuppressWarnings("serial")
public class Main extends JPanel implements MouseListener, KeyListener {

	public static final int SIZE = 800;
	private static final int Y_OFFSET = 29;
	private static final int X_OFFSET = 6;
	
	public static void main(String[] args) {
		Assets.createAssets();

		JFrame frame = new JFrame("Chess");
		frame.setSize(SIZE + X_OFFSET, SIZE + Y_OFFSET);
		frame.setLocationRelativeTo(null);
		frame.setFocusable(true);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Main main = new Main();
		frame.add(main);
		frame.addMouseListener(main);
		frame.addKeyListener(main);
		frame.setVisible(true);
	}
	
	private Board board = new Board();

	public Main() {
		repaint();
	}
	
	public void paint(Graphics g) {
		board.draw(g);
	}

	public void mousePressed(MouseEvent e) {
		board.mousePressed(e.getX() - X_OFFSET, e.getY() - Y_OFFSET);
		repaint();
	}

	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

	public void keyPressed(KeyEvent e) {
		board.keyPressed(e.getKeyCode());
		repaint();
	}
	
	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
}
