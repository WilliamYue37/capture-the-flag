package chess;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.List;

public abstract class Piece {
	
	protected boolean white;
	private BufferedImage image;
	protected Board board;
	
	public Piece(Board board, boolean white, BufferedImage image) {
		this.white = white;
		this.image = image;
		this.board = board;
	}
	
	public abstract List<Point> getMovementCapabilites(int rank, int file, boolean check);
	
	private boolean addPointNoCheck(List<Point> movement, int rank, int file) {
		if(board.isTileValid(rank, file)) {
			Piece piece = board.getPiece(rank, file);
			if(piece == null) { movement.add(new Point(rank, file)); return true; }
			else if(piece.isWhite() != white) { movement.add(new Point(rank, file)); }
		}
		
		return false;
	}
	
	protected boolean addPoint(List<Point> movement, int rank, int file, int currentRank, int currentFile, boolean check) {
		boolean added = addPointNoCheck(movement, rank, file);
		if(check && putInCheck(rank, file, currentRank, currentFile)) {
			movement.remove(new Point(rank, file));
		}
		
		return added;
	}
	
	protected boolean putInCheck(int rank, int file, int currentRank, int currentFile) {
		board.movePiece(currentRank, currentFile, rank, file, true);
		Point kingPoint = (this instanceof King) ? new Point(rank, file) : board.getKingPoint(white);
		if(board.inCheck(white, kingPoint)) {
			board.undoLastMove();
			return true;
		}
		
		board.undoLastMove();
		return false;
	}
	
	protected void addPoints(List<Point> movement, int rank, int file, int rankOffset, int fileOffset, int currentRank, int currentFile, boolean check) {
		boolean added = addPoint(movement, rank + rankOffset, file + fileOffset, currentRank, currentFile, check);
		if(added) {
			addPoints(movement, rank + rankOffset, file + fileOffset, rankOffset, fileOffset, currentRank, currentFile, check);
		}
	}
	
	public void draw(Graphics g, int rank, int file) {
		g.drawImage(image, rank * Tile.SIZE, file * Tile.SIZE, Tile.SIZE, Tile.SIZE, null);
	}
	
	public boolean isWhite() {
		return white;
	}
}
