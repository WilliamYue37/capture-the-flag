package chess;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import main.Assets;

public class Queen extends Piece {

	public Queen(Board board, boolean white) {
		super(board, white, white ? Assets.whiteQueen : Assets.blackQueen);
	}
	
	public List<Point> getMovementCapabilites(int rank, int file, boolean check) {
		List<Point> movement = new ArrayList<Point>();
		addPoints(movement, rank, file, 1, 1, rank, file, check);
		addPoints(movement, rank, file, -1, 1, rank, file, check);
		addPoints(movement, rank, file, 1, -1, rank, file, check);
		addPoints(movement, rank, file, -1, -1, rank, file, check);
		addPoints(movement, rank, file, 1, 0, rank, file, check);
		addPoints(movement, rank, file, -1, 0, rank, file, check);
		addPoints(movement, rank, file, 0, -1, rank, file, check);
		addPoints(movement, rank, file, 0, 1, rank, file, check);
		return movement;
	}
}
