package chess;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import main.Assets;

public class Bishop extends Piece {

	public Bishop(Board board, boolean white) {
		super(board, white, white ? Assets.whiteBishop : Assets.blackBishop);
	}

	public List<Point> getMovementCapabilites(int rank, int file, boolean check) {
		List<Point> movement = new ArrayList<Point>();
		addPoints(movement, rank, file, 1, 1, rank, file, check);
		addPoints(movement, rank, file, -1, 1, rank, file, check);
		addPoints(movement, rank, file, 1, -1, rank, file, check);
		addPoints(movement, rank, file, -1, -1, rank, file, check);
		return movement;
	}
}
