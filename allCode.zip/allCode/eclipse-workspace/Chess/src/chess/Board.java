package chess;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.util.List;

public class Board {

	private Tile[][] tiles = new Tile[8][8];
	
	private boolean tileSelected = false;
	private int selectedRank;
	private int selectedFile;
	
	private boolean whiteTurn = true;
	
	private King whiteKing;
	private King blackKing;
	
	public Board() {
		placePieces();
	}
	
	private int startRank;
	private int startFile;
	private int endRank;
	private int endFile;
	private Piece movePiece;
	private Piece takePiece;
	public void movePiece(int startRank, int startFile, int endRank, int endFile, boolean willUndo) {
		if(!isTileValid(endRank, endFile)) { return; }
		this.startRank = startRank;
		this.startFile = startFile;
		this.endRank = endRank;
		this.endFile = endFile;
		movePiece = tiles[startRank][startFile].getPiece();
		takePiece = tiles[endRank][endFile].getPiece();
		tiles[endRank][endFile].setPiece(movePiece);
		tiles[startRank][startFile].setPiece(null);
		canUndo = true;
		if(!willUndo) {
			whiteTurn = !whiteTurn;
		}
	}
	
	private boolean canUndo = false;
	public void undoLastMove() {
		if(canUndo) {
			tiles[startRank][startFile].setPiece(movePiece);
			tiles[endRank][endFile].setPiece(takePiece);
		}
	}
	
	public void keyPressed(int k) {
		if(k == KeyEvent.VK_N) {
			placePieces();
		}
	}

	private boolean hasMovementCapabilities(boolean white) {
		for(int rank = 0; rank < 8; rank++) {
			for(int file = 0; file < 8; file++) {
				Piece piece = tiles[rank][file].getPiece();
				if(piece != null && piece.isWhite() == white && !piece.getMovementCapabilites(rank, file, true).isEmpty()) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	private void checkForGameOver(boolean white) {
		if(!hasMovementCapabilities(white)) {
			if(inCheck(white, getKingPoint(white))) {
				System.out.println((white ? "Black" : "White") + " has checkmated " + (white ? "white" : "black") + "!");
			} else {
				System.out.println("Stalemate!");
			}
		}
	}
	
	public void mousePressed(int x, int y) {
		int rank = x / Tile.SIZE;
		int file = y / Tile.SIZE;
		if(tileSelected && tiles[selectedRank][selectedFile].inMovementCapabilities(rank, file)) {
			if(tiles[selectedRank][selectedFile].getPiece() instanceof King && Math.abs(selectedRank - rank) == 2) {
				if(rank > selectedRank) {
					movePiece(4, selectedFile, 6, file, false);
					movePiece(7, selectedFile, 5, file, true);
				} else {
					movePiece(4, selectedFile, 1, file, false);
					movePiece(0, selectedFile, 2, file, true);
				}
			} else {
				movePiece(selectedRank, selectedFile, rank, file, false);
			}
			
			checkForGameOver(true);
			checkForGameOver(false);
			tileSelected = false;
		}
		
		else {
			selectedRank = rank;
			selectedFile = file;
			Piece piece = tiles[rank][file].getPiece();
			tileSelected = piece != null && piece.isWhite() == whiteTurn;
			if(tileSelected) {
				canUndo = false;
			}
		}
	}
	
	public Point getKingPoint(boolean white) {
		if(white) {
			return new Point(whiteKing.getRank(), whiteKing.getFile());
		} else {
			return new Point(blackKing.getRank(), blackKing.getFile());
		}
	}
	
	public boolean inCheck(boolean white, Point kingPoint) {
		for(int rank = 0; rank < 8; rank++) {
			for(int file = 0; file < 8; file++) {
				Piece piece = tiles[rank][file].getPiece();
				if(piece != null && piece.isWhite() != white) {
					List<Point> movement = piece.getMovementCapabilites(rank, file, false);
					for(Point move : movement) {
						if(move.equals(kingPoint)) {
							return true;
						}
					}
				}
			}
		}
		
		return false;
	}
	
	public void draw(Graphics g) {
		for(Tile[] tA : tiles) {
			for(Tile t : tA) {
				t.draw(g);
			}
		}
		
		if(tileSelected) {
			tiles[selectedRank][selectedFile].displayCapabilities(g);
		}
	}
	
	public boolean isTileValid(int rank, int file) {
		if(rank < 0 || rank > 7 || file < 0 || file > 7) {
			return false;
		} else {
			return true;
		}
	}
	
	public Piece getPiece(int rank, int file) {
		return tiles[rank][file].getPiece();
	}
	
	private void placePieces() {
		// tiles
		whiteTurn = true;
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				tiles[i][j] = new Tile(this, i, j);
			}
		}
		
		// pawn
		for(int i = 0; i < 8; i++) {
			Pawn whitePawn = new Pawn(this, true);
			tiles[i][6].setPiece(whitePawn);
			
			Pawn blackPawn = new Pawn(this, false);
			tiles[i][1].setPiece(blackPawn);
		}
				
		// knight
		Knight whiteKnight1 = new Knight(this, true);
		tiles[1][7].setPiece(whiteKnight1);
		Knight whiteKnight2 = new Knight(this, true);
		tiles[6][7].setPiece(whiteKnight2);
				
		Knight blackKnight1 = new Knight(this, false);
		tiles[1][0].setPiece(blackKnight1);
		Knight blackKnight2 = new Knight(this, false);
		tiles[6][0].setPiece(blackKnight2);
				
		// bishop
		Bishop whiteBishop1 = new Bishop(this, true);
		tiles[2][7].setPiece(whiteBishop1);
		Bishop whiteBishop2 = new Bishop(this, true);
		tiles[5][7].setPiece(whiteBishop2);
				
		Bishop blackBishop1 = new Bishop(this, false);
		tiles[2][0].setPiece(blackBishop1);
		Bishop blackBishop2 = new Bishop(this, false);
		tiles[5][0].setPiece(blackBishop2);
				
		// rook
		Rook whiteRook1 = new Rook(this, true);
		tiles[0][7].setPiece(whiteRook1);
		Rook whiteRook2 = new Rook(this, true);
		tiles[7][7].setPiece(whiteRook2);
				
		Rook blackRook1 = new Rook(this, false);
		tiles[0][0].setPiece(blackRook1);
		Rook blackRook2 = new Rook(this, false);
		tiles[7][0].setPiece(blackRook2);
				
		// queen
		Queen whiteQueen = new Queen(this, true);
		tiles[3][7].setPiece(whiteQueen);
				
		Queen blackQueen = new Queen(this, false);
		tiles[3][0].setPiece(blackQueen);
			
		// king
		whiteKing = new King(this, true);
		tiles[4][7].setPiece(whiteKing);
		
		blackKing = new King(this, false);
		tiles[4][0].setPiece(blackKing);
	}
	
	public Tile[][] getTiles() {
		return tiles;
	}
}
