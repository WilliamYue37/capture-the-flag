package chess;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.List;

import main.Main;

public class Tile {

	public static final int SIZE = Main.SIZE / 8;
	
	private static final Color DARK = new Color(100, 0, 0);
	private static final Color LIGHT = new Color(200, 100, 0);
	private boolean dark;
	
	private int rank;
	private int file;
	
	private Piece piece;
	private List<Point> movement;
	private Board board;
	
	public Tile(Board board, int rank, int file) {
		this.board = board;
		this.rank = rank;
		this.file = file;
		dark = (rank + file) % 2 == 0;
	}
	
	public void draw(Graphics g) {
		g.setColor(dark ? DARK : LIGHT);
		if(piece instanceof King && board.inCheck(piece.isWhite(), new Point(rank, file))) {
			g.setColor(Color.RED);
		}
		g.fillRect(rank * SIZE, file * SIZE, SIZE, SIZE);
		
		
		
		if(piece != null) {
			piece.draw(g, rank, file);
		}
	}
	
	public boolean inMovementCapabilities(int rank, int file) {
		for(Point move : movement) {
			if(move.x == rank && move.y == file) {
				return true;
			}
		}
		
		return false;
	}
	
	public void displayCapabilities(Graphics g) {
		movement = piece.getMovementCapabilites(rank, file, true);
		for(Point move : movement) {
			if(board.getPiece(move.x, move.y) != null) {
				g.setColor(Color.RED);
			} else {
				g.setColor(Color.BLUE);
			}
			g.fillOval(move.x * SIZE + SIZE / 4, move.y * SIZE + SIZE / 4, SIZE / 2, SIZE / 2);
		}
	}
	
	public void setPiece(Piece piece) {
		this.piece = piece;
		if(piece instanceof Pawn) {
			if(piece.isWhite() && file == 0) {
				Queen queen = new Queen(board, true);
				this.piece = queen;
			} if(!piece.isWhite() && file == 7) {
				Queen queen = new Queen(board, false);
				this.piece = queen;
			}
		}
	}
	
	public Piece getPiece() {
		return piece;
	}
}
