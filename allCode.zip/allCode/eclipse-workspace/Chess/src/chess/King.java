package chess;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import main.Assets;

public class King extends Piece {

	private int rank;
	private int file;
	
	public King(Board board, boolean white) {
		super(board, white, white ? Assets.whiteKing : Assets.blackKing);
	}

	public List<Point> getMovementCapabilites(int rank, int file, boolean check) {
		this.rank = rank;
		this.file = file;
		
		List<Point> movement = new ArrayList<Point>();
		addPoint(movement, rank, file + 1, rank, file, check);
		addPoint(movement, rank, file - 1, rank, file, check);
		addPoint(movement, rank + 1, file, rank, file, check);
		addPoint(movement, rank - 1, file, rank, file, check);
		addPoint(movement, rank - 1, file + 1, rank, file, check);
		addPoint(movement, rank - 1, file - 1, rank, file, check);
		addPoint(movement, rank + 1, file + 1, rank, file, check);
		addPoint(movement, rank + 1, file - 1, rank, file, check);
		
		if(check && rank == 4 && file == (white ? 7 : 0)) {
			addCastleMove(movement, rank, file);
		}
		
		return movement;
	}

	private void addCastleMove(List<Point> movement, int rank, int file) {
		if(!board.inCheck(white, new Point(rank, file))) {
			Tile[][] tiles = board.getTiles();
			
			if(tiles[5][file].getPiece() == null && tiles[6][file].getPiece() == null && tiles[7][file].getPiece() instanceof Rook) {
				board.movePiece(4, file, 6, file, true);
				board.movePiece(7, file, 5, file, true);
				if(!board.inCheck(white, new Point(6, file))) {
					movement.add(new Point(6, file));
				}
				board.movePiece(6, file, 4, file, true);
				board.movePiece(5, file, 7, file, true);
			}
			
			if(tiles[3][file].getPiece() == null && tiles[2][file].getPiece() == null && tiles[1][file].getPiece() == null && tiles[0][file].getPiece() instanceof Rook) {
				board.movePiece(4, file, 1, file, true);
				board.movePiece(0, file, 2, file, true);
				if(!board.inCheck(white, new Point(1, file))) {
					movement.add(new Point(2, file));
				}
				board.movePiece(1, file, 4, file, true);
				board.movePiece(2, file, 0, file, true);
			}
		}
	}

	public int getRank() {
		return rank;
	}
	
	public int getFile() {
		return file;
	}
}
