package chess;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import main.Assets;

public class Knight extends Piece {

	public Knight(Board board, boolean white) {
		super(board, white, white ? Assets.whiteKnight : Assets.blackKnight);
	}

	public List<Point> getMovementCapabilites(int rank, int file, boolean check) {
		List<Point> movement = new ArrayList<Point>();
		addPoint(movement, rank + 2, file + 1, rank, file, check);
		addPoint(movement, rank + 2, file - 1, rank, file, check);
		addPoint(movement, rank - 2, file + 1, rank, file, check);
		addPoint(movement, rank - 2, file - 1, rank, file, check);
		addPoint(movement, rank + 1, file + 2, rank, file, check);
		addPoint(movement, rank - 1, file + 2, rank, file, check);
		addPoint(movement, rank + 1, file - 2, rank, file, check);
		addPoint(movement, rank - 1, file - 2, rank, file, check);
		return movement;
	}
}
