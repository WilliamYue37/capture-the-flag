package chess;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import main.Assets;

public class Pawn extends Piece {

	public Pawn(Board board, boolean white) {
		super(board, white, white ? Assets.whitePawn : Assets.blackPawn);
	}
	
	public List<Point> getMovementCapabilites(int rank, int file, boolean check) {
		List<Point> movement = new ArrayList<Point>();
		
		if(white) {
			if(addMovePoint(movement, rank, file - 1, file, check)) {
				if(file == 6) { addMovePoint(movement, rank, file - 2, file, check); }
			}
			addTakePoint(movement, rank - 1, file - 1, rank, file, check);
			addTakePoint(movement, rank + 1, file - 1, rank, file, check);
		} else {
			if(addMovePoint(movement, rank, file + 1, file, check)) {
				if(file == 1) { addMovePoint(movement, rank, file + 2, file, check); }
			}
			addTakePoint(movement, rank - 1, file + 1, rank, file, check);
			addTakePoint(movement, rank + 1, file + 1, rank, file, check);
		}

		return movement;
	}
	
	private boolean addMovePoint(List<Point> movement, int rank, int file, int currentFile, boolean check) {
		if(board.isTileValid(rank, file)) {
			Piece piece = board.getPiece(rank, file);
			if(piece == null) { 
				if(!check || !putInCheck(rank, file, rank, currentFile)) {
					movement.add(new Point(rank, file));
				}
				return true;
			}
		}
		
		return false;
	}

	private void addTakePoint(List<Point> movement, int rank, int file, int currentRank, int currentFile, boolean check) {
		if(board.isTileValid(rank, file)) {
			Piece piece = board.getPiece(rank, file);
			if(piece != null && piece.isWhite() != white) {
				if(!check || !putInCheck(rank, file, currentRank, currentFile)) {
					movement.add(new Point(rank, file));
				}
			}
		}
	}
}
