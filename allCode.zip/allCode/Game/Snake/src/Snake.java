import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Snake extends JPanel implements ActionListener, KeyListener {
    
    public static int SIZE = 800;

    public static void main(String[] args) {
    	JFrame frame = new JFrame("Snake");
    	frame.setSize(SIZE + 7, SIZE + 30);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	Snake a = new Snake();
    	frame.add(a);
    	frame.setFocusable(true);
    	frame.addKeyListener(a);
    }
    
    private Game game;
    
    private Snake() {
    	game = new Game();
    	javax.swing.Timer timer = new javax.swing.Timer(100, this);
    	timer.start();
    }
    
    public void actionPerformed(ActionEvent e) {
    	game.update();
    	if(game.isDead()) {
    		game = new Game();
    	}
    	repaint();
    } 

   	public void paint(Graphics g) {
   		game.draw(g);
   	}
   	
   	public void keyPressed(KeyEvent e) { game.keyPressed(e.getKeyCode()); }
   	public void keyReleased(KeyEvent e) {}
   	public void keyTyped(KeyEvent e) {}
}

class Game {
	
	private static final int SIZE = 20;
	private static final int TILE_SIZE = Snake.SIZE / SIZE;
	
	private static final int UP = 0;
	private static final int DOWN = 1;
	private static final int LEFT = 2;
	private static final int RIGHT = 3;
	private int direction = UP;
	private int lastDirection = UP;
	
	private ArrayList<Integer> xPositions = new ArrayList<Integer>();
	private ArrayList<Integer> yPositions = new ArrayList<Integer>();
	
	private int appleX;
	private int appleY;
	
	private boolean dead = false;
	
	public Game() {
		xPositions.add(SIZE / 2);
		yPositions.add(SIZE / 2);
		xPositions.add(SIZE / 2);
		yPositions.add(SIZE / 2);
		xPositions.add(SIZE / 2);
		yPositions.add(SIZE / 2);
		
		setApplePosition();
	}

	private boolean validApplePosition() {
		for(int i = 0; i < xPositions.size(); i++) {
			if(appleX == xPositions.get(i) && appleY == yPositions.get(i)) {
				return false;
			}
		}
		
		return true;
	}
	
	private void setApplePosition() {
		do {
			appleX = (int) (Math.random() * SIZE);
			appleY = (int) (Math.random() * SIZE);
		} while(!validApplePosition());
	}
	
	public void update() {
		int x = xPositions.get(xPositions.size() - 1);
		int y = yPositions.get(yPositions.size() - 1);
		
		switch(direction) {
		case UP : 
			y--;
			if(y < 0) {
				y = SIZE - 1;
			}
			break;
		case DOWN :
			y++;
			if(y > SIZE - 1) {
				y = 0;
			}
			break;
		case LEFT :
			x--;
			if(x < 0) {
				x = SIZE - 1;
			}
			break;
		case RIGHT :
			x++;
			if(x > SIZE - 1) {
				x = 0;
			}
			break;
		}
		
		xPositions.add(x);
		yPositions.add(y);
		
		if(appleX == x && appleY == y) {
			xPositions.add(0, xPositions.get(0));
			yPositions.add(0, yPositions.get(0));
			xPositions.add(0, xPositions.get(0));
			yPositions.add(0, yPositions.get(0));
			
			setApplePosition();
		}
		
		else {
			xPositions.remove(0);
			yPositions.remove(0);
		}
		
		for(int i = 0; i < xPositions.size() - 1; i++) {
			if(x == xPositions.get(i) && y == yPositions.get(i)) {
				dead = true;
			}
		}
		
		lastDirection = direction;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, Snake.SIZE, Snake.SIZE);
		g.setColor(Color.BLACK);
		for(int i = 0; i <= SIZE; i++) {
			g.drawLine(i * TILE_SIZE, 0, i * TILE_SIZE, Snake.SIZE);
			g.drawLine(0, i * TILE_SIZE, Snake.SIZE, i * TILE_SIZE);
		}
		
		g.setColor(Color.GREEN);
		for(int i = 0; i < xPositions.size(); i++) {
			if(i == xPositions.size() - 1) {
				g.setColor(Color.BLUE);
			}
			
			g.fillRect(xPositions.get(i) * TILE_SIZE + 1, yPositions.get(i) * TILE_SIZE + 1, TILE_SIZE - 1, TILE_SIZE - 1);
		}
		
		g.setColor(Color.RED);
		g.fillRect(appleX * TILE_SIZE + 1, appleY * TILE_SIZE + 1, TILE_SIZE - 1, TILE_SIZE - 1);
	}
	
	public void keyPressed(int k) {
		switch(k) {
		case KeyEvent.VK_UP :
			if(lastDirection != DOWN) {
				direction = UP;
			}
			break;
		case KeyEvent.VK_DOWN : 
			if(lastDirection != UP) {
				direction = DOWN;
			}
			break;
		case KeyEvent.VK_LEFT : 
			if(lastDirection != RIGHT) {
				direction = LEFT;
			}
			break;
		case KeyEvent.VK_RIGHT : 
			if(lastDirection != LEFT) {
				direction = RIGHT;
			}
			break;
		}
	}
	
	public boolean isDead() {
		return dead;
	}
}