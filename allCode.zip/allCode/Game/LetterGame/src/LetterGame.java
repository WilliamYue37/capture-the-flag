import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;

public class LetterGame extends JPanel implements ActionListener, MouseListener {
    
    public static int SIZE = 800;
    
    public static void main(String[] args) {
    	JFrame frame = new JFrame("Letter Game");
    	frame.setSize(SIZE + 6, SIZE + 30);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	LetterGame a = new LetterGame();
    	frame.add(a);
    	frame.setFocusable(true);
    	frame.addMouseListener(a);
    	a.createGame();
    }

	private Game game;

	private void createGame() {
		game = new Game();
	}

    private LetterGame() {
    	javax.swing.Timer timer = new javax.swing.Timer(25, this);
    	timer.start();
    }
    
    public void actionPerformed(ActionEvent e) { repaint(); } 

   	public void paint(Graphics g) {
   		if(game != null) {
   			game.draw(g);
   		}
   	}
   	
   	public void mousePressed(MouseEvent e) { game.mousePressed(e.getX(), e.getY(), e.getButton()); }
   	public void mouseReleased(MouseEvent e) {}
   	public void mouseClicked(MouseEvent e) {}
   	public void mouseEntered(MouseEvent e) {}
   	public void mouseExited(MouseEvent e) {}
}

class Game {
	
	private Token[][] tokens;
	private int numTokens;
	private boolean pic;
	private int emptyX;
	private int emptyY;
	private BufferedImage image;
	
	public Game() {
		pic = JOptionPane.showConfirmDialog(null, "YES for picture, NO for letter", null, JOptionPane.YES_NO_OPTION) == 0;
		numTokens = Integer.parseInt(JOptionPane.showInputDialog("Enter starting number of tokens"));
	}

	private void create() {
		if(pic) {
			createPictureTokens();
		} else {
			createLetterTokens();
		}
	}

	private void loadImage(String name) {
		try {
			image = ImageIO.read(new File("C:\\Users\\600976\\Desktop\\LetterGame\\images\\" + name));
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	private void createPictureTokens() {
		tokens = new Token[numTokens][numTokens];
		int size = LetterGame.SIZE / numTokens;
		loadImage("football.jpg");
		ArrayList<BufferedImage> images = new ArrayList<BufferedImage>();
		ArrayList<Integer> codes = new ArrayList<Integer>();
		int width = image.getWidth() / numTokens;
		int height = image.getHeight() / numTokens;
		for(int i = 0; i < numTokens; i++) {
			for(int j = 0; j < numTokens; j++) {
				if(i == numTokens - 1 && j == numTokens - 1) {
					images.add(null);
					codes.add(Integer.MAX_VALUE);
				} else {
					images.add(image.getSubimage(i * width, j * height, width, height));
					codes.add(i * numTokens + j);
				}
			}
		}

		for(int i = 0; i < numTokens; i++) {
			for(int j = 0; j < numTokens; j++) {
				int a = (int) (Math.random() * images.size());
				BufferedImage image = images.remove(a);
				tokens[i][j] = new PictureToken(i * size, j * size, size, image, codes.remove(a));
				if(image == null) {
					emptyX = i;
					emptyY = j;
				}
			}
		}
	}

	private void createLetterTokens() {
		tokens = new Token[numTokens][numTokens];
		int size = LetterGame.SIZE / numTokens;
		ArrayList<Character> chars = new ArrayList<Character>();
		for(int i = 0; i < numTokens * numTokens - 1; i++) {
			chars.add((char) ((int) 'A' + i));
		}
		chars.add(' ');
		
		for(int i = 0; i < numTokens; i++) {
			for(int j = 0; j < numTokens; j++) {
				int a = (int) (Math.random() * chars.size());
				char c = chars.remove(a);
				tokens[i][j] = new LetterToken(i * size, j * size, size, c);
				if(c == ' ') {
					emptyX = i;
					emptyY = j;
				}
			}
		}
	}

	public void mousePressed(int x, int y, int b) {
		int gx = x * numTokens / LetterGame.SIZE;
		int gy = y * numTokens / LetterGame.SIZE;
		
		if(canMove(gx, gy) || b == 2) {
			Token temp = tokens[gx][gy];
			tokens[gx][gy] = tokens[emptyX][emptyY];
			tokens[emptyX][emptyY] = temp;
			
			tokens[gx][gy].move(gx, gy);
			tokens[emptyX][emptyY].move(emptyX, emptyY);
			
			emptyX = gx;
			emptyY = gy;
			
			testWinner();
		}
	}
	
	private boolean canMove(int x, int y) {
		return Math.abs(x - emptyX) + Math.abs(y - emptyY) == 1;
	}
	
	private void testWinner() {
		boolean wonV = true;
		boolean wonH = !pic;
		int valueV = -1;
		int valueH = -1;

		for(int i = 0; i < numTokens; i++) {
			for(int j = 0; j < numTokens; j++) {
				int v = tokens[i][j].getValue();
				if(valueV >= v) {
					wonV = false;
				}
				valueV = v;
				
				int h = tokens[j][i].getValue();
				if(valueH >= h) {
					wonH = false;
				}
				valueH = h;
				
				if(!wonV && !wonH) {
					return;
				}
			}
		}
		
		numTokens++;
		create();
	}
	
	public void draw(Graphics g) {
		if(tokens == null) {
			create();
		}
		
		g.setFont(new Font(Font.SERIF, Font.BOLD, LetterGame.SIZE / (numTokens + 1)));
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, LetterGame.SIZE, LetterGame.SIZE);
		for(Token[] tA : tokens) {
			for(Token t : tA) {
				t.draw(g);
			}
		}
	}
}

abstract class Token {

	protected Rectangle bounds;
	protected boolean empty = false;

	public Token(int x, int y, int size) {
		bounds = new Rectangle(x, y, size, size);
	}
	
	public abstract void draw(Graphics g);
	public abstract int getValue();
	
	public void move(int x, int y) {
		bounds.x = x * bounds.width;
		bounds.y = y * bounds.height;
	}
	
	public boolean isEmpty() {
		return empty;
	}
}

class LetterToken extends Token {
	
	private char letter;
	
	public LetterToken(int x, int y, int size, char letter) {
		super(x, y, size);
		this.letter = letter;
		if(letter == ' ') {
			empty = true;
		}
	}
	
	public int getValue() {
		if(letter == ' ') {
			return Integer.MAX_VALUE;
		}
		return (int) letter;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawString(letter + "", bounds.x + bounds.width / 5, bounds.y + bounds.height / 5 * 4);
		g.drawRect(bounds.x, bounds.y, bounds.width, bounds.height);
	}
}

class PictureToken extends Token {
	
	private int code;
	private BufferedImage image;
	
	public PictureToken(int x, int y, int size, BufferedImage image, int code) {
		super(x, y, size);
		this.code = code;
		this.image = image;
		if(image == null) {
			code = Integer.MAX_VALUE;
			empty = true;
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		if(image == null) {
			g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
		} else {
			g.drawImage(image, bounds.x, bounds.y, bounds.width, bounds.height, null);
			g.drawRect(bounds.x, bounds.y, bounds.width, bounds.height);
		}
	}
	
	public int getValue() {
		return code;
	}
}





















