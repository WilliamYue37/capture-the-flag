import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class QuadTreeTest extends JPanel implements ActionListener, MouseMotionListener {
    
    public static int SIZE = 1000;

    public static void main(String[] args) {
    	JFrame frame = new JFrame("QuadTree");
    	frame.setSize(SIZE + 7, SIZE + 30);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	QuadTreeTest a = new QuadTreeTest();
    	frame.add(a);
    	frame.setFocusable(true);
    	frame.addMouseMotionListener(a);
    	
    	runBinaryTreeLabs();
    }

	private static void runBinaryTreeLabs() {
		BinaryTree<Integer> root = null;
		for(int i = 0; i < 20; i++) {
			int rand = (int)(Math.random() * 100);
			if(root == null) {
				root = new BinaryTree<Integer>(rand);
			} else {
				root.add(rand);
			}
		}
		
		root.printOrder();
		System.out.println();
		root.printPre();
		System.out.println();
		root.printPost();
		System.out.println();
		root.printReverse();
		System.out.println();
		System.out.println(root.countNodes());
		System.out.println(root.countLevels());
		System.out.println(root.countLeaves());
		System.out.println(root.getWidth());
		
		root = new BinaryTree<Integer>(10);
		root.add(11);
		root.add(15);
		root.add(1);
		root.add(2);
		root.add(3);
		root.add(4);
		root.add(5);
		root.add(7);
		root.add(-10);
		System.out.println("\n" + root.getWidth());
	}

	private int mouseX;
	private int mouseY;

	private LodData lodData;
	private Node root;

    private QuadTreeTest() {
    	lodData = new LodData();
    	root = new Node(lodData);
    	
    	javax.swing.Timer timer = new javax.swing.Timer(1, this);
    	timer.start();
    }
    
    public void actionPerformed(ActionEvent e) {
    	repaint();
    } 

   	public void paint(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, SIZE, SIZE);
		
		root.update(lodData, mouseX, mouseY);
		root.draw(g);
   	}
   	
   	public void mouseMoved(MouseEvent e) {
   		mouseX = e.getX() - 7;
   		mouseY = e.getY() - 30;
   	}
   	
   	public void mouseDragged(MouseEvent e) {
   		mouseX = e.getX() - 7;
   		mouseY = e.getY() - 30;
   	}
}

class BinaryTree<T extends Comparable> {
	
	private BinaryTree<T> left;
	private BinaryTree<T> right;
	private T t;
	
	public BinaryTree(T t) {
		this.t = t;
	}
	
	public int countLeaves() {
		if(left == null && right == null) { return 1; }
		int l = (left == null) ? 0 : left.countLeaves();
		int r = (right == null) ? 0 : right.countLeaves();
		return l + r;
	}
	
	public int countNodes() {
		int l = (left == null) ? 0 : left.countNodes();
		int r = (right == null) ? 0 : right.countNodes();
		return 1 + l + r;
	}
	
	public int countLevels() {
		int l = (left == null) ? 0 : left.countLevels();
		int r = (right == null) ? 0 : right.countLevels();
		return 1 + Math.max(l, r);
	}

	public int getWidth() { // doesn't work
		if(left == null && right == null) { return 1; }
		if(left == null && right != null) {
			return Math.max(right.getWidth(), right.countLevels() + 1);
		} if(left != null && right == null) {
			return Math.max(left.getWidth(), left.countLevels() + 1);
		} else {
			int longL = left.countLevels();
			int longR = left.countLevels();
			System.out.println(longL + " " + longR);
			return Math.max(longL + longR, Math.max(left.countLevels() + 1, right.countLevels() + 1));
		}
	}
	
	public void add(T t) {
		int compare = this.t.compareTo(t);
		if(compare > 0) {
			if(left == null) {
				left = new BinaryTree(t);
			} else { 
				left.add(t);
			}
		} else if(compare < 0) {
			if(right == null) {
				right = new BinaryTree(t);
			} else {
				right.add(t);
			}
		}
	}
	
	public void printOrder() {
		if(left != null) { left.printOrder(); }
		System.out.print(t + ", ");
		if(right != null) { right.printOrder(); }
	}
	
	public void printPre() {
		System.out.print(t + ", ");
		if(left != null) { left.printOrder(); }
		if(right != null) { right.printOrder(); }
	}
	
	public void printPost() {
		if(left != null) { left.printOrder(); }
		if(right != null) { right.printOrder(); }
		System.out.print(t + ", ");
	}
	
	public void printReverse() {
		if(right != null) { right.printOrder(); }
		System.out.print(t + ", ");
		if(left != null) { left.printOrder(); }
	}
}

class LodData {
	
	private static final float SIZE = QuadTreeTest.SIZE;
	private float[] lods = { SIZE * 0.7f, SIZE * 0.5f, SIZE * 0.3f, SIZE * 0.2f, SIZE * 0.1f, SIZE * 0.05f, SIZE * 0.025f };
	
	public boolean inBounds(int lod) {
		return lod < lods.length;
	}
	
	public boolean shouldSplit(int lod, float centerX, float centerY, float mouseX, float mouseY) {
		if(lod >= lods.length) { return false; }
		if(lods[lod] == -1) { return true; }
		float width = centerX - mouseX;
		float height = centerY - mouseY;
		float distance = (float)Math.sqrt(width * width + height * height);
		return distance <= lods[lod];
	}
}

class Node {
	
	private int level;
	private float size;
	private Node[] children;
	private boolean hasChildren;
	private float x;
	private float y;
	
	public Node(LodData lodData) {
		size = QuadTreeTest.SIZE;
		x = 0;
		y = 0;
		level = 0;
		create(lodData);
	}
	
	public Node(Node parent, int i, LodData lodData) {
		size = parent.size / 2;
		level = parent.level + 1;
		x = parent.x + size * (i / 2);
		y = parent.y + size * (i % 2);
		create(lodData);
	}
	
	private void create(LodData lodData) {
		if(lodData.inBounds(level)) {
			children = new Node[4];
			for(int i = 0; i < 4; i++) {
				children[i] = new Node(this, i, lodData);
			}
		}
	}
	
	public void update(LodData lodData, float mouseX, float mouseY) {
		hasChildren = lodData.shouldSplit(level, x + size / 2, y + size / 2, mouseX, mouseY);
		if(hasChildren) {
			for(Node child : children) {
				child.update(lodData, mouseX, mouseY);
			}
		}
	}
	public void draw(Graphics g) {
		if(hasChildren) {
			for(Node child : children) {
				child.draw(g);
			}
		} else {
			g.setColor(Color.BLACK);
			g.drawRect((int)x, (int)y, (int)size, (int)size);
		}
	}
}
