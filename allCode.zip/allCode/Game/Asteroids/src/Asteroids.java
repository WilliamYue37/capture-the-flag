import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Asteroids extends JPanel implements ActionListener, KeyListener {
    
    public static int SIZE = 800;
    
    public static void main(String[] args) {
    	JFrame frame = new JFrame("Asteroids");
    	frame.setSize(SIZE + 6, SIZE + 30);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	Asteroids a = new Asteroids();
    	frame.add(a);
    	frame.setFocusable(true);
    	frame.addKeyListener(a);
    }
    
    private long lastTime;
    private Game game;
    
    private Asteroids() {
    	game = new Game();
    	lastTime = System.currentTimeMillis();
    	
    	javax.swing.Timer timer = new javax.swing.Timer(1, this);
    	timer.start();
    }
    
    public void actionPerformed(ActionEvent e) {
    	long delta = System.currentTimeMillis() - lastTime;
    	lastTime = System.currentTimeMillis();
    	game.update(delta / 1000f);
    	repaint();
    } 

   	public void paint(Graphics g) {
   		game.draw(g);
   	}
   	
   	public void keyPressed(KeyEvent e) { game.keyPressed(e.getKeyCode()); }
   	public void keyReleased(KeyEvent e) { game.keyReleased(e.getKeyCode()); }
   	public void keyTyped(KeyEvent e) {}
}

class Game {
	
	private int level = 0;
	
	private Player player;
	private ArrayList<Asteroid> asteroids = new ArrayList<Asteroid>();
	private ArrayList<Bullet> bullets = new ArrayList<Bullet>();
	
	public Game() {
		player = new Player(this);
	}
	
	public void update(float dt) {
		if(asteroids.isEmpty()) {
			level++;
			for(int i = 0; i < level * 2 + 2; i++) {
				asteroids.add(new Asteroid(this));
			}
		}
		
		player.update(dt);
		
		for(int i = 0; i < bullets.size(); i++) {
			bullets.get(i).update(dt);
			if(bullets.get(i).shouldRemove()) {
				bullets.remove(i--);
			}
		}
		
		for(int i = 0; i < asteroids.size(); i++) {
			asteroids.get(i).update(dt);
			if(asteroids.get(i).shouldRemove()) {
				asteroids.remove(i--);
			}
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, Asteroids.SIZE, Asteroids.SIZE);
		
		g.setColor(Color.WHITE);
		player.draw(g);
		for(Asteroid a : asteroids) {
			a.draw(g);
		} for(Bullet b : bullets) {
			b.draw(g);
		}
	}
	
	public ArrayList<Bullet> getBullets() {
		return bullets;
	}
	
	public ArrayList<Asteroid> getAsteroids() {
		return asteroids;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public void playerKilled() {
		player = new Player(this);
	}
	
	public void keyPressed(int k) { player.keyPressed(k); }
	public void keyReleased(int k) { player.keyReleased(k); }
}

class Shape {
	
	private float[] radians;
	private float[] mags;
	
	private void createPolarPositions(float[] xPositions, float[] yPositions) {
		radians = new float[xPositions.length];
		mags = new float[xPositions.length];
		for(int i = 0; i < xPositions.length; i++) {
			mags[i] = (float) Math.sqrt(xPositions[i] * xPositions[i] + yPositions[i] * yPositions[i]);
			radians[i] = (float) (Math.atan2(yPositions[i], xPositions[i]) - Math.PI / 2);
		}
	}
	
	public Shape(float[] data0, float[] data1, boolean polar) {
		if(polar) {
			radians = data0;
			mags = data1;
		} else {
			createPolarPositions(data0, data1);
		}
	}

	public void draw(Graphics g, float x, float y, float angle) {
		for(int i = 0, j = radians.length - 1; i < radians.length; j = i++) {
			float angle0 = angle + radians[i];
			float angle1 = angle + radians[j];
			int x0 = (int) (Math.cos(angle0) * mags[i] + x);
			int y0 = (int) (Math.sin(angle0) * mags[i] + y);
			int x1 = (int) (Math.cos(angle1) * mags[j] + x);
			int y1 = (int) (Math.sin(angle1) * mags[j] + y);
			g.drawLine(x0, y0, x1, y1);
		}
	}
	
	private boolean between(double f, double a, double b) {
		if(a >= f && b <= f) { return true; }
		if(b >= f && a <= f) { return true; }
		return false;
	}
	
	private boolean intersectionOnRight(double x0, double y0, double x1, double y1, double xp, double yp) {
		if(x0 == x1) {
			if(x0 < xp) { return false; }
			return between(yp, y0, y1);
		}
		
		double slope = (y1 - y0) / (x1 - x0);
		double x = (yp - y0) / slope + x0;
		if(x < xp) { return false; }
		return between(yp, y0, y1);
	}
	
	private boolean inter(Shape shape, float x, float y, float angle, float X, float Y, float Angle) {
		for(int i = 0; i < radians.length; i++) {
			float xp = (float) Math.cos(angle + radians[i]) * mags[i] + x;
			float yp = (float) Math.sin(angle + radians[i]) * mags[i] + y;
			
			if(shape.pointIn(xp, yp, X, Y, Angle)) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean intersects(Shape shape, float x, float y, float angle, float X, float Y, float Angle) {
		return inter(shape, x, y, angle, X, Y, Angle) || shape.inter(this, X, Y, Angle, x, y, angle);
	}
	
	public boolean pointIn(float x, float y, float bx, float by, float angle) {
		int intersections = 0;
		
		for(int i = 0, j = radians.length - 1; i < radians.length; j = i++) {
			float angle0 = angle + radians[i];
			float angle1 = angle + radians[j];
			float x0 = (float) Math.cos(angle0) * mags[i] + bx;
			float y0 = (float) Math.sin(angle0) * mags[i] + by;
			float x1 = (float) Math.cos(angle1) * mags[j] + bx;
			float y1 = (float) Math.sin(angle1) * mags[j] + by;
			
			if(intersectionOnRight(x0, y0, x1, y1, x, y)) {
				intersections++;
			}
		}

		return intersections % 2 == 1;
	}
}

class Bullet {
	
	private float x;
	private float y;
	private float dx;
	private float dy;

	private boolean shouldRemove = false;
	
	private static final float SPEED = 800;
	
	public Bullet(float x, float y, float angle) {
		this.x = x;
		this.y = y;
		dx = (float) Math.cos(angle) * SPEED;
		dy = (float) Math.sin(angle) * SPEED;
	}
	
	public void update(float dt) {
		x += dx * dt;
		y += dy * dt;
		
		if(x < 0) { shouldRemove = true; }
		if(y < 0) { shouldRemove = true; }
		if(x > Asteroids.SIZE) { shouldRemove = true; }
		if(y > Asteroids.SIZE) { shouldRemove = true; }
	}
	
	public boolean shouldRemove() {
		return shouldRemove;
	}
	
	public void hitSomething() {
		shouldRemove = true;
	}
	
	public void draw(Graphics g) {
		g.fillOval((int) x - 3, (int) y - 3, 6, 6);
	}
	
	public float getX() {
		return x;
	}
	
	public float getY() {
		return y;
	}
}

class Asteroid {
	
	public static final int LARGE = 2;
	public static final int MEDIUM = 1;
	public static final int SMALL = 0;
	private int size;
	
	private float x;
	private float y;
	private float dx;
	private float dy;
	
	private float angle;
	private float rotateSpeed;
	
	private Shape shape;
	
	private boolean shouldRemove = false;
	
	private Game game;
	
	public Asteroid(Game game) {
		this.game = game;
		
		float angle = (float) (Math.random() * Math.PI * 2);
		x = (float) Math.cos(angle) * Asteroids.SIZE * 3 / 4 + Asteroids.SIZE / 2;
		y = (float) Math.sin(angle) * Asteroids.SIZE * 3 / 4 + Asteroids.SIZE / 2;
		size = LARGE;
		
		setSpeed();
		createShape();
	}
	
	public Asteroid(Game game, int size, float x, float y) {
		this.game = game;
		
		this.x = x;
		this.y = y;
		this.size = size;
		
		setSpeed();
		createShape();
	}
	
	private void createShape() {
		int numPoints = 0;
		float minRadius = 0;
		float maxRadius = 0;
		switch(size) {
		case LARGE :
			numPoints = 12;
			minRadius = 30;
			maxRadius = 50;
			break;
		case MEDIUM : 
			numPoints = 10;
			minRadius = 10;
			maxRadius = 32;
			break;
		case SMALL : 
			numPoints = 8;
			minRadius = 4;
			maxRadius = 18;
			break;
		}
		
		float[] radians = new float[numPoints];
		float[] mags = new float[numPoints];
		for(int i = 0; i < numPoints; i++) {
			radians[i] = (float) Math.PI * 2 * i / numPoints;
			mags[i] = (float) Math.random() * (maxRadius - minRadius) + minRadius;
		}
		
		shape = new Shape(radians, mags, true);
	}
	
	public boolean shouldRemove() {
		return shouldRemove;
	}
	
	private void setSpeed() {
		rotateSpeed = (float) (Math.random() * Math.PI - Math.PI / 2) * 1.35f;
		
		float speed = 0;
		switch(size) {
		case LARGE :
			speed = 75;
			break;
		case MEDIUM : 
			speed = 200;
			break;
		case SMALL : 
			speed = 350;
			break;
		}
		
		float angle = (float) (Math.random() * Math.PI * 2);
		dx = (float) Math.cos(angle) * speed;
		dy = (float) Math.sin(angle) * speed;
	}
	
	private void split() {
		if(size != SMALL) {
			game.getAsteroids().add(new Asteroid(game, size - 1, x, y));
			game.getAsteroids().add(new Asteroid(game, size - 1, x, y));
		}
	}
	
	public void update(float dt) {
		angle += rotateSpeed * dt;
		
		x += dx * dt;
		y += dy * dt;
		
		if(x < 0) { x = Asteroids.SIZE; }
		if(y < 0) { y = Asteroids.SIZE; }
		if(x > Asteroids.SIZE) { x = 0; }
		if(y > Asteroids.SIZE) { y = 0; }
		
		for(Bullet bullet : game.getBullets()) {
			if(!bullet.shouldRemove() && shape.pointIn(bullet.getX(), bullet.getY(), x, y, angle)) {
				shouldRemove = true;
				bullet.hitSomething();
				split();
				return;
			}
		}

		Player player = game.getPlayer();
		if(shape.intersects(player.getShape(), x, y, angle, player.getX(), player.getY(), player.getAngle())) {
			game.playerKilled();
			shouldRemove = true;
			split();
		}
	}
	
	public void draw(Graphics g) {
		shape.draw(g, x, y, angle);
	}
}

class Player {

	private boolean up;
	private boolean left;
	private boolean right;

	private float x;
	private float y;
	private float angle;

	private float[] xPositions = { 0, -5, 0, 5 };
	private float[] yPositions = { 10, -6, -2, -6 };
	private Shape shape;
	
	private float xVelocity;
	private float yVelocity;
	private static final float MAX_SPEED = 400;
	private static final float ACCEL = 500;
	private static final float FRICTION = -200;
	
	private static final float ROTATE_SPEED = (float) Math.PI;
	
	private Game game;
	
	public Player(Game game) {
		this.game = game;		
		x = Asteroids.SIZE / 2;
		y = Asteroids.SIZE / 2;		
		shape = new Shape(xPositions, yPositions, false);
	}
	
	private void capSpeed() {
		float speed = getSpeed();
		if(speed > MAX_SPEED) {
			xVelocity = xVelocity / speed * MAX_SPEED;
			yVelocity = yVelocity / speed * MAX_SPEED;
		}
	}
	
	private float getSpeed() {
		return (float) Math.sqrt(xVelocity * xVelocity + yVelocity * yVelocity);
	}
	
	public void update(float dt) {
		if(left) {
			angle -= ROTATE_SPEED * dt;
		} if(right) {
			angle += ROTATE_SPEED * dt;
		}
		
		if(up) {
			xVelocity += (float) Math.cos(angle) * ACCEL * dt;
			yVelocity += (float) Math.sin(angle) * ACCEL * dt;
			capSpeed();
		} else {
			float speed = getSpeed();
			if(speed != 0) {
				float s = speed + FRICTION * dt;
				if(s < 0) { s = 0; }
				xVelocity = xVelocity / speed * s;
				yVelocity = yVelocity / speed * s;
			}
		}
		
		x += xVelocity * dt;
		y += yVelocity * dt;
		
		if(x < 0) { x = Asteroids.SIZE; }
		if(y < 0) { y = Asteroids.SIZE; }
		if(x > Asteroids.SIZE) { x = 0; }
		if(y > Asteroids.SIZE) { y = 0; }
	}

	public void draw(Graphics g) {
		shape.draw(g, x, y, angle);
	}
	
	private void fire() {
		Bullet b = new Bullet(x, y, angle);
		game.getBullets().add(b);
	}
	
	public float getX() {
		return x;
	}
	
	public float getY() {
		return y;
	}
	
	public float getAngle() {
		return angle;
	}
	
	public Shape getShape() {
		return shape;
	}
	
	public void keyPressed(int k) {
		switch(k) {
		case KeyEvent.VK_UP :
			up = true;
			break;
		case KeyEvent.VK_LEFT :
			left = true;
			break;
		case KeyEvent.VK_RIGHT :
			right = true;
			break;
		case KeyEvent.VK_SPACE : 
			fire();
			break;
		}
	}
	
	public void keyReleased(int k) {
		switch(k) {
		case KeyEvent.VK_UP :
			up = false;
			break;
		case KeyEvent.VK_LEFT :
			left = false;
			break;
		case KeyEvent.VK_RIGHT :
			right = false;
			break;
		}
	}
}