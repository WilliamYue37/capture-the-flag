import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class TicTacToe extends JPanel implements MouseListener {
    
    public static final int SIZE = 900;
    
    public static void main(String[] args) {
    	JFrame frame = new JFrame("Ultimate Tic Tac Toe");
    	frame.setFocusable(true);
    	frame.setSize(SIZE + 6, SIZE + 50);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	TicTacToe a = new TicTacToe();
    	frame.addMouseListener(a);
    	frame.add(a);
    }
    
    private Game game;
    
    private TicTacToe() {
    	game = new Game();
    }
    
    public void paint(Graphics g) {
    	game.draw(g);
    }
    
    public void mousePressed(MouseEvent e) {
    	game.mousePressed(e.getX() - 7, e.getY() - 30);
    	repaint();
    }
    
    public void mouseReleased(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
}

class Board {
	
	private static Color LIGHT_RED = new Color(255, 102, 102);
	private static Color LIGHT_GREEN = new Color(130, 255, 130);
	
	public static final int SIZE = TicTacToe.SIZE / 3;
	
	private int x;
	private int y;
	
	private char winner = ' ';
	
	private Token[][] tokens = new Token[3][3];
	
	public Board(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public boolean wOn(Board a, Board b) {
		return a.winner == winner && b.winner == winner;
	}
	
	public boolean won() {
		return winner != ' ';
	}

	public char getChar() {
		return winner;
	}

	private void testWinner() {
		if(tokens[0][0] != null && tokens[0][0].won(tokens[0][1], tokens[0][2])) { winner = tokens[0][0].getChar(); }
		if(tokens[1][0] != null && tokens[1][0].won(tokens[1][1], tokens[1][2])) { winner = tokens[1][0].getChar(); }
		if(tokens[2][0] != null && tokens[2][0].won(tokens[2][1], tokens[2][2])) { winner = tokens[2][0].getChar(); }
		
		if(tokens[0][0] != null && tokens[0][0].won(tokens[1][0], tokens[2][0])) { winner = tokens[0][0].getChar(); }
		if(tokens[0][1] != null && tokens[0][1].won(tokens[1][1], tokens[2][1])) { winner = tokens[0][1].getChar(); }
		if(tokens[0][2] != null && tokens[0][2].won(tokens[1][2], tokens[2][2])) { winner = tokens[0][2].getChar(); }
		
		if(tokens[0][0] != null && tokens[0][0].won(tokens[1][1], tokens[2][2])) { winner = tokens[0][0].getChar(); }
		if(tokens[0][2] != null && tokens[0][2].won(tokens[1][1], tokens[2][0])) { winner = tokens[0][2].getChar(); }
		
		if(winner == ' ') {
			winner = 'n';
			for(int i = 0; i < 3; i++) {
				for(int j = 0; j < 3; j++) {
					if(tokens[i][j] == null) {
						winner = ' ';
						return;
					}
				}
			}
		}
	}
	
	public boolean setToken(int x, int y, boolean o) {
		if(winner == ' ' && tokens[x][y] == null) {
			Token t;
			int tx = x * Token.SIZE + this.x * SIZE;
			int ty = y * Token.SIZE + this.y * SIZE;
			
			if(o) {
				t = new TokenO(tx, ty);
			} else {
				t = new TokenX(tx, ty);
			}
			
			tokens[x][y] = t;
			testWinner();

			return true;
		} else {
			return false;
		}
	}
	
	public void draw(Graphics g, boolean canPlay) {
		g.setColor(Color.BLACK);
		g.fillRect(x * SIZE, y * SIZE, SIZE, SIZE);
		switch(winner) {
			case ' ' : g.setColor(Color.WHITE); break;
			case 'X' : g.setColor(LIGHT_RED); break;
			case 'O' : g.setColor(LIGHT_GREEN); break;
			case 'n' : g.setColor(Color.GRAY); break;
		} if(canPlay) {
			g.setColor(Color.CYAN);
		}
		g.fillRect(x * SIZE + 5, y * SIZE + 5, SIZE - 10, SIZE - 10);
		g.setColor(Color.BLACK);
		g.drawLine(x * SIZE + SIZE / 3, y * SIZE, x * SIZE + SIZE / 3, y * SIZE + SIZE);
		g.drawLine(x * SIZE + SIZE * 2 / 3, y * SIZE, x * SIZE + SIZE * 2 / 3, y * SIZE + SIZE);
		g.drawLine(x * SIZE, y * SIZE + SIZE / 3, x * SIZE + SIZE, y * SIZE + SIZE / 3);
		g.drawLine(x * SIZE, y * SIZE + SIZE * 2 / 3, x * SIZE + SIZE, y * SIZE + SIZE * 2 / 3);
		
		for(Token[] tA : tokens) {
			for(Token t : tA) {
				if(t != null) {
					t.draw(g);
				}
			}
		}
	}
}

class Game {
	
	private ArrayList<Point> playable = new ArrayList<Point>();
	private boolean xTurn = true;
	private Board[][] boards = new Board[3][3];
	private char winner = ' ';
	
	private void testWinner() {
		if(boards[0][0].won() && boards[0][0].wOn(boards[0][1], boards[0][2])) { winner = boards[0][0].getChar(); }
		if(boards[1][0].won() && boards[1][0].wOn(boards[1][1], boards[1][2])) { winner = boards[1][0].getChar(); }
		if(boards[2][0].won() && boards[2][0].wOn(boards[2][1], boards[2][2])) { winner = boards[2][0].getChar(); }
		
		if(boards[0][0].won() && boards[0][0].wOn(boards[1][0], boards[2][0])) { winner = boards[0][0].getChar(); }
		if(boards[0][1].won() && boards[0][1].wOn(boards[1][1], boards[2][1])) { winner = boards[0][1].getChar(); }
		if(boards[0][2].won() && boards[0][2].wOn(boards[1][2], boards[2][2])) { winner = boards[0][2].getChar(); }
		
		if(boards[0][0].won() && boards[0][0].wOn(boards[1][1], boards[2][2])) { winner = boards[0][0].getChar(); }
		if(boards[0][2].won() && boards[0][2].wOn(boards[1][1], boards[2][0])) { winner = boards[0][2].getChar(); }

		if(winner == ' ') {
			winner = 'n';
			for(int i = 0; i < 3; i++) {
				for(int j = 0; j < 3; j++) {
					if(!boards[i][j].won()) {
						winner = ' ';
					}
				}
			}
		}
	}
	
	public Game() {
		playable.add(new Point(1, 1));
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				boards[i][j] = new Board(i, j);
			}
		}
	}
	
	public void draw(Graphics g) {
		if(winner == ' ') {
			for(int i = 0; i < 3; i++) {
				for(int j = 0; j < 3; j++) {
					boolean canPlay = false;
					for(Point p : playable) {
						if(p.x == i && p.y == j) {
							canPlay = true;
						}
					}
					boards[i][j].draw(g, canPlay);
				}
			}
					
			g.setColor(Color.WHITE);
			g.fillRect(0, TicTacToe.SIZE, TicTacToe.SIZE, 20);
			g.setColor(Color.BLACK);
			g.drawString(xTurn ? "Player X's turn!" : "Player O'x turn!", 10, TicTacToe.SIZE + 15);
		}
		
		else {
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, TicTacToe.SIZE, TicTacToe.SIZE + 20);
			switch(winner) {
			case 'X' : 
				g.setColor(Color.RED);
				g.drawLine(10, 10, TicTacToe.SIZE - 20, TicTacToe.SIZE - 20);
				g.drawLine(TicTacToe.SIZE - 20, 10, 10, TicTacToe.SIZE - 20);
				break;
			case 'O' :
				g.setColor(Color.GREEN);
				g.drawOval(10, 10, TicTacToe.SIZE - 20, TicTacToe.SIZE - 20);
				break;
			case 'n' :
				g.setColor(Color.GRAY);
				g.drawLine(20, 50, TicTacToe.SIZE - 40, 50);
				g.drawLine(TicTacToe.SIZE / 2, 50, TicTacToe.SIZE / 2, TicTacToe.SIZE - 100);
				break;
			}
		}
	}
	
	public void mousePressed(int x, int y) {
		int bx = x * 3 / TicTacToe.SIZE;
		int by = y * 3 / TicTacToe.SIZE;
		int tx = (x * 9 / TicTacToe.SIZE) % 3;
		int ty = (y * 9 / TicTacToe.SIZE) % 3;
		
		boolean canPlay = false;
		for(Point p : playable) {
			if(p.x == bx && p.y == by) {
				canPlay = true;
			}
		}
		
		if(canPlay && boards[bx][by].setToken(tx, ty, !xTurn)) {
			xTurn = !xTurn;
			
			playable.clear();
			if(boards[tx][ty].won()) {
				for(int i = 0; i < 3 ; i++) {
					for(int j = 0; j < 3; j++) {
						if(!boards[i][j].won()) {
							playable.add(new Point(i, j));
						}
					}
				}
			} else {
				playable.add(new Point(tx, ty));
			}
			
			testWinner();
		}
	}
}

abstract class Token {
	
	public static final int SIZE = TicTacToe.SIZE / 9;

	private char c;
	protected int x;
	protected int y;
	
	public Token(int x, int y, char c) {
		this.x = x;
		this.y = y;
		this.c = c;
	}
	
	public abstract void draw(Graphics g);
	
	public char getChar() {
		return c;
	}
	
	public boolean won(Token a, Token b) {
		if(a == null || b == null) { return false; }
		return a.c == c && b.c == c;
	}
}

class TokenX extends Token {
	
	public TokenX(int x, int y) {
		super(x, y, 'X');
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.RED);
		g.drawLine(x + 6, y + 6, x + SIZE - 12, y + SIZE - 12);
		g.drawLine(x + SIZE - 12, y + 6, x + 6, y + SIZE - 12);
	}
}


class TokenO extends Token {
	
	public TokenO(int x, int y) {
		super(x, y, 'O');
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.GREEN);
		g.drawOval(x + 6, y + 6, SIZE - 12, SIZE - 12);
	}
}



































