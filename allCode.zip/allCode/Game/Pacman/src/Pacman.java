import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Pacman extends JPanel implements ActionListener, KeyListener {
    
    public static int SIZE = 800;

    public static void main(String[] args) {
    	JFrame frame = new JFrame("Pacman");
    	frame.setSize(SIZE + 7, SIZE + 30);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	Pacman a = new Pacman();
    	frame.add(a);
    	frame.setFocusable(true);
    	frame.addKeyListener(a);
    }
    
    private Game game;
    
    private Pacman() {
    	game = new Game();
    	
    	javax.swing.Timer timer = new javax.swing.Timer(1, this);
    	timer.start();
    }
    
    public void actionPerformed(ActionEvent e) {
    	game.update();
    	repaint();
    } 

   	public void paint(Graphics g) {
		game.draw(g);
   	}
   	
   	public void keyPressed(KeyEvent e) {
   		game.keyPressed(e.getKeyCode());
   	}
   	
   	public void keyReleased(KeyEvent e) {}
   	public void keyTyped(KeyEvent e) {}
}

class Player {
	
	private static final int UP = 1;
	private static final int DOWN = -1;
	private static final int LEFT = 2;
	private static final int RIGHT = -2;
	
	private int direction;
	private int requestedDirection;
	
	private int x = Pacman.SIZE / BoardData.BOARD_SIZE;
	private int y = Pacman.SIZE / BoardData.BOARD_SIZE;
	private int size = Pacman.SIZE / BoardData.BOARD_SIZE;
	
	private static final int SPEED = 4;
	
	public Player() {
		
	}
	
	private int moveX() {
		if(direction == LEFT) {
			return x - SPEED;
		} else if(direction == RIGHT) {
			return x + SPEED;
		} else {
			return x;
		}
	}
	
	private int moveY() {
		if(direction == UP) {
			return y - SPEED;
		} else if(direction == DOWN) {
			return y + SPEED;
		} else {
			return y;
		}
	}
	
	private boolean testPoint(int x, int y) {
		int tx = x * BoardData.BOARD_SIZE / Pacman.SIZE;
		int ty = y * BoardData.BOARD_SIZE / Pacman.SIZE;
		return BoardData.getTile(tx, ty) != BoardData.OPEN;
	}
	
	private boolean canMove(int direction) {
		int x = moveX();
		int y = moveY();
		if(testPoint(x, y)) { return false; }
		if(testPoint(x, y + size)) { return false; }
		if(testPoint(x + size, y)) { return false; }
		if(testPoint(x + size, y + size)) { return false; }
		return true;
	}
		
	private void move() {
		x = moveX();
		y = moveY();
	}
	
	public void update() {
		if(canMove(requestedDirection)) {
			direction = requestedDirection;
			move();
		} else if(canMove(direction)) {
			move();
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.YELLOW);
		g.fillOval(x, y, size, size);
	}
	
	public void keyPressed(int k) {
		switch(k) {
		case KeyEvent.VK_UP :
			requestedDirection = UP;
			break;
		case KeyEvent.VK_DOWN :
			requestedDirection = DOWN;
			break;
			case KeyEvent.VK_LEFT :
			requestedDirection = LEFT;
			break;
		case KeyEvent.VK_RIGHT :
			requestedDirection = RIGHT;
			break;
		}
	}
}

class Game {
	
	private char[][] board = new char[BoardData.BOARD_SIZE][BoardData.BOARD_SIZE];
	private Player player;
	
	public Game() {
		player = new Player();
	}
	
	public void update() {
		player.update();
	}

	public void keyPressed(int k) {
		player.keyPressed(k);
	}
	
	public void draw(Graphics g) {
		for(int x = 0; x < BoardData.BOARD_SIZE; x++) {
			for(int y = 0; y < BoardData.BOARD_SIZE; y++) {
				switch(BoardData.getTile(x, y)) {
				case BoardData.OPEN :
					g.setColor(Color.BLACK);
					break;
				case BoardData.CLOSED :
					g.setColor(Color.BLUE);
					break;
				default :
					g.setColor(Color.GREEN);
					break;
				}
				
				g.fillRect(x * Pacman.SIZE / BoardData.BOARD_SIZE, y * Pacman.SIZE / BoardData.BOARD_SIZE, Pacman.SIZE / BoardData.BOARD_SIZE, Pacman.SIZE / BoardData.BOARD_SIZE);
			}
		}
		
		player.draw(g);
	}
}

class BoardData {
	
	public static final int BOARD_SIZE = 25;
	public static final char[][] BOARD_DATA = {{'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'o', 'c' }, 
 { 'c', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'c', 'c', 'o', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'c', 'o', 'o', 'c', 'o', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'o', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'c', 'o', 'c', 'o', 'o', 'c' }, 
 { 'c', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'c', 'o', 'c' }, 
 { 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'o', 'o', 'c', 'o', 'o', 'c', 'o', 'o', 'c' }, 
 { 'c', 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'c', 'c', 'o', 'c', 'c', 'o', 'c', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'c', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'c', 'c' }, 
 { 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o' }, 
 { 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'o', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'o', 'c', 'c', 'c', 'c', 'c' }, 
 { 'c', 'o', 'o', 'o', 'c', 'o', 'c', 'o', 'o', 'c', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'c' }, 
 { 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'o', 'c', 'o', 'c' }, 
 { 'c', 'o', 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'c', 'o', 'o', 'c', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'c' }, 
 { 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'o', 'c', 'c', 'c', 'c', 'c', 'o', 'c' }, 
 { 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'c' }, 
 { 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'c', 'c', 'c', 'c', 'c', 'o', 'c', 'c', 'c', 'c', 'c' }, 
 { 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'c', 'o', 'c', 'c', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'c' }, 
 { 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'o', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'c', 'c' }, 
 { 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'o', 'o', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'c', 'o', 'o' }, 
 { 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'o', 'c', 'c', 'c', 'c', 'c', 'o', 'c', 'o', 'c', 'c', 'c', 'o', 'c', 'o', 'c' }, 
 { 'c', 'o', 'o', 'o', 'o', 'c', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'c', 'o', 'c' }, 
 { 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'c', 'o', 'c' }};
 
 	public static char getTile(int x, int y) {
 		if(x < 0 || y < 0 || x >= BOARD_SIZE || y >= BOARD_SIZE) { return CLOSED; }
 		else { return BOARD_DATA[y][x]; }
 	}
	
	public static final char OPEN = 'o';
	public static final char CLOSED = 'c';
}
