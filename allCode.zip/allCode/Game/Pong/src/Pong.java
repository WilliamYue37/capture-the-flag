import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Pong extends JPanel implements ActionListener, KeyListener {
    
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    
    public static void main(String[] args) {
    	JFrame frame = new JFrame("Pong");
    	frame.setSize(WIDTH + 7, HEIGHT + 30);
    	frame.setLocationRelativeTo(null);
    	frame.setResizable(false);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	Pong a = new Pong();
    	frame.add(a);
    	frame.setFocusable(true);
    	frame.addKeyListener(a);
    }
    
    private Game game;
    
    public Pong() {
    	game = new Game();
    	
    	javax.swing.Timer timer = new javax.swing.Timer(5, this);
    	timer.start();
    }
    
    public void actionPerformed(ActionEvent e) {
    	game.update();
    	repaint();
    }
    
    public void paint(Graphics g) {
    	game.draw(g);
    }
    
    public void keyPressed(KeyEvent e) { game.keyPressed(e.getKeyCode()); }
   	public void keyReleased(KeyEvent e) { game.keyReleased(e.getKeyCode()); }
   	public void keyTyped(KeyEvent e) {}
}

class Ball {
	
	private static final int SPEED = 10;
	private static final int SIZE = 20;
	
	private int x;
	private int y;
	private int dx;
	private int dy;
	private boolean moveLeft;
	
	private Game game;
	private boolean leftWon;
	private boolean rightWon;
	
	public Ball(Game game) {
		this.game = game;
		x = Pong.WIDTH / 2 - SIZE / 2;
		y = Pong.HEIGHT / 2 - SIZE / 2;
		moveLeft = (int)(Math.random() * 2) == 0;
		dy = 0;
		if(moveLeft) {
			dx = -4;
		} else {
			dx = 4;
		}
	}
	
	private void setMove() {
		moveLeft = !moveLeft;
		dx = (int)(Math.random() * SPEED / 2 + SPEED / 2);
		if(moveLeft) {
			dx = -dx;
		}
		
		dy = (int)Math.sqrt(SPEED * SPEED - dx * dx);
		if((int)(Math.random() * 2) == 0) {
			dy = -dy;
		}
	}
	
	public void update() {
		x += dx;
		y += dy;
		
		if(y < 0) {
			y = 0;
			dy = -dy;
		} if(y + SIZE > Pong.HEIGHT) {
			y = Pong.HEIGHT - SIZE;
			dy = -dy;
		}
		
		if(x - SIZE < 0) {
			leftWon = true;
		} if(x > Pong.WIDTH) {
			rightWon = true;
		}
		
		if(game.getRelaventPaddle(moveLeft).getBounds().intersects(new Rectangle(x, y, SIZE, SIZE))) {
			setMove();
		}
	}

	public boolean leftWon() {
		return leftWon;
	}

	public boolean rightWon() {
		return rightWon;
	}

	public void draw(Graphics g) {
		g.setColor(Color.YELLOW);
		g.fillOval(x, y, SIZE, SIZE);
	}
}

class Game {
	
	private Paddle paddleLeft;
	private Paddle paddleRight;
	private Ball ball;
	
	private int leftScore;
	private int rightScore;
	
	public Game() {
		paddleLeft = new Paddle(true);
		paddleRight = new Paddle(false);
		ball = new Ball(this);
	}
	
	public void keyReleased(int k) {
		paddleLeft.keyReleased(k);
		paddleRight.keyReleased(k);
	}
	
	public void keyPressed(int k) {
		paddleLeft.keyPressed(k);
		paddleRight.keyPressed(k);
		
		if(k == KeyEvent.VK_SPACE) {
			ball = new Ball(this);
		}
	}
	
	public void update() {
		paddleLeft.update();
		paddleRight.update();
		ball.update();
		
		if(ball.rightWon()) {
			rightScore++;
			ball = new Ball(this);
		} if(ball.leftWon()) {
			leftScore++;
			ball = new Ball(this);
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, Pong.WIDTH, Pong.HEIGHT);
		g.setColor(Color.WHITE);
		g.fillRect(5, 5, Pong.WIDTH - 10, Pong.HEIGHT - 10);
		g.setColor(Color.BLACK);
		g.fillOval(Pong.WIDTH / 2 - 100, Pong.HEIGHT / 2 - 100, 200, 200);
		g.setColor(Color.WHITE);
		g.fillOval(Pong.WIDTH / 2 - 90, Pong.HEIGHT / 2 - 90, 180, 180);
		g.setColor(Color.BLACK);
		g.fillRect(Pong.WIDTH / 2 - 5, 0, 10, Pong.HEIGHT);
		
		paddleLeft.draw(g);
		paddleRight.draw(g);
		ball.draw(g);
		
		g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 64));
		g.setColor(Color.RED);
		g.drawString(rightScore + "", 150, 100);
		g.setColor(Color.BLUE);
		g.drawString(leftScore + "", Pong.WIDTH - 150, 100);
	}
	
	public Paddle getRelaventPaddle(boolean moveLeft) {
		if(moveLeft) {
			return paddleLeft;
		} else {
			return paddleRight;
		}
	}
}

class Paddle {
	
	private Rectangle bounds;
	private boolean left;
	
	private static final int WIDTH = 15;
	private static final int HEIGHT = 75;
	private static final int SPEED = 4;
	
	private boolean up;
	private boolean down;
	
	public Paddle(boolean left) {
		this.left = left;
		if(left) {
			bounds = new Rectangle(50, Pong.HEIGHT / 2 - HEIGHT / 2, WIDTH, HEIGHT);
		} else {
			bounds = new Rectangle(Pong.WIDTH - 50 - WIDTH, Pong.HEIGHT / 2 - HEIGHT / 2, WIDTH, HEIGHT);
		}
	}
	
	public void keyReleased(int k) {
		if(left) {
			if(k == KeyEvent.VK_W) {
				up = false;
			} if(k == KeyEvent.VK_S) {
				down = false;
			}
		} else {
			if(k == KeyEvent.VK_UP) {
				up = false;
			} if(k == KeyEvent.VK_DOWN) {
				down = false;
			}
		}
	}
	
	public void keyPressed(int k) {
		if(left) {
			if(k == KeyEvent.VK_W) {
				up = true;
			} if(k == KeyEvent.VK_S) {
				down = true;
			}
		} else {
			if(k == KeyEvent.VK_UP) {
				up = true;
			} if(k == KeyEvent.VK_DOWN) {
				down = true;
			}
		}
	}
	
	public void update() {
		if(up) {
			bounds.y -= SPEED;
		} if(down) {
			bounds.y += SPEED;
		}
		
		if(bounds.y < -10) {
			bounds.y = -10;
		} if(bounds.y + HEIGHT > Pong.HEIGHT + 10) {
			bounds.y = Pong.HEIGHT + 10 - HEIGHT;
		}
	}
	
	public void draw(Graphics g) {
		g.setColor(left ? Color.RED : Color.BLUE);
		g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
	}
	
	public Rectangle getBounds() {
		return bounds;
	}
}
