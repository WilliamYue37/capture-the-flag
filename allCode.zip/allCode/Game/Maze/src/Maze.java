import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class Maze extends JPanel implements ActionListener, KeyListener {
    
    public static final int SIZE = 840;
    
    public static void main(String[] args) {
    	JFrame frame = new JFrame("Maze");
    	frame.setSize(SIZE, SIZE + 20);
    	frame.setLocationRelativeTo(null);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setVisible(true);
    	Maze maze = new Maze();
    	frame.add(maze);
    	frame.setFocusable(true);
    	frame.addKeyListener(maze);
    }
    
    private Game game;
    
    private Maze() {
    	javax.swing.Timer timer = new javax.swing.Timer(10, this);
    	timer.start();
    	
    	game = new Game();
    }
    
    public void actionPerformed(ActionEvent e) {
    	if(game.isComplete()) {
    		game = new Game();
    	}
    	
    	repaint();
    }
    
    public void paint(Graphics g) {
    	game.draw(g);
    }
    
    public void keyPressed(KeyEvent e) {
    	if(e.getKeyCode() == KeyEvent.VK_SPACE) {
    		game = new Game();
    	}
    	
    	game.keyPressed(e.getKeyCode());
    }
    
    public void keyReleased(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}
}

class Game {
	
	private int x;
	private int y;
	private Point start;
	private Point end;
	
	private boolean[][] tiles;
	private boolean[][] visible;
	private static final int NUM_TILES = 41;
	private static final int TILE_SIZE = Maze.SIZE / NUM_TILES;
	
	public Game() {
		tiles = new boolean[NUM_TILES][NUM_TILES];
		visible = new boolean[NUM_TILES][NUM_TILES];
		start = Generator.getStartCoords(NUM_TILES);
		end = Generator.generate(tiles, end, start);
		x = start.x;
		y = start.y;
		updateVisible();
	}
	
	private void updateVisible() {
		int x = this.x;
		int y = this.y;
		while(tiles[x][y]) {
			x++;
			visible[x][y] = true;
			visible[x][y + 1] = true;
			visible[x][y - 1] = true;
		}
		
		x = this.x;
		while(tiles[x][y]) {
			x--;
			visible[x][y] = true;
			visible[x][y + 1] = true;
			visible[x][y - 1] = true;
		}
		
		x = this.x;
		while(tiles[x][y]) {
			y++;
			visible[x][y] = true;
			visible[x + 1][y] = true;
			visible[x - 1][y] = true;
		}
		
		y = this.y;
		while(tiles[x][y]) {
			y--;
			visible[x][y] = true;
			visible[x + 1][y] = true;
			visible[x - 1][y] = true;
		}
	}
	
	public void keyPressed(int k) {
		switch(k) {
		case KeyEvent.VK_UP :
			if(tiles[x][y - 1]) {
				y--;
				updateVisible();
			}
			break;
		case KeyEvent.VK_DOWN : 
			if(tiles[x][y + 1]) {
				y++;
				updateVisible();
			}
			break;
		case KeyEvent.VK_LEFT : 
			if(tiles[x - 1][y]) {
				x--;
				updateVisible();
			}
			break;
		case KeyEvent.VK_RIGHT : 
			if(tiles[x + 1][y]) {
				x++;
				updateVisible();
			}
			break;
		case KeyEvent.VK_ENTER : 
			for(int x = 0; x < NUM_TILES; x++) {
				for(int y = 0; y < NUM_TILES; y++) {
					visible[x][y] = true;
				}
			}
			break;
		}
	}

	public void draw(Graphics g) {
		for(int x = 0; x < NUM_TILES; x++) {
			for(int y = 0; y < NUM_TILES; y++) {
				g.setColor(tiles[x][y] ? Color.WHITE : Color.BLUE);
				if(x == start.x && y == start.y) { g.setColor(Color.GREEN); }
				if(y == end.y && x == end.x) { g.setColor(Color.RED); }
				if(!visible[x][y]) { g.setColor(Color.BLACK); }
				g.fillRect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
			}
		}
		
		g.setColor(Color.RED);
		g.fillOval(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
	}
	
	public boolean isComplete() {
		return x == end.x && y == end.y;
	}
}

class Generator {
	
	public static Point getStartCoords(int size) {
		int x = getStartCoord(size);
		int y = getStartCoord(size);
		return new Point(x, y);
	}
	
	private static int getStartCoord(int size) {
		int c = 0;
		do {
			c = (int) (Math.random() * size / 2) + 1;
		} while(c % 2 == 0);
		return c;
	}
	
	public static Point generate(boolean[][] tiles, Point end, Point start) {
		int size = tiles.length;
		ArrayList<Point> openList = new ArrayList<Point>();
		ArrayList<Point> closedList = new ArrayList<Point>();
		openList.add(start);
		tiles[start.x][start.y] = true;
		
		while(!openList.isEmpty()) {
			int c = (int) (Math.random() * openList.size());
			Point current = openList.remove(c);
			closedList.add(current);
			open(current, tiles, openList, closedList);
		}
		
		return closedList.get(closedList.size() - 1);
	}
	
	private static void open(Point center, boolean[][] tiles, ArrayList<Point> openList, ArrayList<Point> closedList) {
		open(center, 2, 0, tiles, openList, closedList);
		open(center, 0, 2, tiles, openList, closedList);
		open(center, -2, 0, tiles, openList, closedList);
		open(center, 0, -2, tiles, openList, closedList);
	}
	
	private static void open(Point point, int xOffset, int yOffset, boolean[][] tiles, ArrayList<Point> openList, ArrayList<Point> closedList) {
		Point n = new Point(point.x + xOffset, point.y + yOffset);
		if(validPoint(n, tiles.length) && !inList(n, openList) && !inList(n, closedList)) {
			openList.add(n);
			tiles[point.x + xOffset / 2][point.y + yOffset / 2] = true;
			tiles[n.x][n.y] = true;
		}
	}
	
	private static boolean validPoint(Point point, int size) {
		if(point.x < 0) { return false; }
		if(point.y < 0) { return false; }
		if(point.x >= size) { return false; }
		if(point.y >= size) { return false; }
		return true;
	}
	
	private static boolean inList(Point point, ArrayList<Point> points) {
		for(Point p : points) {
			if(point.equals(p)) {
				return true;
			}
		}
		
		return false;
	}
}
